
  # Tuition Centre Management System (Community)

  This is a code bundle for Tuition Centre Management System (Community). The original project is available at https://www.figma.com/design/64ShDacEzL4vfLJMeenFVh/Tuition-Centre-Management-System--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  