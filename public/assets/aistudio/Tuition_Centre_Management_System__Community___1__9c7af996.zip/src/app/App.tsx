import { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { LoginModal } from './components/LoginModal';
import { EnquireModal } from './components/EnquireModal';
import { AppointmentModal } from './components/AppointmentModal';

// Student Components
import { StudentDashboard } from './components/student/StudentDashboard';
import { StudentSidebar } from './components/student/StudentSidebar';
import { StudentSchedule } from './components/student/StudentSchedule';
import { StudentAssignments } from './components/student/StudentAssignments';
import { StudentHelp } from './components/student/StudentHelp';
import { StudentBookings } from './components/student/StudentBookings';
import { StudentTimetable } from './components/student/StudentTimetable';
import { StudentProgressReports } from './components/student/StudentProgressReports';
import { StudentAnnouncements } from './components/student/StudentAnnouncements';

// Staff Components  
import { StaffSidebar } from './components/staff/StaffSidebar';
import { StaffDashboard } from './components/staff/StaffDashboard';
import { StaffAssignments } from './components/staff/StaffAssignments';
import { StaffStudentRequests } from './components/staff/StaffStudentRequests';
import { StaffAnnouncements } from './components/staff/StaffAnnouncements';
import { StaffAttendance } from './components/staff/StaffAttendance';
import { StaffStudents } from './components/staff/StaffStudents';
import { StaffScheduler } from './components/staff/StaffScheduler';
import { StaffProfile } from './components/staff/StaffProfile';

// Admin Components
import { Dashboard } from './components/Dashboard';
import { StudentManagement } from './components/StudentManagement';
import { TeacherManagement } from './components/TeacherManagement';
import { ClassScheduling } from './components/ClassScheduling';
import { HRManagement } from './components/HRManagement';
import { Settings } from './components/Settings';
import { AdminSidebar } from './components/admin/AdminSidebar';
import { AdminFinance } from './components/admin/AdminFinance';
import { AdminReports } from './components/admin/AdminReports';
import { AdminCommunications } from './components/admin/AdminCommunications';
import { AdminResources } from './components/admin/AdminResources';
import { AdminDocuments } from './components/admin/AdminDocuments';

type UserType = 'student' | 'staff' | 'admin' | null;

interface User {
  type: UserType;
  email: string;
  name: string;
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeModule, setActiveModule] = useState('dashboard');
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isEnquireModalOpen, setIsEnquireModalOpen] = useState(false);
  const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);

  const handleLogin = (userType: UserType, credentials: { email: string; password: string }) => {
    // Mock authentication - in real app this would validate against backend
    const mockUsers = {
      'student@ilamtuition.co.nz': { type: 'student', name: 'Sarah Chen' },
      'staff@ilamtuition.co.nz': { type: 'staff', name: 'Dr. Smith Johnson' },
      'admin@ilamtuition.co.nz': { type: 'admin', name: 'Admin User' }
    };

    const mockUser = mockUsers[credentials.email as keyof typeof mockUsers];
    if (mockUser) {
      setUser({
        type: userType,
        email: credentials.email,
        name: mockUser.name
      });
      setActiveModule('dashboard');
    } else {
      alert('Invalid credentials. Please use the demo credentials provided.');
    }
  };

  const handleLogout = () => {
    setUser(null);
    setActiveModule('dashboard');
  };

  const renderStudentModule = () => {
    switch (activeModule) {
      case 'dashboard':
        return <StudentDashboard />;
      case 'schedule':
        return <StudentSchedule />;
      case 'progress':
        return <StudentProgressReports />;
      case 'assignments':
        return <StudentAssignments />;
      case 'announcements':
        return <StudentAnnouncements />;
      case 'timetable':
        return <StudentTimetable />;
      case 'bookings':
        return <StudentBookings />;
      case 'assistance':
        return <StudentHelp />;
      default:
        return <StudentDashboard />;
    }
  };

  const renderStaffModule = () => {
    switch (activeModule) {
      case 'dashboard':
        return <StaffDashboard />;
      case 'students':
        return <StaffStudents />;
      case 'schedule':
        return <ClassScheduling />;
      case 'assignments':
        return <StaffAssignments />;
      case 'requests':
        return <StaffStudentRequests />;
      case 'announcements':
        return <StaffAnnouncements />;
      case 'attendance':
        return <StaffAttendance />;
      case 'scheduler':
        return <StaffScheduler />;
      case 'profile':
        return <StaffProfile />;
      default:
        return <div className="p-6"><h1>Staff Dashboard</h1><p>Staff dashboard coming soon...</p></div>;
    }
  };

  const renderAdminModule = () => {
    switch (activeModule) {
      case 'dashboard':
        return <Dashboard />;
      case 'students':
        return <StudentManagement />;
      case 'teachers':
        return <TeacherManagement />;
      case 'hr':
        return <HRManagement />;
      case 'finance':
        return <AdminFinance />;
      case 'reports':
        return <AdminReports />;
      case 'communications':
        return <AdminCommunications />;
      case 'resources':
        return <AdminResources />;
      case 'documents':
        return <AdminDocuments />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  const renderSidebar = () => {
    if (user?.type === 'student') {
      return <StudentSidebar activeModule={activeModule} setActiveModule={setActiveModule} onLogout={handleLogout} />;
    } else if (user?.type === 'staff') {
      return <StaffSidebar activeModule={activeModule} setActiveModule={setActiveModule} onLogout={handleLogout} />;
    } else if (user?.type === 'admin') {
      return <AdminSidebar activeModule={activeModule} setActiveModule={setActiveModule} onLogout={handleLogout} />;
    }
    return null;
  };

  const renderMainContent = () => {
    if (user?.type === 'student') {
      return renderStudentModule();
    } else if (user?.type === 'staff') {
      return renderStaffModule();
    } else if (user?.type === 'admin') {
      return renderAdminModule();
    }
    return null;
  };

  // Show landing page if no user is logged in
  if (!user) {
    return (
      <>
        <LandingPage 
          onEnquireNow={() => setIsEnquireModalOpen(true)}
          onLogin={() => setIsLoginModalOpen(true)}
          onBookAppointment={() => setIsAppointmentModalOpen(true)}
        />
        <LoginModal
          isOpen={isLoginModalOpen}
          onClose={() => setIsLoginModalOpen(false)}
          onLogin={handleLogin}
        />
        <EnquireModal
          isOpen={isEnquireModalOpen}
          onClose={() => setIsEnquireModalOpen(false)}
        />
        <AppointmentModal
          isOpen={isAppointmentModalOpen}
          onClose={() => setIsAppointmentModalOpen(false)}
        />
      </>
    );
  }

  // Show appropriate dashboard based on user type
  return (
    <div className="flex h-screen bg-background">
      {renderSidebar()}
      <main className="flex-1 overflow-auto p-6">
        {renderMainContent()}
      </main>
    </div>
  );
}