import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { 
  Search, 
  Filter, 
  Mail, 
  Phone, 
  Calendar,
  BookOpen,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
  MessageCircle,
  FileText,
  User,
  MapPin,
  Star,
  Target,
  Award
} from 'lucide-react';

interface Student {
  id: string;
  name: string;
  email: string;
  parentEmail: string;
  parentPhone: string;
  address: string;
  subjects: string[];
  teacher: string;
  grade: string;
  attendance: number;
  averageGrade: string;
  recentPerformance: {
    subject: string;
    assignment: string;
    score: number;
    maxScore: number;
    date: string;
  }[];
  nextAssignment?: {
    title: string;
    dueDate: string;
    subject: string;
  };
  notes: string[];
  status: 'active' | 'needs-attention' | 'excellent';
  lastContact: string;
}

export function StaffStudents() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('all');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  // Mock data for 25 Grade 7 students
  const students: Student[] = [
    // Mathematics Students (Ms. Sarah Williams)
    {
      id: '1',
      name: 'Emma Thompson',
      email: 'emma.thompson@student.co.nz',
      parentEmail: 'j.thompson@email.co.nz',
      parentPhone: '021 123 4567',
      address: 'Fendalton, Christchurch',
      subjects: ['Mathematics'],
      teacher: 'Ms. Sarah Williams',
      grade: 'Grade 7',
      attendance: 95,
      averageGrade: 'A-',
      recentPerformance: [
        { subject: 'Mathematics', assignment: 'Fractions Test', score: 23, maxScore: 25, date: '2024-09-20' },
        { subject: 'Mathematics', assignment: 'Geometry Quiz', score: 18, maxScore: 20, date: '2024-09-15' }
      ],
      nextAssignment: { title: 'Decimals Worksheet', dueDate: '2024-09-28', subject: 'Mathematics' },
      notes: ['Excellent problem-solving skills', 'Shows work clearly'],
      status: 'excellent',
      lastContact: '2024-09-18'
    },
    {
      id: '2',
      name: 'Liam Patel',
      email: 'liam.patel@student.co.nz',
      parentEmail: 'r.patel@email.co.nz',
      parentPhone: '021 234 5678',
      address: 'Riccarton, Christchurch',
      subjects: ['Mathematics'],
      teacher: 'Ms. Sarah Williams',
      grade: 'Grade 7',
      attendance: 88,
      averageGrade: 'B+',
      recentPerformance: [
        { subject: 'Mathematics', assignment: 'Fractions Test', score: 20, maxScore: 25, date: '2024-09-20' },
        { subject: 'Mathematics', assignment: 'Geometry Quiz', score: 16, maxScore: 20, date: '2024-09-15' }
      ],
      nextAssignment: { title: 'Decimals Worksheet', dueDate: '2024-09-28', subject: 'Mathematics' },
      notes: ['Needs extra help with word problems', 'Improving steadily'],
      status: 'active',
      lastContact: '2024-09-16'
    },
    {
      id: '3',
      name: 'Sophia Chen',
      email: 'sophia.chen@student.co.nz',
      parentEmail: 'l.chen@email.co.nz',
      parentPhone: '021 345 6789',
      address: 'Ilam, Christchurch',
      subjects: ['Mathematics'],
      teacher: 'Ms. Sarah Williams',
      grade: 'Grade 7',
      attendance: 92,
      averageGrade: 'A',
      recentPerformance: [
        { subject: 'Mathematics', assignment: 'Fractions Test', score: 25, maxScore: 25, date: '2024-09-20' },
        { subject: 'Mathematics', assignment: 'Geometry Quiz', score: 19, maxScore: 20, date: '2024-09-15' }
      ],
      nextAssignment: { title: 'Decimals Worksheet', dueDate: '2024-09-28', subject: 'Mathematics' },
      notes: ['Natural mathematician', 'Helps other students'],
      status: 'excellent',
      lastContact: '2024-09-19'
    },
    {
      id: '4',
      name: 'Mason Williams',
      email: 'mason.williams@student.co.nz',
      parentEmail: 's.williams@email.co.nz',
      parentPhone: '021 456 7890',
      address: 'Merivale, Christchurch',
      subjects: ['Mathematics'],
      teacher: 'Ms. Sarah Williams',
      grade: 'Grade 7',
      attendance: 78,
      averageGrade: 'C+',
      recentPerformance: [
        { subject: 'Mathematics', assignment: 'Fractions Test', score: 15, maxScore: 25, date: '2024-09-20' },
        { subject: 'Mathematics', assignment: 'Geometry Quiz', score: 12, maxScore: 20, date: '2024-09-15' }
      ],
      nextAssignment: { title: 'Decimals Worksheet', dueDate: '2024-09-28', subject: 'Mathematics' },
      notes: ['Struggles with attendance', 'Needs consistent practice'],
      status: 'needs-attention',
      lastContact: '2024-09-14'
    },
    {
      id: '5',
      name: 'Aria Kumar',
      email: 'aria.kumar@student.co.nz',
      parentEmail: 'p.kumar@email.co.nz',
      parentPhone: '021 567 8901',
      address: 'Burnside, Christchurch',
      subjects: ['Mathematics'],
      teacher: 'Ms. Sarah Williams',
      grade: 'Grade 7',
      attendance: 94,
      averageGrade: 'B',
      recentPerformance: [
        { subject: 'Mathematics', assignment: 'Fractions Test', score: 21, maxScore: 25, date: '2024-09-20' },
        { subject: 'Mathematics', assignment: 'Geometry Quiz', score: 17, maxScore: 20, date: '2024-09-15' }
      ],
      nextAssignment: { title: 'Decimals Worksheet', dueDate: '2024-09-28', subject: 'Mathematics' },
      notes: ['Good effort', 'Asks thoughtful questions'],
      status: 'active',
      lastContact: '2024-09-17'
    },

    // Science Students (Mr. James Thompson)
    {
      id: '6',
      name: 'Oliver Brown',
      email: 'oliver.brown@student.co.nz',
      parentEmail: 'k.brown@email.co.nz',
      parentPhone: '021 678 9012',
      address: 'Papanui, Christchurch',
      subjects: ['Science'],
      teacher: 'Mr. James Thompson',
      grade: 'Grade 7',
      attendance: 91,
      averageGrade: 'A-',
      recentPerformance: [
        { subject: 'Science', assignment: 'Plants Project', score: 28, maxScore: 30, date: '2024-09-22' },
        { subject: 'Science', assignment: 'Animal Quiz', score: 17, maxScore: 20, date: '2024-09-18' }
      ],
      nextAssignment: { title: 'Weather Report', dueDate: '2024-10-01', subject: 'Science' },
      notes: ['Loves experiments', 'Great observation skills'],
      status: 'excellent',
      lastContact: '2024-09-20'
    },
    {
      id: '7',
      name: 'Charlotte Davis',
      email: 'charlotte.davis@student.co.nz',
      parentEmail: 'm.davis@email.co.nz',
      parentPhone: '021 789 0123',
      address: 'Cashmere, Christchurch',
      subjects: ['Science'],
      teacher: 'Mr. James Thompson',
      grade: 'Grade 7',
      attendance: 96,
      averageGrade: 'A',
      recentPerformance: [
        { subject: 'Science', assignment: 'Plants Project', score: 30, maxScore: 30, date: '2024-09-22' },
        { subject: 'Science', assignment: 'Animal Quiz', score: 20, maxScore: 20, date: '2024-09-18' }
      ],
      nextAssignment: { title: 'Weather Report', dueDate: '2024-10-01', subject: 'Science' },
      notes: ['Outstanding student', 'Perfect attendance this term'],
      status: 'excellent',
      lastContact: '2024-09-21'
    },
    {
      id: '8',
      name: 'Ethan Wilson',
      email: 'ethan.wilson@student.co.nz',
      parentEmail: 'd.wilson@email.co.nz',
      parentPhone: '021 890 1234',
      address: 'Shirley, Christchurch',
      subjects: ['Science'],
      teacher: 'Mr. James Thompson',
      grade: 'Grade 7',
      attendance: 85,
      averageGrade: 'B',
      recentPerformance: [
        { subject: 'Science', assignment: 'Plants Project', score: 24, maxScore: 30, date: '2024-09-22' },
        { subject: 'Science', assignment: 'Animal Quiz', score: 15, maxScore: 20, date: '2024-09-18' }
      ],
      nextAssignment: { title: 'Weather Report', dueDate: '2024-10-01', subject: 'Science' },
      notes: ['Practical learner', 'Enjoys hands-on activities'],
      status: 'active',
      lastContact: '2024-09-19'
    },
    {
      id: '9',
      name: 'Isla Anderson',
      email: 'isla.anderson@student.co.nz',
      parentEmail: 'c.anderson@email.co.nz',
      parentPhone: '021 901 2345',
      address: 'St Albans, Christchurch',
      subjects: ['Science'],
      teacher: 'Mr. James Thompson',
      grade: 'Grade 7',
      attendance: 90,
      averageGrade: 'B+',
      recentPerformance: [
        { subject: 'Science', assignment: 'Plants Project', score: 26, maxScore: 30, date: '2024-09-22' },
        { subject: 'Science', assignment: 'Animal Quiz', score: 18, maxScore: 20, date: '2024-09-18' }
      ],
      nextAssignment: { title: 'Weather Report', dueDate: '2024-10-01', subject: 'Science' },
      notes: ['Shows improvement', 'Good teamwork skills'],
      status: 'active',
      lastContact: '2024-09-18'
    },
    {
      id: '10',
      name: 'Noah Taylor',
      email: 'noah.taylor@student.co.nz',
      parentEmail: 'b.taylor@email.co.nz',
      parentPhone: '021 012 3456',
      address: 'Addington, Christchurch',
      subjects: ['Science'],
      teacher: 'Mr. James Thompson',
      grade: 'Grade 7',
      attendance: 82,
      averageGrade: 'C+',
      recentPerformance: [
        { subject: 'Science', assignment: 'Plants Project', score: 20, maxScore: 30, date: '2024-09-22' },
        { subject: 'Science', assignment: 'Animal Quiz', score: 13, maxScore: 20, date: '2024-09-18' }
      ],
      nextAssignment: { title: 'Weather Report', dueDate: '2024-10-01', subject: 'Science' },
      notes: ['Needs encouragement', 'Better with visual aids'],
      status: 'needs-attention',
      lastContact: '2024-09-15'
    },

    // English Students (Ms. Emma Clarke)
    {
      id: '11',
      name: 'Ava Smith',
      email: 'ava.smith@student.co.nz',
      parentEmail: 'j.smith@email.co.nz',
      parentPhone: '021 123 4568',
      address: 'Redwood, Christchurch',
      subjects: ['English'],
      teacher: 'Ms. Emma Clarke',
      grade: 'Grade 7',
      attendance: 93,
      averageGrade: 'A',
      recentPerformance: [
        { subject: 'English', assignment: 'Creative Story', score: 28, maxScore: 30, date: '2024-09-25' },
        { subject: 'English', assignment: 'Reading Quiz', score: 19, maxScore: 20, date: '2024-09-20' }
      ],
      nextAssignment: { title: 'Poetry Analysis', dueDate: '2024-10-03', subject: 'English' },
      notes: ['Excellent writer', 'Creative imagination'],
      status: 'excellent',
      lastContact: '2024-09-23'
    },
    {
      id: '12',
      name: 'Jackson Lee',
      email: 'jackson.lee@student.co.nz',
      parentEmail: 'h.lee@email.co.nz',
      parentPhone: '021 234 5679',
      address: 'Northwood, Christchurch',
      subjects: ['English'],
      teacher: 'Ms. Emma Clarke',
      grade: 'Grade 7',
      attendance: 89,
      averageGrade: 'B+',
      recentPerformance: [
        { subject: 'English', assignment: 'Creative Story', score: 25, maxScore: 30, date: '2024-09-25' },
        { subject: 'English', assignment: 'Reading Quiz', score: 16, maxScore: 20, date: '2024-09-20' }
      ],
      nextAssignment: { title: 'Poetry Analysis', dueDate: '2024-10-03', subject: 'English' },
      notes: ['Good vocabulary', 'Needs work on structure'],
      status: 'active',
      lastContact: '2024-09-21'
    },
    {
      id: '13',
      name: 'Grace Johnson',
      email: 'grace.johnson@student.co.nz',
      parentEmail: 'a.johnson@email.co.nz',
      parentPhone: '021 345 6780',
      address: 'Halswell, Christchurch',
      subjects: ['English'],
      teacher: 'Ms. Emma Clarke',
      grade: 'Grade 7',
      attendance: 97,
      averageGrade: 'A-',
      recentPerformance: [
        { subject: 'English', assignment: 'Creative Story', score: 27, maxScore: 30, date: '2024-09-25' },
        { subject: 'English', assignment: 'Reading Quiz', score: 18, maxScore: 20, date: '2024-09-20' }
      ],
      nextAssignment: { title: 'Poetry Analysis', dueDate: '2024-10-03', subject: 'English' },
      notes: ['Great reader', 'Participates well in discussions'],
      status: 'excellent',
      lastContact: '2024-09-24'
    },
    {
      id: '14',
      name: 'Lucas White',
      email: 'lucas.white@student.co.nz',
      parentEmail: 'n.white@email.co.nz',
      parentPhone: '021 456 7891',
      address: 'Wigram, Christchurch',
      subjects: ['English'],
      teacher: 'Ms. Emma Clarke',
      grade: 'Grade 7',
      attendance: 84,
      averageGrade: 'B',
      recentPerformance: [
        { subject: 'English', assignment: 'Creative Story', score: 22, maxScore: 30, date: '2024-09-25' },
        { subject: 'English', assignment: 'Reading Quiz', score: 15, maxScore: 20, date: '2024-09-20' }
      ],
      nextAssignment: { title: 'Poetry Analysis', dueDate: '2024-10-03', subject: 'English' },
      notes: ['Quiet but thoughtful', 'Building confidence'],
      status: 'active',
      lastContact: '2024-09-19'
    },
    {
      id: '15',
      name: 'Mia Garcia',
      email: 'mia.garcia@student.co.nz',
      parentEmail: 'r.garcia@email.co.nz',
      parentPhone: '021 567 8902',
      address: 'Yaldhurst, Christchurch',
      subjects: ['English'],
      teacher: 'Ms. Emma Clarke',
      grade: 'Grade 7',
      attendance: 91,
      averageGrade: 'B+',
      recentPerformance: [
        { subject: 'English', assignment: 'Creative Story', score: 24, maxScore: 30, date: '2024-09-25' },
        { subject: 'English', assignment: 'Reading Quiz', score: 17, maxScore: 20, date: '2024-09-20' }
      ],
      nextAssignment: { title: 'Poetry Analysis', dueDate: '2024-10-03', subject: 'English' },
      notes: ['Shows improvement', 'Enjoys group work'],
      status: 'active',
      lastContact: '2024-09-22'
    },

    // Te Reo Māori Students (Whaea Maria Tane)
    {
      id: '16',
      name: 'Aroha Williams',
      email: 'aroha.williams@student.co.nz',
      parentEmail: 't.williams@email.co.nz',
      parentPhone: '021 678 9013',
      address: 'Linwood, Christchurch',
      subjects: ['Te Reo Māori'],
      teacher: 'Whaea Maria Tane',
      grade: 'Grade 7',
      attendance: 98,
      averageGrade: 'A',
      recentPerformance: [
        { subject: 'Te Reo Māori', assignment: 'Whakapapa Project', score: 19, maxScore: 20, date: '2024-09-26' },
        { subject: 'Te Reo Māori', assignment: 'Vocabulary Test', score: 18, maxScore: 20, date: '2024-09-21' }
      ],
      nextAssignment: { title: 'Māori Legends Presentation', dueDate: '2024-10-05', subject: 'Te Reo Māori' },
      notes: ['Natural pronunciation', 'Cultural understanding'],
      status: 'excellent',
      lastContact: '2024-09-25'
    },
    {
      id: '17',
      name: 'Kai Thompson',
      email: 'kai.thompson@student.co.nz',
      parentEmail: 'p.thompson@email.co.nz',
      parentPhone: '021 789 0124',
      address: 'New Brighton, Christchurch',
      subjects: ['Te Reo Māori'],
      teacher: 'Whaea Maria Tane',
      grade: 'Grade 7',
      attendance: 94,
      averageGrade: 'A-',
      recentPerformance: [
        { subject: 'Te Reo Māori', assignment: 'Whakapapa Project', score: 18, maxScore: 20, date: '2024-09-26' },
        { subject: 'Te Reo Māori', assignment: 'Vocabulary Test', score: 17, maxScore: 20, date: '2024-09-21' }
      ],
      nextAssignment: { title: 'Māori Legends Presentation', dueDate: '2024-10-05', subject: 'Te Reo Māori' },
      notes: ['Enthusiastic learner', 'Good participation'],
      status: 'excellent',
      lastContact: '2024-09-24'
    },
    {
      id: '18',
      name: 'Tama Robinson',
      email: 'tama.robinson@student.co.nz',
      parentEmail: 'k.robinson@email.co.nz',
      parentPhone: '021 890 1235',
      address: 'Aranui, Christchurch',
      subjects: ['Te Reo Māori'],
      teacher: 'Whaea Maria Tane',
      grade: 'Grade 7',
      attendance: 87,
      averageGrade: 'B+',
      recentPerformance: [
        { subject: 'Te Reo Māori', assignment: 'Whakapapa Project', score: 16, maxScore: 20, date: '2024-09-26' },
        { subject: 'Te Reo Māori', assignment: 'Vocabulary Test', score: 15, maxScore: 20, date: '2024-09-21' }
      ],
      nextAssignment: { title: 'Māori Legends Presentation', dueDate: '2024-10-05', subject: 'Te Reo Māori' },
      notes: ['Shows effort', 'Family support helpful'],
      status: 'active',
      lastContact: '2024-09-20'
    },
    {
      id: '19',
      name: 'Ella Mitchell',
      email: 'ella.mitchell@student.co.nz',
      parentEmail: 'f.mitchell@email.co.nz',
      parentPhone: '021 901 2346',
      address: 'Hornby, Christchurch',
      subjects: ['Te Reo Māori'],
      teacher: 'Whaea Maria Tane',
      grade: 'Grade 7',
      attendance: 92,
      averageGrade: 'B',
      recentPerformance: [
        { subject: 'Te Reo Māori', assignment: 'Whakapapa Project', score: 15, maxScore: 20, date: '2024-09-26' },
        { subject: 'Te Reo Māori', assignment: 'Vocabulary Test', score: 16, maxScore: 20, date: '2024-09-21' }
      ],
      nextAssignment: { title: 'Māori Legends Presentation', dueDate: '2024-10-05', subject: 'Te Reo Māori' },
      notes: ['Steady progress', 'Enjoys cultural activities'],
      status: 'active',
      lastContact: '2024-09-22'
    },
    {
      id: '20',
      name: 'Rua Ngata',
      email: 'rua.ngata@student.co.nz',
      parentEmail: 'w.ngata@email.co.nz',
      parentPhone: '021 012 3457',
      address: 'Sydenham, Christchurch',
      subjects: ['Te Reo Māori'],
      teacher: 'Whaea Maria Tane',
      grade: 'Grade 7',
      attendance: 96,
      averageGrade: 'A',
      recentPerformance: [
        { subject: 'Te Reo Māori', assignment: 'Whakapapa Project', score: 20, maxScore: 20, date: '2024-09-26' },
        { subject: 'Te Reo Māori', assignment: 'Vocabulary Test', score: 19, maxScore: 20, date: '2024-09-21' }
      ],
      nextAssignment: { title: 'Māori Legends Presentation', dueDate: '2024-10-05', subject: 'Te Reo Māori' },
      notes: ['Heritage learner', 'Helps other students'],
      status: 'excellent',
      lastContact: '2024-09-26'
    },

    // Multi-subject students
    {
      id: '21',
      name: 'Zoe Baker',
      email: 'zoe.baker@student.co.nz',
      parentEmail: 'g.baker@email.co.nz',
      parentPhone: '021 123 4569',
      address: 'Sumner, Christchurch',
      subjects: ['Mathematics', 'English'],
      teacher: 'Multiple Teachers',
      grade: 'Grade 7',
      attendance: 90,
      averageGrade: 'B+',
      recentPerformance: [
        { subject: 'Mathematics', assignment: 'Fractions Test', score: 21, maxScore: 25, date: '2024-09-20' },
        { subject: 'English', assignment: 'Creative Story', score: 26, maxScore: 30, date: '2024-09-25' }
      ],
      nextAssignment: { title: 'Decimals Worksheet', dueDate: '2024-09-28', subject: 'Mathematics' },
      notes: ['Balanced across subjects', 'Good time management'],
      status: 'active',
      lastContact: '2024-09-23'
    },
    {
      id: '22',
      name: 'Ryan Clark',
      email: 'ryan.clark@student.co.nz',
      parentEmail: 'v.clark@email.co.nz',
      parentPhone: '021 234 5680',
      address: 'Lyttelton, Christchurch',
      subjects: ['Science', 'Te Reo Māori'],
      teacher: 'Multiple Teachers',
      grade: 'Grade 7',
      attendance: 88,
      averageGrade: 'B',
      recentPerformance: [
        { subject: 'Science', assignment: 'Plants Project', score: 25, maxScore: 30, date: '2024-09-22' },
        { subject: 'Te Reo Māori', assignment: 'Whakapapa Project', score: 17, maxScore: 20, date: '2024-09-26' }
      ],
      nextAssignment: { title: 'Weather Report', dueDate: '2024-10-01', subject: 'Science' },
      notes: ['Enjoys practical learning', 'Cultural interest growing'],
      status: 'active',
      lastContact: '2024-09-21'
    },
    {
      id: '23',
      name: 'Sophie Adams',
      email: 'sophie.adams@student.co.nz',
      parentEmail: 'o.adams@email.co.nz',
      parentPhone: '021 345 6781',
      address: 'Diamond Harbour, Christchurch',
      subjects: ['English', 'Science'],
      teacher: 'Multiple Teachers',
      grade: 'Grade 7',
      attendance: 95,
      averageGrade: 'A-',
      recentPerformance: [
        { subject: 'English', assignment: 'Creative Story', score: 28, maxScore: 30, date: '2024-09-25' },
        { subject: 'Science', assignment: 'Plants Project', score: 27, maxScore: 30, date: '2024-09-22' }
      ],
      nextAssignment: { title: 'Poetry Analysis', dueDate: '2024-10-03', subject: 'English' },
      notes: ['Strong analytical skills', 'Cross-curricular connections'],
      status: 'excellent',
      lastContact: '2024-09-24'
    },
    {
      id: '24',
      name: 'Hunter Wilson',
      email: 'hunter.wilson@student.co.nz',
      parentEmail: 'i.wilson@email.co.nz',
      parentPhone: '021 456 7892',
      address: 'Rolleston, Christchurch',
      subjects: ['Mathematics', 'Science'],
      teacher: 'Multiple Teachers',
      grade: 'Grade 7',
      attendance: 86,
      averageGrade: 'B-',
      recentPerformance: [
        { subject: 'Mathematics', assignment: 'Fractions Test', score: 18, maxScore: 25, date: '2024-09-20' },
        { subject: 'Science', assignment: 'Plants Project', score: 22, maxScore: 30, date: '2024-09-22' }
      ],
      nextAssignment: { title: 'Decimals Worksheet', dueDate: '2024-09-28', subject: 'Mathematics' },
      notes: ['Prefers practical work', 'Needs consistent support'],
      status: 'needs-attention',
      lastContact: '2024-09-18'
    },
    {
      id: '25',
      name: 'Chloe Martin',
      email: 'chloe.martin@student.co.nz',
      parentEmail: 'u.martin@email.co.nz',
      parentPhone: '021 567 8903',
      address: 'Prebbleton, Christchurch',
      subjects: ['Mathematics', 'English', 'Science', 'Te Reo Māori'],
      teacher: 'Multiple Teachers',
      grade: 'Grade 7',
      attendance: 93,
      averageGrade: 'A',
      recentPerformance: [
        { subject: 'Mathematics', assignment: 'Fractions Test', score: 24, maxScore: 25, date: '2024-09-20' },
        { subject: 'English', assignment: 'Creative Story', score: 29, maxScore: 30, date: '2024-09-25' },
        { subject: 'Science', assignment: 'Plants Project', score: 29, maxScore: 30, date: '2024-09-22' },
        { subject: 'Te Reo Māori', assignment: 'Whakapapa Project', score: 19, maxScore: 20, date: '2024-09-26' }
      ],
      nextAssignment: { title: 'Decimals Worksheet', dueDate: '2024-09-28', subject: 'Mathematics' },
      notes: ['Exceptional all-round student', 'Leadership potential'],
      status: 'excellent',
      lastContact: '2024-09-26'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'bg-green-100 text-green-800';
      case 'needs-attention': return 'bg-red-100 text-red-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getGradeColor = (grade: string) => {
    if (grade.startsWith('A')) return 'text-green-600';
    if (grade.startsWith('B')) return 'text-blue-600';
    if (grade.startsWith('C')) return 'text-yellow-600';
    return 'text-gray-600';
  };

  const filteredStudents = students.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSubject = selectedSubject === 'all' || student.subjects.includes(selectedSubject);
    return matchesSearch && matchesSubject;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>My Students</h1>
          <p className="text-muted-foreground">
            Manage and track your Grade 7 students' progress
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline" className="flex items-center gap-1">
            <User className="w-3 h-3" />
            {filteredStudents.length} Students
          </Badge>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="flex gap-4 items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Search students..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <select
          value={selectedSubject}
          onChange={(e) => setSelectedSubject(e.target.value)}
          className="px-3 py-2 border rounded-md bg-background"
        >
          <option value="all">All Subjects</option>
          <option value="Mathematics">Mathematics</option>
          <option value="Science">Science</option>
          <option value="English">English</option>
          <option value="Te Reo Māori">Te Reo Māori</option>
        </select>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="communication">Communication</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Students</p>
                    <p className="text-2xl font-bold">{students.length}</p>
                  </div>
                  <User className="w-8 h-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Excellent</p>
                    <p className="text-2xl font-bold text-green-600">
                      {students.filter(s => s.status === 'excellent').length}
                    </p>
                  </div>
                  <Star className="w-8 h-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Need Attention</p>
                    <p className="text-2xl font-bold text-red-600">
                      {students.filter(s => s.status === 'needs-attention').length}
                    </p>
                  </div>
                  <AlertCircle className="w-8 h-8 text-red-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Avg Attendance</p>
                    <p className="text-2xl font-bold">
                      {Math.round(students.reduce((acc, s) => acc + s.attendance, 0) / students.length)}%
                    </p>
                  </div>
                  <Target className="w-8 h-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Students List */}
          <div className="grid gap-4">
            {filteredStudents.map((student) => (
              <Card key={student.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className="bg-gradient-to-br from-blue-100 to-purple-100">
                          {student.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold">{student.name}</h3>
                        <p className="text-sm text-muted-foreground">{student.email}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge className={getStatusColor(student.status)}>
                            {student.status === 'needs-attention' ? 'Needs Attention' : 
                             student.status === 'excellent' ? 'Excellent' : 'Active'}
                          </Badge>
                          <Badge variant="outline" className={getGradeColor(student.averageGrade)}>
                            {student.averageGrade}
                          </Badge>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {student.subjects.map((subject, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {subject}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="text-right space-y-2">
                      <div className="flex items-center gap-1 text-sm">
                        <Target className="w-3 h-3" />
                        {student.attendance}% attendance
                      </div>
                      {student.nextAssignment && (
                        <div className="text-xs text-muted-foreground">
                          Next: {student.nextAssignment.title}
                        </div>
                      )}
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline">
                          <MessageCircle className="w-3 h-3 mr-1" />
                          Contact
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setSelectedStudent(student)}>
                          View Details
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  {student.notes.length > 0 && (
                    <div className="mt-4 p-3 bg-muted/30 rounded-lg">
                      <p className="text-sm">
                        <span className="font-medium">Notes: </span>
                        {student.notes.join(', ')}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid gap-4">
            {filteredStudents.map((student) => (
              <Card key={student.id}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{student.name}</span>
                    <Badge className={getGradeColor(student.averageGrade)}>
                      Average: {student.averageGrade}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Attendance</span>
                        <span>{student.attendance}%</span>
                      </div>
                      <Progress value={student.attendance} className="h-2" />
                    </div>
                    
                    <div>
                      <h4 className="font-medium mb-2">Recent Performance</h4>
                      <div className="space-y-2">
                        {student.recentPerformance.map((performance, index) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-muted/30 rounded">
                            <div>
                              <span className="text-sm font-medium">{performance.assignment}</span>
                              <span className="text-xs text-muted-foreground ml-2">({performance.subject})</span>
                            </div>
                            <div className="text-right">
                              <div className="text-sm font-medium">
                                {performance.score}/{performance.maxScore}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {new Date(performance.date).toLocaleDateString('en-NZ')}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="communication" className="space-y-4">
          <div className="grid gap-4">
            {filteredStudents.map((student) => (
              <Card key={student.id}>
                <CardHeader>
                  <CardTitle>{student.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium mb-2">Student Contact</h4>
                        <div className="space-y-1 text-sm">
                          <div className="flex items-center gap-2">
                            <Mail className="w-3 h-3" />
                            {student.email}
                          </div>
                          <div className="flex items-center gap-2">
                            <MapPin className="w-3 h-3" />
                            {student.address}
                          </div>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Parent Contact</h4>
                        <div className="space-y-1 text-sm">
                          <div className="flex items-center gap-2">
                            <Mail className="w-3 h-3" />
                            {student.parentEmail}
                          </div>
                          <div className="flex items-center gap-2">
                            <Phone className="w-3 h-3" />
                            {student.parentPhone}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-muted-foreground">
                          Last contact: {new Date(student.lastContact).toLocaleDateString('en-NZ')}
                        </span>
                        <div className="flex gap-2">
                          <Button size="sm">
                            <Mail className="w-3 h-3 mr-1" />
                            Email Student
                          </Button>
                          <Button size="sm" variant="outline">
                            <Phone className="w-3 h-3 mr-1" />
                            Call Parent
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Student Detail Modal */}
      {selectedStudent && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{selectedStudent.name} - Detailed View</span>
                <Button variant="ghost" onClick={() => setSelectedStudent(null)}>
                  ×
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-4">
                <Avatar className="w-16 h-16">
                  <AvatarFallback className="bg-gradient-to-br from-blue-100 to-purple-100 text-lg">
                    {selectedStudent.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-xl font-semibold">{selectedStudent.name}</h3>
                  <p className="text-muted-foreground">{selectedStudent.grade}</p>
                  <Badge className={getStatusColor(selectedStudent.status)}>
                    {selectedStudent.status === 'needs-attention' ? 'Needs Attention' : 
                     selectedStudent.status === 'excellent' ? 'Excellent' : 'Active'}
                  </Badge>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-3">Academic Performance</h4>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Overall Grade</span>
                        <span className={getGradeColor(selectedStudent.averageGrade)}>
                          {selectedStudent.averageGrade}
                        </span>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Attendance</span>
                        <span>{selectedStudent.attendance}%</span>
                      </div>
                      <Progress value={selectedStudent.attendance} className="h-2" />
                    </div>
                    <div>
                      <span className="text-sm font-medium">Subjects:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedStudent.subjects.map((subject, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {subject}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Contact Information</h4>
                  <div className="space-y-2 text-sm">
                    <div><strong>Email:</strong> {selectedStudent.email}</div>
                    <div><strong>Parent Email:</strong> {selectedStudent.parentEmail}</div>
                    <div><strong>Parent Phone:</strong> {selectedStudent.parentPhone}</div>
                    <div><strong>Address:</strong> {selectedStudent.address}</div>
                    <div><strong>Last Contact:</strong> {new Date(selectedStudent.lastContact).toLocaleDateString('en-NZ')}</div>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-3">Recent Performance</h4>
                <div className="space-y-2">
                  {selectedStudent.recentPerformance.map((performance, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                      <div>
                        <div className="font-medium">{performance.assignment}</div>
                        <div className="text-sm text-muted-foreground">{performance.subject}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">
                          {performance.score}/{performance.maxScore}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(performance.date).toLocaleDateString('en-NZ')}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {selectedStudent.notes.length > 0 && (
                <div>
                  <h4 className="font-medium mb-3">Notes</h4>
                  <div className="bg-muted/30 p-3 rounded-lg">
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      {selectedStudent.notes.map((note, index) => (
                        <li key={index}>{note}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                <Button className="flex-1">
                  <Mail className="w-4 h-4 mr-2" />
                  Email Student
                </Button>
                <Button variant="outline" className="flex-1">
                  <Phone className="w-4 h-4 mr-2" />
                  Call Parent
                </Button>
                <Button variant="outline" className="flex-1">
                  <FileText className="w-4 h-4 mr-2" />
                  Add Note
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}