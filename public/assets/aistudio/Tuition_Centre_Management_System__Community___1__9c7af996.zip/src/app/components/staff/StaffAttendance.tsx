import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Calendar } from '../ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  Calendar as CalendarIcon,
  Clock,
  Users,
  CheckCircle,
  XCircle,
  AlertCircle,
  Save,
  Download,
  Filter,
  TrendingUp,
  TrendingDown,
  BarChart3,
  User
} from 'lucide-react';
import { format } from 'date-fns';

interface Student {
  id: string;
  name: string;
  avatar: string;
  email: string;
  attendanceRate: number;
  status: 'present' | 'absent' | 'late' | 'excused';
  notes?: string;
}

interface ClassSession {
  id: string;
  subject: string;
  className: string;
  date: string;
  time: string;
  duration: string;
  room: string;
  topic: string;
  studentsPresent: number;
  totalStudents: number;
  attendanceMarked: boolean;
}

interface AttendanceRecord {
  date: string;
  subject: string;
  className: string;
  presentCount: number;
  totalCount: number;
  rate: number;
}

export function StaffAttendance() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedClass, setSelectedClass] = useState('grade7a-math');
  const [attendanceData, setAttendanceData] = useState<Record<string, 'present' | 'absent' | 'late' | 'excused'>>({});

  // Demo classes for Ms. Smith Johnson (Grade 7 teacher)
  const classes = [
    { id: 'grade7a-math', name: 'Grade 7A Mathematics', subject: 'Mathematics' },
    { id: 'grade7b-math', name: 'Grade 7B Mathematics', subject: 'Mathematics' },
    { id: 'grade7a-science', name: 'Grade 7A Science', subject: 'Science' },
    { id: 'grade7-english', name: 'Grade 7 English', subject: 'English' },
    { id: 'grade7-maori', name: 'Grade 7 Te Reo Māori', subject: 'Te Reo Māori' }
  ];

  // Demo today's sessions
  const todaySessions: ClassSession[] = [
    {
      id: '1',
      subject: 'Mathematics',
      className: 'Grade 7A Mathematics',
      date: '2024-09-26',
      time: '9:00 AM - 10:00 AM',
      duration: '60 minutes',
      room: 'Room 101',
      topic: 'Adding and Subtracting Fractions',
      studentsPresent: 23,
      totalStudents: 25,
      attendanceMarked: true
    },
    {
      id: '2',
      subject: 'Science',
      className: 'Grade 7B Science',
      date: '2024-09-26',
      time: '2:00 PM - 3:00 PM',
      duration: '60 minutes',
      room: 'Science Lab',
      topic: 'Plant Parts and Functions',
      studentsPresent: 0,
      totalStudents: 20,
      attendanceMarked: false
    }
  ];

  // Demo students for Grade 7A Mathematics
  const students: Student[] = [
    {
      id: '1',
      name: 'Sarah Chen',
      avatar: 'SC',
      email: 'sarah.chen@student.ilamtuition.co.nz',
      attendanceRate: 96,
      status: 'present'
    },
    {
      id: '2',
      name: 'Michael Zhang',
      avatar: 'MZ',
      email: 'michael.zhang@student.ilamtuition.co.nz',
      attendanceRate: 92,
      status: 'present'
    },
    {
      id: '3',
      name: 'Emma Wilson',
      avatar: 'EW',
      email: 'emma.wilson@student.ilamtuition.co.nz',
      attendanceRate: 88,
      status: 'late',
      notes: 'Arrived 10 minutes late due to transport'
    },
    {
      id: '4',
      name: 'James Liu',
      avatar: 'JL',
      email: 'james.liu@student.ilamtuition.co.nz',
      attendanceRate: 94,
      status: 'present'
    },
    {
      id: '5',
      name: 'Amy Chen',
      avatar: 'AC',
      email: 'amy.chen@student.ilamtuition.co.nz',
      attendanceRate: 85,
      status: 'absent'
    },
    {
      id: '6',
      name: 'David Kim',
      avatar: 'DK',
      email: 'david.kim@student.ilamtuition.co.nz',
      attendanceRate: 90,
      status: 'present'
    },
    {
      id: '7',
      name: 'Lisa Patel',
      avatar: 'LP',
      email: 'lisa.patel@student.ilamtuition.co.nz',
      attendanceRate: 98,
      status: 'present'
    },
    {
      id: '8',
      name: 'Tom Wilson',
      avatar: 'TW',
      email: 'tom.wilson@student.ilamtuition.co.nz',
      attendanceRate: 87,
      status: 'present'
    },
    {
      id: '9',
      name: 'Anna Davis',
      avatar: 'AD',
      email: 'anna.davis@student.ilamtuition.co.nz',
      attendanceRate: 91,
      status: 'present'
    },
    {
      id: '10',
      name: 'Kevin Lee',
      avatar: 'KL',
      email: 'kevin.lee@student.ilamtuition.co.nz',
      attendanceRate: 89,
      status: 'present'
    },
    {
      id: '11',
      name: 'Sophie Brown',
      avatar: 'SB',
      email: 'sophie.brown@student.ilamtuition.co.nz',
      attendanceRate: 93,
      status: 'present'
    },
    {
      id: '12',
      name: 'Ryan Taylor',
      avatar: 'RT',
      email: 'ryan.taylor@student.ilamtuition.co.nz',
      attendanceRate: 84,
      status: 'excused',
      notes: 'Medical appointment - pre-approved absence'
    }
  ];

  // Demo attendance history
  const attendanceHistory: AttendanceRecord[] = [
    { date: '2024-09-26', subject: 'Mathematics', className: 'Grade 7A Mathematics', presentCount: 23, totalCount: 25, rate: 92 },
    { date: '2024-09-24', subject: 'Mathematics', className: 'Grade 7A Mathematics', presentCount: 25, totalCount: 25, rate: 100 },
    { date: '2024-09-22', subject: 'Mathematics', className: 'Grade 7A Mathematics', presentCount: 21, totalCount: 25, rate: 84 },
    { date: '2024-09-19', subject: 'Science', className: 'Grade 7B Science', presentCount: 18, totalCount: 20, rate: 90 },
    { date: '2024-09-17', subject: 'Science', className: 'Grade 7B Science', presentCount: 20, totalCount: 20, rate: 100 },
    { date: '2024-09-26', subject: 'English', className: 'Grade 7 English', presentCount: 22, totalCount: 25, rate: 88 },
    { date: '2024-09-24', subject: 'Te Reo Māori', className: 'Grade 7 Te Reo Māori', presentCount: 26, totalCount: 28, rate: 93 },
    { date: '2024-09-22', subject: 'Te Reo Māori', className: 'Grade 7 Te Reo Māori', presentCount: 25, totalCount: 28, rate: 89 }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present': return 'bg-green-100 text-green-800 border-green-200';
      case 'absent': return 'bg-red-100 text-red-800 border-red-200';
      case 'late': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'excused': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getAttendanceRateColor = (rate: number) => {
    if (rate >= 95) return 'text-green-600';
    if (rate >= 85) return 'text-yellow-600';
    return 'text-red-600';
  };

  const handleStatusChange = (studentId: string, status: 'present' | 'absent' | 'late' | 'excused') => {
    setAttendanceData(prev => ({
      ...prev,
      [studentId]: status
    }));
  };

  const calculateTodaysStats = () => {
    const presentCount = students.filter(s => s.status === 'present').length;
    const lateCount = students.filter(s => s.status === 'late').length;
    const absentCount = students.filter(s => s.status === 'absent').length;
    const excusedCount = students.filter(s => s.status === 'excused').length;
    
    return {
      present: presentCount,
      late: lateCount,
      absent: absentCount,
      excused: excusedCount,
      total: students.length,
      rate: Math.round(((presentCount + lateCount) / students.length) * 100)
    };
  };

  const todaysStats = calculateTodaysStats();
  const overallAttendanceRate = Math.round(attendanceHistory.reduce((sum, record) => sum + record.rate, 0) / attendanceHistory.length);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Attendance Management</h1>
          <p className="text-muted-foreground">
            Mark attendance and track student participation in your classes
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline" className="flex items-center gap-1">
            <BarChart3 className="w-3 h-3" />
            {overallAttendanceRate}% Overall Rate
          </Badge>
          <Button size="sm" className="flex items-center gap-1">
            <Save className="w-3 h-3" />
            Save Attendance
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-5">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Present</p>
                <p className="text-2xl font-bold text-green-600">{todaysStats.present}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Late</p>
                <p className="text-2xl font-bold text-orange-600">{todaysStats.late}</p>
              </div>
              <Clock className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Absent</p>
                <p className="text-2xl font-bold text-red-600">{todaysStats.absent}</p>
              </div>
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Excused</p>
                <p className="text-2xl font-bold text-blue-600">{todaysStats.excused}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Attendance Rate</p>
                <p className={`text-2xl font-bold ${getAttendanceRateColor(todaysStats.rate)}`}>{todaysStats.rate}%</p>
              </div>
              <BarChart3 className="w-8 h-8 text-primary" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="today" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="today">Today's Classes</TabsTrigger>
          <TabsTrigger value="mark">Mark Attendance</TabsTrigger>
          <TabsTrigger value="history">Attendance History</TabsTrigger>
        </TabsList>

        <TabsContent value="today" className="space-y-4">
          <div className="space-y-4">
            {todaySessions.map((session) => (
              <Card key={session.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <CardTitle className="text-lg">{session.className}</CardTitle>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {session.time}
                        </span>
                        <span className="flex items-center gap-1">
                          <CalendarIcon className="w-3 h-3" />
                          {session.room}
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {session.studentsPresent}/{session.totalStudents} present
                        </span>
                      </div>
                    </div>
                    <Badge variant="outline" className={session.attendanceMarked ? getStatusColor('present') : 'bg-yellow-100 text-yellow-800 border-yellow-200'}>
                      {session.attendanceMarked ? 'Marked' : 'Pending'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-medium text-sm mb-1">Topic: {session.topic}</h4>
                      <p className="text-sm text-muted-foreground">Duration: {session.duration}</p>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-green-600 h-2 rounded-full" 
                        style={{ width: `${(session.studentsPresent / session.totalStudents) * 100}%` }}
                      ></div>
                    </div>
                    <div className="flex gap-2">
                      {!session.attendanceMarked && (
                        <Button size="sm">Mark Attendance</Button>
                      )}
                      <Button variant="outline" size="sm">View Details</Button>
                      <Button variant="outline" size="sm" className="flex items-center gap-1">
                        <Download className="w-3 h-3" />
                        Export
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="mark" className="space-y-4">
          <div className="flex items-center gap-4 mb-6">
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium">Class:</label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger className="w-60">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {classes.map((cls) => (
                    <SelectItem key={cls.id} value={cls.id}>
                      {cls.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium">Date:</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-40 justify-start text-left">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(selectedDate, 'MMM dd, yyyy')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => date && setSelectedDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Student Attendance - Grade 7A Mathematics</CardTitle>
              <p className="text-sm text-muted-foreground">
                {format(selectedDate, 'EEEE, MMMM dd, yyyy')} • 9:00 AM - 10:00 AM • Room 101
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {students.map((student) => (
                  <div key={student.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback>{student.avatar}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{student.name}</div>
                        <div className="text-sm text-muted-foreground">
                          Overall attendance: <span className={getAttendanceRateColor(student.attendanceRate)}>{student.attendanceRate}%</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant={student.status === 'present' ? 'default' : 'outline'}
                          onClick={() => handleStatusChange(student.id, 'present')}
                          className="flex items-center gap-1"
                        >
                          <CheckCircle className="w-3 h-3" />
                          Present
                        </Button>
                        <Button
                          size="sm"
                          variant={student.status === 'late' ? 'default' : 'outline'}
                          onClick={() => handleStatusChange(student.id, 'late')}
                          className="flex items-center gap-1"
                        >
                          <Clock className="w-3 h-3" />
                          Late
                        </Button>
                        <Button
                          size="sm"
                          variant={student.status === 'absent' ? 'default' : 'outline'}
                          onClick={() => handleStatusChange(student.id, 'absent')}
                          className="flex items-center gap-1"
                        >
                          <XCircle className="w-3 h-3" />
                          Absent
                        </Button>
                        <Button
                          size="sm"
                          variant={student.status === 'excused' ? 'default' : 'outline'}
                          onClick={() => handleStatusChange(student.id, 'excused')}
                          className="flex items-center gap-1"
                        >
                          <AlertCircle className="w-3 h-3" />
                          Excused
                        </Button>
                      </div>
                      <Badge variant="outline" className={getStatusColor(student.status)}>
                        {student.status.charAt(0).toUpperCase() + student.status.slice(1)}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex gap-2 mt-6 pt-4 border-t">
                <Button className="flex items-center gap-1">
                  <Save className="w-3 h-3" />
                  Save Attendance
                </Button>
                <Button variant="outline">Reset</Button>
                <Button variant="outline" className="flex items-center gap-1">
                  <Download className="w-3 h-3" />
                  Export Report
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <div className="flex items-center gap-4 mb-6">
            <Select defaultValue="all">
              <SelectTrigger className="w-60">
                <Filter className="w-3 h-3 mr-1" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                <SelectItem value="mathematics">Mathematics</SelectItem>
                <SelectItem value="science">Science</SelectItem>
                <SelectItem value="english">English</SelectItem>
                <SelectItem value="te-reo-maori">Te Reo Māori</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <Download className="w-3 h-3" />
              Export History
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Attendance History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {attendanceHistory.map((record, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="space-y-1">
                      <div className="font-medium">{record.className}</div>
                      <div className="text-sm text-muted-foreground">
                        {new Date(record.date).toLocaleDateString('en-NZ', { 
                          weekday: 'long', 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">{record.presentCount}/{record.totalCount}</div>
                      <div className={`text-sm ${getAttendanceRateColor(record.rate)}`}>
                        {record.rate}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}