import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { 
  MessageSquare,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  User,
  Calendar,
  BookOpen,
  HelpCircle,
  Filter,
  Send,
  FileText,
  Star,
  Users
} from 'lucide-react';

interface StudentRequest {
  id: string;
  studentName: string;
  studentAvatar: string;
  studentEmail: string;
  requestType: 'booking' | 'help' | 'clarification' | 'makeup' | 'resource';
  title: string;
  description: string;
  subject: string;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  submittedDate: string;
  requestedDate?: string;
  requestedTime?: string;
  attachments?: string[];
  staffResponse?: string;
  responseDate?: string;
}

export function StaffStudentRequests() {
  const [selectedRequest, setSelectedRequest] = useState<StudentRequest | null>(null);
  const [responseText, setResponseText] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  // Demo student requests for Dr. Smith Johnson
  const studentRequests: StudentRequest[] = [
    {
      id: '1',
      studentName: 'Sarah Chen',
      studentAvatar: 'SC',
      studentEmail: 'sarah.chen@student.ilamtuition.co.nz',
      requestType: 'booking',
      title: 'Extra Tutoring Session - Calculus Integration',
      description: 'Hi Dr. Johnson, I\'m struggling with integration by parts and would really appreciate an extra one-on-one session before the upcoming test. I\'ve been practicing but still making errors in choosing u and dv correctly.',
      subject: 'Advanced Mathematics',
      priority: 'high',
      status: 'pending',
      submittedDate: '2024-09-26T14:30:00',
      requestedDate: '2024-09-28',
      requestedTime: '3:00 PM - 4:00 PM'
    },
    {
      id: '2',
      studentName: 'Michael Zhang',
      studentAvatar: 'MZ',
      studentEmail: 'michael.zhang@student.ilamtuition.co.nz',
      requestType: 'help',
      title: 'Assignment Question Clarification',
      description: 'For the trigonometry applications assignment, question 7 about the lighthouse problem - I\'m not sure if I should use sine or cosine for the angle calculation. Could you provide some guidance?',
      subject: 'Advanced Mathematics',
      priority: 'medium',
      status: 'approved',
      submittedDate: '2024-09-25T16:15:00',
      staffResponse: 'Great question! For lighthouse problems, remember to identify which side is opposite to your angle and which is adjacent. In this case, you\'re looking at the height (opposite) and distance (adjacent), so you\'ll want to use tangent. Let\'s discuss this in our next class.',
      responseDate: '2024-09-25T18:20:00'
    },
    {
      id: '3',
      studentName: 'Emma Wilson',
      studentAvatar: 'EW',
      studentEmail: 'emma.wilson@student.ilamtuition.co.nz',
      requestType: 'resource',
      title: 'Additional Practice Problems',
      description: 'Could you recommend some additional quadratic equation practice problems? I feel confident with the basics but want more challenging problems to prepare for university entrance.',
      subject: 'Mathematics Fundamentals',
      priority: 'low',
      status: 'completed',
      submittedDate: '2024-09-24T10:45:00',
      staffResponse: 'I\'ve uploaded a set of advanced quadratic problems to the student portal. These include real-world applications and some competition-style questions. Check the "Additional Resources" section.',
      responseDate: '2024-09-24T13:30:00'
    },
    {
      id: '4',
      studentName: 'James Liu',
      studentAvatar: 'JL',
      studentEmail: 'james.liu@student.ilamtuition.co.nz',
      requestType: 'makeup',
      title: 'Makeup Session for Missed Class',
      description: 'I had to miss last Tuesday\'s class due to a family emergency. Could we arrange a makeup session to cover the differential equations introduction? I have my notes from classmates but would benefit from your explanation.',
      subject: 'Advanced Mathematics',
      priority: 'medium',
      status: 'approved',
      submittedDate: '2024-09-23T09:20:00',
      requestedDate: '2024-09-27',
      requestedTime: '1:00 PM - 2:00 PM',
      staffResponse: 'Absolutely! I\'ve scheduled a makeup session for Friday at 1 PM. We\'ll cover differential equations basics and I\'ll provide additional examples.',
      responseDate: '2024-09-23T11:45:00'
    },
    {
      id: '5',
      studentName: 'Amy Chen',
      studentAvatar: 'AC',
      studentEmail: 'amy.chen@student.ilamtuition.co.nz',
      requestType: 'clarification',
      title: 'Test Format Questions',
      description: 'For the upcoming calculus test, will we need to memorize all integration formulas or will there be a formula sheet provided? Also, are graphing calculators allowed for the graphing section?',
      subject: 'Advanced Mathematics',
      priority: 'medium',
      status: 'pending',
      submittedDate: '2024-09-26T08:15:00'
    },
    {
      id: '6',
      studentName: 'David Kim',
      studentAvatar: 'DK',
      studentEmail: 'david.kim@student.ilamtuition.co.nz',
      requestType: 'booking',
      title: 'Group Study Session Request',
      description: 'Several of us from the fundamentals class would like to organize a group study session before the quadratic test. Could you facilitate or provide guidance for a 2-hour session this weekend?',
      subject: 'Mathematics Fundamentals',
      priority: 'low',
      status: 'pending',
      submittedDate: '2024-09-25T19:30:00',
      requestedDate: '2024-09-28',
      requestedTime: '10:00 AM - 12:00 PM'
    },
    {
      id: '7',
      studentName: 'Lisa Patel',
      studentAvatar: 'LP',
      studentEmail: 'lisa.patel@student.ilamtuition.co.nz',
      requestType: 'help',
      title: 'Career Guidance - Mathematics Pathway',
      description: 'I\'m really enjoying mathematics and considering pursuing it at university. Could we discuss different mathematics career paths and what additional preparations I should consider?',
      subject: 'Advanced Mathematics',
      priority: 'low',
      status: 'approved',
      submittedDate: '2024-09-22T15:45:00',
      staffResponse: 'I\'d love to discuss your mathematics future! There are many exciting paths including pure mathematics, applied mathematics, statistics, actuarial science, and engineering. Let\'s schedule a career chat.',
      responseDate: '2024-09-22T17:15:00'
    },
    {
      id: '8',
      studentName: 'Tom Wilson',
      studentAvatar: 'TW',
      studentEmail: 'tom.wilson@student.ilamtuition.co.nz',
      requestType: 'resource',
      title: 'Online Learning Platforms',
      description: 'Can you recommend some good online platforms or apps for practicing calculus problems? I\'d like to supplement our class work with additional practice during my commute.',
      subject: 'Advanced Mathematics',
      priority: 'low',
      status: 'completed',
      submittedDate: '2024-09-21T12:30:00',
      staffResponse: 'I recommend Khan Academy for foundational review, Wolfram Alpha for checking your work, and PatrickJMT on YouTube for clear explanations. I\'ve also added some app recommendations to the student portal.',
      responseDate: '2024-09-21T14:45:00'
    }
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'booking': return <Calendar className="w-4 h-4" />;
      case 'help': return <HelpCircle className="w-4 h-4" />;
      case 'clarification': return <MessageSquare className="w-4 h-4" />;
      case 'makeup': return <BookOpen className="w-4 h-4" />;
      case 'resource': return <FileText className="w-4 h-4" />;
      default: return <MessageSquare className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'booking': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'help': return 'bg-green-100 text-green-800 border-green-200';
      case 'clarification': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'makeup': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'resource': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'approved': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      case 'completed': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatTypeLabel = (type: string) => {
    switch (type) {
      case 'booking': return 'Session Booking';
      case 'help': return 'Help Request';
      case 'clarification': return 'Clarification';
      case 'makeup': return 'Makeup Session';
      case 'resource': return 'Resource Request';
      default: return 'General';
    }
  };

  const filteredRequests = studentRequests.filter(request => {
    if (filterStatus === 'all') return true;
    return request.status === filterStatus;
  });

  const pendingCount = studentRequests.filter(r => r.status === 'pending').length;
  const highPriorityCount = studentRequests.filter(r => r.priority === 'high' && r.status === 'pending').length;

  const handleResponse = (requestId: string, action: 'approve' | 'reject') => {
    // In a real app, this would make an API call
    console.log(`${action} request ${requestId} with response: ${responseText}`);
    setSelectedRequest(null);
    setResponseText('');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Student Requests</h1>
          <p className="text-muted-foreground">
            Review and respond to student requests for help, bookings, and clarifications
          </p>
        </div>
        <div className="flex gap-2">
          {highPriorityCount > 0 && (
            <Badge variant="outline" className="flex items-center gap-1 bg-red-50 text-red-700 border-red-200">
              <AlertCircle className="w-3 h-3" />
              {highPriorityCount} High Priority
            </Badge>
          )}
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {pendingCount} Pending
          </Badge>
        </div>
      </div>

      {/* Filter and Stats */}
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-40">
              <Filter className="w-3 h-3 mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Requests</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{studentRequests.filter(r => r.requestType === 'booking').length}</div>
            <div className="text-xs text-muted-foreground">Bookings</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{studentRequests.filter(r => r.requestType === 'help').length}</div>
            <div className="text-xs text-muted-foreground">Help</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{studentRequests.filter(r => r.requestType === 'clarification').length}</div>
            <div className="text-xs text-muted-foreground">Clarifications</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{studentRequests.filter(r => r.requestType === 'makeup').length}</div>
            <div className="text-xs text-muted-foreground">Makeup</div>
          </div>
        </div>
      </div>

      {/* Requests List */}
      <div className="space-y-4">
        {filteredRequests.map((request) => (
          <Card key={request.id} className={request.priority === 'high' && request.status === 'pending' ? 'ring-2 ring-red-200' : ''}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-lg">{request.title}</CardTitle>
                    <Badge variant="outline" className={getTypeColor(request.requestType)}>
                      {getTypeIcon(request.requestType)}
                      {formatTypeLabel(request.requestType)}
                    </Badge>
                    <Badge variant="outline" className={getPriorityColor(request.priority)}>
                      {request.priority.toUpperCase()}
                    </Badge>
                    <Badge variant="outline" className={getStatusColor(request.status)}>
                      {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Avatar className="w-4 h-4">
                        <AvatarFallback className="text-xs">{request.studentAvatar}</AvatarFallback>
                      </Avatar>
                      {request.studentName}
                    </span>
                    <span className="flex items-center gap-1">
                      <BookOpen className="w-3 h-3" />
                      {request.subject}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(request.submittedDate).toLocaleDateString('en-NZ')} at {new Date(request.submittedDate).toLocaleTimeString('en-NZ', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedRequest(request)}>
                        View Details
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                          {getTypeIcon(request.requestType)}
                          {request.title}
                        </DialogTitle>
                      </DialogHeader>
                      {selectedRequest && (
                        <div className="space-y-4">
                          <div className="flex items-center gap-4 p-3 bg-muted/30 rounded-lg">
                            <Avatar>
                              <AvatarFallback>{selectedRequest.studentAvatar}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{selectedRequest.studentName}</div>
                              <div className="text-sm text-muted-foreground">{selectedRequest.studentEmail}</div>
                              <div className="text-sm text-muted-foreground">{selectedRequest.subject}</div>
                            </div>
                          </div>
                          
                          <div>
                            <h4 className="font-medium mb-2">Request Details</h4>
                            <p className="text-sm leading-relaxed">{selectedRequest.description}</p>
                          </div>

                          {(selectedRequest.requestedDate || selectedRequest.requestedTime) && (
                            <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                              <h4 className="font-medium text-sm mb-2 text-blue-800">Requested Schedule</h4>
                              <div className="space-y-1 text-sm text-blue-700">
                                {selectedRequest.requestedDate && (
                                  <div className="flex items-center gap-2">
                                    <Calendar className="w-3 h-3" />
                                    <span>{new Date(selectedRequest.requestedDate).toLocaleDateString('en-NZ', { 
                                      weekday: 'long', 
                                      year: 'numeric', 
                                      month: 'long', 
                                      day: 'numeric' 
                                    })}</span>
                                  </div>
                                )}
                                {selectedRequest.requestedTime && (
                                  <div className="flex items-center gap-2">
                                    <Clock className="w-3 h-3" />
                                    <span>{selectedRequest.requestedTime}</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}

                          {selectedRequest.staffResponse && (
                            <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                              <h4 className="font-medium text-sm mb-2 text-green-800">Your Response</h4>
                              <p className="text-sm text-green-700">{selectedRequest.staffResponse}</p>
                              <div className="text-xs text-green-600 mt-2">
                                Responded on {new Date(selectedRequest.responseDate!).toLocaleDateString('en-NZ')}
                              </div>
                            </div>
                          )}

                          {selectedRequest.status === 'pending' && (
                            <div className="space-y-4">
                              <div>
                                <label className="text-sm font-medium mb-2 block">Response</label>
                                <Textarea
                                  value={responseText}
                                  onChange={(e) => setResponseText(e.target.value)}
                                  placeholder="Type your response to the student..."
                                  rows={4}
                                />
                              </div>
                              <div className="flex gap-2">
                                <Button 
                                  onClick={() => handleResponse(selectedRequest.id, 'approve')}
                                  className="flex items-center gap-1"
                                  disabled={!responseText.trim()}
                                >
                                  <CheckCircle className="w-3 h-3" />
                                  Approve & Send
                                </Button>
                                <Button 
                                  variant="outline"
                                  onClick={() => handleResponse(selectedRequest.id, 'reject')}
                                  className="flex items-center gap-1"
                                  disabled={!responseText.trim()}
                                >
                                  <XCircle className="w-3 h-3" />
                                  Decline & Send
                                </Button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>
                  {request.status === 'pending' && (
                    <div className="flex gap-1">
                      <Button size="sm" className="flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" />
                        Approve
                      </Button>
                      <Button variant="outline" size="sm" className="flex items-center gap-1">
                        <XCircle className="w-3 h-3" />
                        Decline
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground line-clamp-2">{request.description}</p>
              
              {request.staffResponse && (
                <div className="mt-3 p-3 bg-muted/30 rounded-lg">
                  <div className="text-xs text-muted-foreground mb-1">Your response:</div>
                  <p className="text-sm">{request.staffResponse}</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredRequests.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No Requests Found</h3>
            <p className="text-muted-foreground">
              {filterStatus === 'all' 
                ? 'No student requests at the moment.'
                : `No ${filterStatus} requests found.`
              }
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}