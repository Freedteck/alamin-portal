import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Calendar } from '../ui/calendar';
import { 
  Calendar as CalendarIcon,
  Clock,
  Users,
  Plus,
  Edit,
  Trash2,
  CheckCircle,
  AlertCircle,
  MessageCircle,
  Bell,
  Filter,
  Search,
  BookOpen,
  Calculator,
  Atom,
  Languages,
  User,
  MapPin,
  Phone,
  Mail
} from 'lucide-react';

interface ClassSlot {
  id: string;
  subject: string;
  teacher: string;
  teacherId: string;
  date: string;
  startTime: string;
  endTime: string;
  duration: number;
  room: string;
  capacity: number;
  enrolledStudents: number;
  students: string[];
  status: 'confirmed' | 'pending' | 'conflict' | 'cancelled';
  notes?: string;
  collaborators?: string[];
  lastUpdated: string;
  updatedBy: string;
}

interface Teacher {
  id: string;
  name: string;
  email: string;
  subjects: string[];
  availability: {
    [day: string]: { start: string; end: string; }[];
  };
  phone: string;
  status: 'available' | 'busy' | 'unavailable';
}

export function StaffScheduler() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [isAddingClass, setIsAddingClass] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<ClassSlot | null>(null);
  const [viewMode, setViewMode] = useState<'week' | 'teacher' | 'room'>('week');
  const [filterSubject, setFilterSubject] = useState('all');

  // Mock teachers data
  const teachers: Teacher[] = [
    {
      id: 'sarah-williams',
      name: 'Ms. Sarah Williams',
      email: 'sarah.williams@ilamtuition.co.nz',
      subjects: ['Mathematics'],
      availability: {
        'Monday': [{ start: '09:00', end: '17:00' }],
        'Tuesday': [{ start: '09:00', end: '17:00' }],
        'Wednesday': [{ start: '13:00', end: '17:00' }],
        'Thursday': [{ start: '09:00', end: '17:00' }],
        'Friday': [{ start: '09:00', end: '15:00' }],
      },
      phone: '021 111 2222',
      status: 'available'
    },
    {
      id: 'james-thompson',
      name: 'Mr. James Thompson',
      email: 'james.thompson@ilamtuition.co.nz',
      subjects: ['Science'],
      availability: {
        'Monday': [{ start: '10:00', end: '18:00' }],
        'Tuesday': [{ start: '09:00', end: '16:00' }],
        'Wednesday': [{ start: '09:00', end: '17:00' }],
        'Thursday': [{ start: '14:00', end: '18:00' }],
        'Friday': [{ start: '09:00', end: '17:00' }],
      },
      phone: '021 333 4444',
      status: 'available'
    },
    {
      id: 'emma-clarke',
      name: 'Ms. Emma Clarke',
      email: 'emma.clarke@ilamtuition.co.nz',
      subjects: ['English'],
      availability: {
        'Monday': [{ start: '09:00', end: '15:00' }],
        'Tuesday': [{ start: '10:00', end: '18:00' }],
        'Wednesday': [{ start: '09:00', end: '17:00' }],
        'Thursday': [{ start: '09:00', end: '17:00' }],
        'Friday': [{ start: '13:00', end: '17:00' }],
      },
      phone: '021 555 6666',
      status: 'busy'
    },
    {
      id: 'maria-tane',
      name: 'Whaea Maria Tane',
      email: 'maria.tane@ilamtuition.co.nz',
      subjects: ['Te Reo Māori'],
      availability: {
        'Monday': [{ start: '11:00', end: '16:00' }],
        'Tuesday': [{ start: '09:00', end: '17:00' }],
        'Wednesday': [{ start: '09:00', end: '15:00' }],
        'Thursday': [{ start: '10:00', end: '17:00' }],
        'Friday': [{ start: '09:00', end: '14:00' }],
      },
      phone: '021 777 8888',
      status: 'available'
    },
    {
      id: 'david-kim',
      name: 'Mr. David Kim',
      email: 'david.kim@ilamtuition.co.nz',
      subjects: ['Mathematics', 'Science'],
      availability: {
        'Monday': [{ start: '14:00', end: '19:00' }],
        'Tuesday': [{ start: '09:00', end: '13:00' }],
        'Wednesday': [{ start: '15:00', end: '19:00' }],
        'Thursday': [{ start: '09:00', end: '17:00' }],
        'Friday': [{ start: '10:00', end: '16:00' }],
      },
      phone: '021 999 0000',
      status: 'available'
    }
  ];

  // Mock class slots for next week
  const [classSlots, setClassSlots] = useState<ClassSlot[]>([
    {
      id: '1',
      subject: 'Mathematics',
      teacher: 'Ms. Sarah Williams',
      teacherId: 'sarah-williams',
      date: '2024-09-30',
      startTime: '09:00',
      endTime: '10:00',
      duration: 60,
      room: 'Room A',
      capacity: 8,
      enrolledStudents: 5,
      students: ['Emma Thompson', 'Liam Patel', 'Sophia Chen', 'Mason Williams', 'Aria Kumar'],
      status: 'confirmed',
      notes: 'Fractions and decimals focus',
      lastUpdated: '2024-09-25T10:30:00Z',
      updatedBy: 'Ms. Sarah Williams'
    },
    {
      id: '2',
      subject: 'Science',
      teacher: 'Mr. James Thompson',
      teacherId: 'james-thompson',
      date: '2024-09-30',
      startTime: '10:30',
      endTime: '11:30',
      duration: 60,
      room: 'Lab 1',
      capacity: 6,
      enrolledStudents: 5,
      students: ['Oliver Brown', 'Charlotte Davis', 'Ethan Wilson', 'Isla Anderson', 'Noah Taylor'],
      status: 'confirmed',
      notes: 'Plant biology experiments',
      lastUpdated: '2024-09-24T15:20:00Z',
      updatedBy: 'Mr. James Thompson'
    },
    {
      id: '3',
      subject: 'English',
      teacher: 'Ms. Emma Clarke',
      teacherId: 'emma-clarke',
      date: '2024-09-30',
      startTime: '14:00',
      endTime: '15:00',
      duration: 60,
      room: 'Room B',
      capacity: 8,
      enrolledStudents: 6,
      students: ['Ava Smith', 'Jackson Lee', 'Grace Johnson', 'Lucas White', 'Mia Garcia', 'Zoe Baker'],
      status: 'pending',
      notes: 'Poetry analysis workshop',
      collaborators: ['sarah-williams'],
      lastUpdated: '2024-09-23T09:15:00Z',
      updatedBy: 'Ms. Emma Clarke'
    },
    {
      id: '4',
      subject: 'Te Reo Māori',
      teacher: 'Whaea Maria Tane',
      teacherId: 'maria-tane',
      date: '2024-10-01',
      startTime: '11:00',
      endTime: '12:00',
      duration: 60,
      room: 'Cultural Room',
      capacity: 10,
      enrolledStudents: 7,
      students: ['Aroha Williams', 'Kai Thompson', 'Tama Robinson', 'Ella Mitchell', 'Rua Ngata', 'Ryan Clark', 'Chloe Martin'],
      status: 'confirmed',
      notes: 'Māori legends storytelling',
      lastUpdated: '2024-09-25T14:45:00Z',
      updatedBy: 'Whaea Maria Tane'
    },
    {
      id: '5',
      subject: 'Mathematics',
      teacher: 'Mr. David Kim',
      teacherId: 'david-kim',
      date: '2024-10-02',
      startTime: '15:00',
      endTime: '16:00',
      duration: 60,
      room: 'Room A',
      capacity: 8,
      enrolledStudents: 4,
      students: ['Hunter Wilson', 'Sophie Adams', 'Ryan Clark', 'Chloe Martin'],
      status: 'conflict',
      notes: 'Geometry basics - CONFLICT: Room A already booked',
      lastUpdated: '2024-09-25T16:30:00Z',
      updatedBy: 'Mr. David Kim'
    }
  ]);

  const getNextWeekDates = () => {
    const today = new Date();
    const nextMonday = new Date(today);
    nextMonday.setDate(today.getDate() + (1 + 7 - today.getDay()) % 7);
    
    const dates = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date(nextMonday);
      date.setDate(nextMonday.getDate() + i);
      dates.push(date);
    }
    return dates;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'conflict': return 'bg-red-100 text-red-800';
      case 'cancelled': return 'bg-gray-100 text-gray-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getSubjectIcon = (subject: string) => {
    switch (subject) {
      case 'Mathematics': return <Calculator className="w-4 h-4" />;
      case 'Science': return <Atom className="w-4 h-4" />;
      case 'English': return <BookOpen className="w-4 h-4" />;
      case 'Te Reo Māori': return <Languages className="w-4 h-4" />;
      default: return <BookOpen className="w-4 h-4" />;
    }
  };

  const getTeacherStatus = (teacherId: string) => {
    const teacher = teachers.find(t => t.id === teacherId);
    return teacher?.status || 'unavailable';
  };

  const nextWeekDates = getNextWeekDates();
  
  const filteredSlots = classSlots.filter(slot => 
    filterSubject === 'all' || slot.subject === filterSubject
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>📅 Schedule Classes</h1>
          <p className="text-muted-foreground">
            Collaborate with other staff to coordinate next week's class timetable
          </p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isAddingClass} onOpenChange={setIsAddingClass}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Add Class
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Schedule New Class</DialogTitle>
              </DialogHeader>
              <AddClassForm onClose={() => setIsAddingClass(false)} teachers={teachers} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filters and Views */}
      <div className="flex gap-4 items-center">
        <Select value={filterSubject} onValueChange={setFilterSubject}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filter by subject" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Subjects</SelectItem>
            <SelectItem value="Mathematics">Mathematics</SelectItem>
            <SelectItem value="Science">Science</SelectItem>
            <SelectItem value="English">English</SelectItem>
            <SelectItem value="Te Reo Māori">Te Reo Māori</SelectItem>
          </SelectContent>
        </Select>
        
        <div className="flex bg-muted p-1 rounded-lg">
          <Button
            variant={viewMode === 'week' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('week')}
          >
            Week View
          </Button>
          <Button
            variant={viewMode === 'teacher' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('teacher')}
          >
            By Teacher
          </Button>
          <Button
            variant={viewMode === 'room' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('room')}
          >
            By Room
          </Button>
        </div>
      </div>

      <Tabs defaultValue="schedule" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="schedule">📋 Schedule</TabsTrigger>
          <TabsTrigger value="teachers">👥 Teachers</TabsTrigger>
          <TabsTrigger value="collaboration">🤝 Collaboration</TabsTrigger>
        </TabsList>

        <TabsContent value="schedule" className="space-y-4">
          {viewMode === 'week' && (
            <div className="space-y-4">
              <div className="grid grid-cols-8 gap-2">
                <div className="font-medium p-3">Time</div>
                {nextWeekDates.map((date, index) => (
                  <div key={index} className="font-medium p-3 text-center">
                    <div>{['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][index]}</div>
                    <div className="text-sm text-muted-foreground">
                      {date.getDate()}/{date.getMonth() + 1}
                    </div>
                  </div>
                ))}
              </div>

              {/* Time slots */}
              {Array.from({ length: 10 }, (_, i) => {
                const hour = 9 + i;
                const timeSlot = `${hour.toString().padStart(2, '0')}:00`;
                
                return (
                  <div key={timeSlot} className="grid grid-cols-8 gap-2 min-h-16">
                    <div className="flex items-center p-3 text-sm text-muted-foreground">
                      {timeSlot}
                    </div>
                    {nextWeekDates.map((date, dayIndex) => {
                      const dateStr = date.toISOString().split('T')[0];
                      const daySlots = filteredSlots.filter(slot => 
                        slot.date === dateStr && 
                        slot.startTime === timeSlot
                      );
                      
                      return (
                        <div key={dayIndex} className="p-1">
                          {daySlots.map((slot) => (
                            <Card 
                              key={slot.id} 
                              className="cursor-pointer hover:shadow-md transition-shadow p-2 mb-1"
                              onClick={() => setSelectedSlot(slot)}
                            >
                              <div className="space-y-1">
                                <div className="flex items-center gap-1">
                                  {getSubjectIcon(slot.subject)}
                                  <span className="text-xs font-medium truncate">
                                    {slot.subject}
                                  </span>
                                </div>
                                <div className="text-xs text-muted-foreground truncate">
                                  {slot.teacher}
                                </div>
                                <div className="flex items-center justify-between">
                                  <Badge className={`${getStatusColor(slot.status)} text-xs`}>
                                    {slot.status}
                                  </Badge>
                                  <span className="text-xs">
                                    {slot.enrolledStudents}/{slot.capacity}
                                  </span>
                                </div>
                              </div>
                            </Card>
                          ))}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          )}

          {viewMode === 'teacher' && (
            <div className="grid gap-4">
              {teachers.map((teacher) => {
                const teacherSlots = filteredSlots.filter(slot => slot.teacherId === teacher.id);
                return (
                  <Card key={teacher.id}>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback>
                              {teacher.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div>{teacher.name}</div>
                            <div className="text-sm text-muted-foreground">
                              {teacher.subjects.join(', ')}
                            </div>
                          </div>
                        </div>
                        <Badge className={
                          teacher.status === 'available' ? 'bg-green-100 text-green-800' :
                          teacher.status === 'busy' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }>
                          {teacher.status}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {teacherSlots.length > 0 ? (
                          teacherSlots.map((slot) => (
                            <div 
                              key={slot.id}
                              className="flex items-center justify-between p-3 bg-muted/30 rounded-lg cursor-pointer hover:bg-muted/50"
                              onClick={() => setSelectedSlot(slot)}
                            >
                              <div className="flex items-center gap-3">
                                {getSubjectIcon(slot.subject)}
                                <div>
                                  <div className="font-medium">{slot.subject}</div>
                                  <div className="text-sm text-muted-foreground">
                                    {new Date(slot.date).toLocaleDateString('en-NZ', { weekday: 'short', day: 'numeric', month: 'short' })} • 
                                    {slot.startTime} - {slot.endTime} • {slot.room}
                                  </div>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge className={getStatusColor(slot.status)}>
                                  {slot.status}
                                </Badge>
                                <span className="text-sm text-muted-foreground">
                                  {slot.enrolledStudents}/{slot.capacity}
                                </span>
                              </div>
                            </div>
                          ))
                        ) : (
                          <p className="text-muted-foreground text-center py-4">
                            No classes scheduled for next week
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}

          {viewMode === 'room' && (
            <div className="grid gap-4">
              {['Room A', 'Room B', 'Lab 1', 'Cultural Room', 'Study Room'].map((room) => {
                const roomSlots = filteredSlots.filter(slot => slot.room === room);
                return (
                  <Card key={room}>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <MapPin className="w-5 h-5" />
                        {room}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {roomSlots.length > 0 ? (
                          roomSlots.map((slot) => (
                            <div 
                              key={slot.id}
                              className="flex items-center justify-between p-3 bg-muted/30 rounded-lg cursor-pointer hover:bg-muted/50"
                              onClick={() => setSelectedSlot(slot)}
                            >
                              <div className="flex items-center gap-3">
                                {getSubjectIcon(slot.subject)}
                                <div>
                                  <div className="font-medium">{slot.subject} - {slot.teacher}</div>
                                  <div className="text-sm text-muted-foreground">
                                    {new Date(slot.date).toLocaleDateString('en-NZ', { weekday: 'short', day: 'numeric', month: 'short' })} • 
                                    {slot.startTime} - {slot.endTime}
                                  </div>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge className={getStatusColor(slot.status)}>
                                  {slot.status}
                                </Badge>
                                <span className="text-sm text-muted-foreground">
                                  {slot.enrolledStudents}/{slot.capacity}
                                </span>
                              </div>
                            </div>
                          ))
                        ) : (
                          <p className="text-muted-foreground text-center py-4">
                            No classes scheduled in this room
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="teachers" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            {teachers.map((teacher) => (
              <Card key={teacher.id}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className="bg-gradient-to-br from-blue-100 to-purple-100">
                          {teacher.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div>{teacher.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {teacher.subjects.join(', ')}
                        </div>
                      </div>
                    </div>
                    <Badge className={
                      teacher.status === 'available' ? 'bg-green-100 text-green-800' :
                      teacher.status === 'busy' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }>
                      {teacher.status}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Mail className="w-3 h-3" />
                      {teacher.email}
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-3 h-3" />
                      {teacher.phone}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">📅 Weekly Availability</h4>
                    <div className="space-y-1 text-sm">
                      {Object.entries(teacher.availability).map(([day, slots]) => (
                        <div key={day} className="flex justify-between">
                          <span className="font-medium">{day}:</span>
                          <span className="text-muted-foreground">
                            {slots.map(slot => `${slot.start}-${slot.end}`).join(', ')}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      <MessageCircle className="w-3 h-3 mr-1" />
                      Message
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      <CalendarIcon className="w-3 h-3 mr-1" />
                      Schedule
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="collaboration" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Recent Activity & Notifications
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <div className="font-medium">Class Confirmed</div>
                    <div className="text-sm text-muted-foreground">
                      Ms. Emma Clarke confirmed English class for Monday 2:00 PM
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">2 hours ago</div>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
                  <div>
                    <div className="font-medium">Room Conflict Detected</div>
                    <div className="text-sm text-muted-foreground">
                      Mr. David Kim's Mathematics class conflicts with Room A booking
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">1 day ago</div>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                  <MessageCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <div className="font-medium">Collaboration Request</div>
                    <div className="text-sm text-muted-foreground">
                      Whaea Maria Tane requests collaboration for Te Reo Māori cultural week
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">3 days ago</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>🤝 Collaboration Requests</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-medium">Cross-Subject Project</div>
                    <Badge variant="outline">Pending</Badge>
                  </div>
                  <div className="text-sm text-muted-foreground mb-3">
                    Ms. Emma Clarke wants to collaborate on a Science-English project about environmental writing.
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm">Accept</Button>
                    <Button size="sm" variant="outline">Discuss</Button>
                    <Button size="sm" variant="ghost">Decline</Button>
                  </div>
                </div>
                
                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-medium">Resource Sharing</div>
                    <Badge variant="outline">New</Badge>
                  </div>
                  <div className="text-sm text-muted-foreground mb-3">
                    Mr. James Thompson offers to share laboratory equipment for mathematics geometry lessons.
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm">Accept</Button>
                    <Button size="sm" variant="outline">View Details</Button>
                    <Button size="sm" variant="ghost">Later</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Class Detail Modal */}
      {selectedSlot && (
        <ClassDetailModal 
          slot={selectedSlot} 
          onClose={() => setSelectedSlot(null)}
          teachers={teachers}
        />
      )}
    </div>
  );
}

function AddClassForm({ onClose, teachers }: { onClose: () => void; teachers: Teacher[] }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Subject</Label>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Select subject" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="mathematics">Mathematics</SelectItem>
              <SelectItem value="science">Science</SelectItem>
              <SelectItem value="english">English</SelectItem>
              <SelectItem value="te-reo-maori">Te Reo Māori</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Teacher</Label>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Select teacher" />
            </SelectTrigger>
            <SelectContent>
              {teachers.map(teacher => (
                <SelectItem key={teacher.id} value={teacher.id}>
                  {teacher.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label>Date</Label>
          <Input type="date" />
        </div>
        <div>
          <Label>Start Time</Label>
          <Input type="time" />
        </div>
        <div>
          <Label>End Time</Label>
          <Input type="time" />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Room</Label>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Select room" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="room-a">Room A</SelectItem>
              <SelectItem value="room-b">Room B</SelectItem>
              <SelectItem value="lab-1">Lab 1</SelectItem>
              <SelectItem value="cultural-room">Cultural Room</SelectItem>
              <SelectItem value="study-room">Study Room</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Capacity</Label>
          <Input type="number" placeholder="Max students" />
        </div>
      </div>
      
      <div>
        <Label>Notes</Label>
        <Textarea placeholder="Additional notes for this class..." />
      </div>
      
      <div className="flex gap-2 justify-end">
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={onClose}>Schedule Class</Button>
      </div>
    </div>
  );
}

function ClassDetailModal({ slot, onClose, teachers }: { slot: ClassSlot; onClose: () => void; teachers: Teacher[] }) {
  const teacher = teachers.find(t => t.id === slot.teacherId);
  
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {slot.subject === 'Mathematics' && <Calculator className="w-5 h-5" />}
            {slot.subject === 'Science' && <Atom className="w-5 h-5" />}
            {slot.subject === 'English' && <BookOpen className="w-5 h-5" />}
            {slot.subject === 'Te Reo Māori' && <Languages className="w-5 h-5" />}
            {slot.subject} Class Details
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium mb-2">📅 Schedule</h4>
              <div className="space-y-1 text-sm">
                <div>Date: {new Date(slot.date).toLocaleDateString('en-NZ', { 
                  weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' 
                })}</div>
                <div>Time: {slot.startTime} - {slot.endTime}</div>
                <div>Duration: {slot.duration} minutes</div>
                <div>Room: {slot.room}</div>
              </div>
            </div>
            <div>
              <h4 className="font-medium mb-2">👨‍🏫 Teacher</h4>
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback>
                    {slot.teacher.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">{slot.teacher}</div>
                  <div className="text-sm text-muted-foreground">{teacher?.email}</div>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium mb-2">👥 Students ({slot.enrolledStudents}/{slot.capacity})</h4>
            <div className="flex flex-wrap gap-2">
              {slot.students.map((student, index) => (
                <Badge key={index} variant="secondary">{student}</Badge>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="font-medium mb-2">📝 Status & Notes</h4>
            <div className="space-y-2">
              <Badge className={slot.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                              slot.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                              slot.status === 'conflict' ? 'bg-red-100 text-red-800' :
                              'bg-gray-100 text-gray-800'}>
                {slot.status.toUpperCase()}
              </Badge>
              {slot.notes && (
                <div className="bg-muted/30 p-3 rounded-lg text-sm">
                  {slot.notes}
                </div>
              )}
            </div>
          </div>
          
          <div className="text-xs text-muted-foreground">
            Last updated: {new Date(slot.lastUpdated).toLocaleString('en-NZ')} by {slot.updatedBy}
          </div>
          
          <div className="flex gap-2">
            <Button className="flex-1">
              <Edit className="w-4 h-4 mr-2" />
              Edit Class
            </Button>
            <Button variant="outline" className="flex-1">
              <MessageCircle className="w-4 h-4 mr-2" />
              Message Teacher
            </Button>
            <Button variant="outline">
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}