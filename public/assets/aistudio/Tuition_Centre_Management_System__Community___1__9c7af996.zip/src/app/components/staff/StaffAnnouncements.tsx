import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Checkbox } from '../ui/checkbox';
import { Calendar } from '../ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { 
  Plus,
  Megaphone,
  Calendar as CalendarIcon,
  Clock,
  Users,
  Send,
  Edit,
  Trash2,
  Eye,
  BookOpen,
  PartyPopper,
  AlertTriangle,
  Info,
  Star,
  Bell,
  Target
} from 'lucide-react';
import { format } from 'date-fns';

interface Announcement {
  id: string;
  title: string;
  content: string;
  type: 'general' | 'event' | 'test' | 'birthday' | 'achievement' | 'urgent';
  author: string;
  date: string;
  expiryDate?: string;
  targetAudience: string[];
  eventDate?: string;
  eventTime?: string;
  location?: string;
  status: 'draft' | 'published' | 'expired';
  views: number;
}

export function StaffAnnouncements() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedExpiryDate, setSelectedExpiryDate] = useState<Date>();

  // Demo announcements created by Dr. Smith Johnson
  const announcements: Announcement[] = [
    {
      id: '1',
      title: '🎉 Monthly Math Challenge - October 2024',
      content: 'Get ready for our exciting monthly math challenge! This month we\'re focusing on calculus problems. Prizes for top 3 performers include scientific calculators and math reference books. All students welcome to participate!',
      type: 'event',
      author: 'Dr. Smith Johnson',
      date: '2024-09-24',
      eventDate: '2024-10-15',
      eventTime: '3:00 PM - 5:00 PM',
      location: 'Main Hall',
      targetAudience: ['All Students', 'Mathematics Students'],
      status: 'published',
      views: 127
    },
    {
      id: '2',
      title: '📝 Grade 7 Math Test Study Guide Available',
      content: 'I\'ve uploaded a study guide for our upcoming fractions and decimals test. It covers adding, subtracting, multiplying and dividing fractions, plus decimal conversions. Please review before our next class.',
      type: 'general',
      author: 'Ms. Smith Johnson',
      date: '2024-09-23',
      targetAudience: ['Grade 7 Math Students'],
      status: 'published',
      views: 45
    },
    {
      id: '3',
      title: '🔬 Extra Help Sessions This Week',
      content: 'For students needing extra help with fractions, I\'m offering additional help sessions this week. Wednesday 3:30-4:30 PM and Friday 3:30-4:30 PM in Room 101. No need to register, just drop in!',
      type: 'event',
      author: 'Ms. Smith Johnson',
      date: '2024-09-22',
      eventDate: '2024-09-25',
      eventTime: '3:30 PM - 4:30 PM',
      location: 'Room 101',
      targetAudience: ['Grade 7 Math Students'],
      status: 'published',
      views: 38
    },
    {
      id: '4',
      title: '⚠️ Class Schedule Change - Friday 27th',
      content: 'Our Friday Grade 7 mathematics class will be moved from 2:00 PM to 3:00 PM due to a school assembly. We\'ll be covering mixed numbers and improper fractions.',
      type: 'urgent',
      author: 'Ms. Smith Johnson',
      date: '2024-09-21',
      expiryDate: '2024-09-27',
      targetAudience: ['Grade 7 Math Students'],
      status: 'published',
      views: 52
    },
    {
      id: '5',
      title: '🏆 Congratulations to Quiz Winners!',
      content: 'Outstanding performance in last week\'s fractions quiz! Special recognition to Sarah Chen (98%), Michael Zhang (95%), and Emma Wilson (92%). Keep up the excellent work!',
      type: 'achievement',
      author: 'Ms. Smith Johnson',
      date: '2024-09-20',
      targetAudience: ['Grade 7 Math Students', 'Grade 7 Science Students'],
      status: 'published',
      views: 73
    },
    {
      id: '6',
      title: '📚 New Math Games in Library',
      content: 'The library has new math games and fraction activities! I particularly recommend "Fraction War" and the decimal place value charts for extra practice at home.',
      type: 'general',
      author: 'Ms. Smith Johnson',
      date: '2024-09-19',
      targetAudience: ['Grade 7 Math Students'],
      status: 'published',
      views: 29
    },
    {
      id: '7',
      title: '🎂 September Birthday Celebrations',
      content: 'Let\'s celebrate our September mathematics stars! Happy birthday to Emma Wilson (Sept 15) and James Liu (Sept 22). Join us for cake in the math department common area during lunch.',
      type: 'birthday',
      author: 'Dr. Smith Johnson',
      date: '2024-09-18',
      eventDate: '2024-09-22',
      eventTime: '12:30 PM',
      location: 'Math Department Common Area',
      targetAudience: ['All Students'],
      status: 'published',
      views: 64
    },
    {
      id: '8',
      title: 'Advanced Physics Integration Workshop',
      content: 'Planning a workshop on how calculus integration applies to physics problems. This will be particularly useful for students taking both subjects.',
      type: 'event',
      author: 'Dr. Smith Johnson',
      date: '2024-09-26',
      eventDate: '2024-10-10',
      targetAudience: ['Advanced Math Students', 'Physics Students'],
      status: 'draft',
      views: 0
    }
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'event': return <CalendarIcon className="w-4 h-4" />;
      case 'test': return <BookOpen className="w-4 h-4" />;
      case 'birthday': return <PartyPopper className="w-4 h-4" />;
      case 'achievement': return <Star className="w-4 h-4" />;
      case 'urgent': return <AlertTriangle className="w-4 h-4" />;
      default: return <Info className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'event': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'test': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'birthday': return 'bg-pink-100 text-pink-800 border-pink-200';
      case 'achievement': return 'bg-green-100 text-green-800 border-green-200';
      case 'urgent': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'published': return 'bg-green-100 text-green-800 border-green-200';
      case 'draft': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'expired': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatTypeLabel = (type: string) => {
    switch (type) {
      case 'test': return 'Exam/Test';
      case 'birthday': return 'Birthday';
      case 'achievement': return 'Achievement';
      case 'urgent': return 'Important';
      case 'event': return 'Event';
      default: return 'General';
    }
  };

  const publishedCount = announcements.filter(a => a.status === 'published').length;
  const draftCount = announcements.filter(a => a.status === 'draft').length;
  const totalViews = announcements.reduce((sum, a) => sum + a.views, 0);

  const audienceOptions = [
    'All Students',
    'Grade 7 Math Students',
    'Grade 7 Science Students',
    'Grade 7 English Students',
    'Grade 7 Te Reo Māori Students',
    'Parents',
    'Staff'
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Announcement Management</h1>
          <p className="text-muted-foreground">
            Create and manage announcements for your students and classes
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline" className="flex items-center gap-1">
            <Eye className="w-3 h-3" />
            {totalViews} Total Views
          </Badge>
          <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-1">
                <Plus className="w-4 h-4" />
                Create Announcement
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Announcement</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="title">Title</Label>
                    <Input id="title" placeholder="Enter announcement title" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="type">Type</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General</SelectItem>
                        <SelectItem value="event">Event</SelectItem>
                        <SelectItem value="test">Exam/Test</SelectItem>
                        <SelectItem value="birthday">Birthday</SelectItem>
                        <SelectItem value="achievement">Achievement</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="content">Content</Label>
                  <Textarea id="content" placeholder="Write your announcement..." rows={4} />
                </div>

                <div className="space-y-2">
                  <Label>Target Audience</Label>
                  <div className="grid gap-2 md:grid-cols-2">
                    {audienceOptions.map((audience) => (
                      <div key={audience} className="flex items-center space-x-2">
                        <Checkbox id={audience} />
                        <Label htmlFor={audience} className="text-sm">{audience}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Event Date (Optional)</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {selectedDate ? format(selectedDate, 'PPP') : 'Pick a date'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={setSelectedDate}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="time">Event Time (Optional)</Label>
                    <Input id="time" placeholder="e.g. 3:00 PM - 5:00 PM" />
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="location">Location (Optional)</Label>
                    <Input id="location" placeholder="e.g. Room 101" />
                  </div>
                  <div className="space-y-2">
                    <Label>Expiry Date (Optional)</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {selectedExpiryDate ? format(selectedExpiryDate, 'PPP') : 'Pick expiry date'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={selectedExpiryDate}
                          onSelect={setSelectedExpiryDate}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button className="flex items-center gap-1">
                    <Send className="w-3 h-3" />
                    Publish Now
                  </Button>
                  <Button variant="outline">Save as Draft</Button>
                  <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>Cancel</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Published</p>
                <p className="text-2xl font-bold text-primary">{publishedCount}</p>
              </div>
              <Megaphone className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Drafts</p>
                <p className="text-2xl font-bold text-primary">{draftCount}</p>
              </div>
              <Edit className="w-8 h-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Views</p>
                <p className="text-2xl font-bold text-primary">{totalViews}</p>
              </div>
              <Eye className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">This Month</p>
                <p className="text-2xl font-bold text-primary">{announcements.filter(a => new Date(a.date).getMonth() === new Date().getMonth()).length}</p>
              </div>
              <CalendarIcon className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="published" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="published">Published</TabsTrigger>
          <TabsTrigger value="draft">Drafts</TabsTrigger>
          <TabsTrigger value="all">All</TabsTrigger>
        </TabsList>

        <TabsContent value="published" className="space-y-4">
          <div className="space-y-4">
            {announcements.filter(a => a.status === 'published').map((announcement) => (
              <Card key={announcement.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-lg">{announcement.title}</CardTitle>
                        <Badge variant="outline" className={getTypeColor(announcement.type)}>
                          {getTypeIcon(announcement.type)}
                          {formatTypeLabel(announcement.type)}
                        </Badge>
                        <Badge variant="outline" className={getStatusColor(announcement.status)}>
                          {announcement.status.charAt(0).toUpperCase() + announcement.status.slice(1)}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(announcement.date).toLocaleDateString('en-NZ')}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="w-3 h-3" />
                          {announcement.views} views
                        </span>
                        <span className="flex items-center gap-1">
                          <Target className="w-3 h-3" />
                          {announcement.targetAudience.length} audience{announcement.targetAudience.length !== 1 ? 's' : ''}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Eye className="w-3 h-3 mr-1" />
                        View
                      </Button>
                      <Button variant="outline" size="sm">
                        <Edit className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                      <Button variant="outline" size="sm">
                        <Trash2 className="w-3 h-3 mr-1" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{announcement.content}</p>
                  
                  {(announcement.eventDate || announcement.location) && (
                    <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                      <h4 className="font-medium text-sm mb-2 text-blue-800">Event Details</h4>
                      <div className="space-y-1 text-sm text-blue-700">
                        {announcement.eventDate && (
                          <div className="flex items-center gap-2">
                            <CalendarIcon className="w-3 h-3" />
                            <span>{new Date(announcement.eventDate).toLocaleDateString('en-NZ', { 
                              weekday: 'long', 
                              year: 'numeric', 
                              month: 'long', 
                              day: 'numeric' 
                            })}</span>
                          </div>
                        )}
                        {announcement.eventTime && (
                          <div className="flex items-center gap-2">
                            <Clock className="w-3 h-3" />
                            <span>{announcement.eventTime}</span>
                          </div>
                        )}
                        {announcement.location && (
                          <div className="flex items-center gap-2">
                            <Target className="w-3 h-3" />
                            <span>{announcement.location}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="flex items-center gap-2">
                    <Users className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Sent to:</span>
                    <div className="flex gap-1">
                      {announcement.targetAudience.map((audience, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {audience}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {announcement.expiryDate && (
                    <div className="text-xs text-muted-foreground border-t pt-2">
                      <span className="flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        Expires on {new Date(announcement.expiryDate).toLocaleDateString('en-NZ')}
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="draft" className="space-y-4">
          <div className="space-y-4">
            {announcements.filter(a => a.status === 'draft').map((announcement) => (
              <Card key={announcement.id} className="border-dashed">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-lg text-muted-foreground">{announcement.title}</CardTitle>
                        <Badge variant="outline" className={getStatusColor(announcement.status)}>
                          Draft
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Created: {new Date(announcement.date).toLocaleDateString('en-NZ')}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" className="flex items-center gap-1">
                        <Send className="w-3 h-3" />
                        Publish
                      </Button>
                      <Button variant="outline" size="sm">
                        <Edit className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{announcement.content}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="all" className="space-y-4">
          <div className="space-y-4">
            {announcements.map((announcement) => (
              <Card key={announcement.id} className={announcement.status === 'draft' ? 'border-dashed' : ''}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2">
                        <CardTitle className={`text-lg ${announcement.status === 'draft' ? 'text-muted-foreground' : ''}`}>
                          {announcement.title}
                        </CardTitle>
                        <Badge variant="outline" className={getTypeColor(announcement.type)}>
                          {getTypeIcon(announcement.type)}
                          {formatTypeLabel(announcement.type)}
                        </Badge>
                        <Badge variant="outline" className={getStatusColor(announcement.status)}>
                          {announcement.status.charAt(0).toUpperCase() + announcement.status.slice(1)}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(announcement.date).toLocaleDateString('en-NZ')}
                        </span>
                        {announcement.status === 'published' && (
                          <span className="flex items-center gap-1">
                            <Eye className="w-3 h-3" />
                            {announcement.views} views
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {announcement.status === 'draft' ? (
                        <Button size="sm" className="flex items-center gap-1">
                          <Send className="w-3 h-3" />
                          Publish
                        </Button>
                      ) : (
                        <Button variant="outline" size="sm">
                          <Eye className="w-3 h-3 mr-1" />
                          View
                        </Button>
                      )}
                      <Button variant="outline" size="sm">
                        <Edit className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground line-clamp-2">{announcement.content}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}