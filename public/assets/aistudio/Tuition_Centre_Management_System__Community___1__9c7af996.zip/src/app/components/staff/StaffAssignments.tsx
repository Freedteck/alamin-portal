import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Calendar } from '../ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { 
  Plus,
  FileText,
  Calendar as CalendarIcon,
  Clock,
  Users,
  CheckCircle,
  AlertCircle,
  Eye,
  Edit,
  Trash2,
  Download,
  Upload,
  Star,
  MessageCircle
} from 'lucide-react';
import { format } from 'date-fns';

interface Assignment {
  id: string;
  title: string;
  description: string;
  subject: string;
  class: string;
  dueDate: string;
  totalMarks: number;
  status: 'draft' | 'published' | 'completed';
  submissionsCount: number;
  totalStudents: number;
  gradedCount: number;
  averageScore?: number;
  createdDate: string;
  instructions: string;
  attachments: string[];
}

interface Submission {
  id: string;
  studentName: string;
  studentAvatar: string;
  submittedDate: string;
  status: 'submitted' | 'graded' | 'late' | 'missing';
  score?: number;
  maxScore: number;
  feedback?: string;
  files: string[];
}

export function StaffAssignments() {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [activeTab, setActiveTab] = useState('all');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // Demo assignments for Ms. Smith Johnson (Grade 7 teacher)
  const assignments: Assignment[] = [
    {
      id: '1',
      title: 'Fractions and Decimals Practice',
      description: 'Practice problems covering adding, subtracting, multiplying and dividing fractions and decimals.',
      subject: 'Mathematics',
      class: 'Grade 7A Mathematics',
      dueDate: '2024-10-15',
      totalMarks: 50,
      status: 'published',
      submissionsCount: 22,
      totalStudents: 25,
      gradedCount: 18,
      averageScore: 87,
      createdDate: '2024-09-20',
      instructions: 'Complete all 20 problems. Show all working steps. Use a calculator only for checking your answers.',
      attachments: ['fractions-worksheet.pdf', 'help-guide.pdf']
    },
    {
      id: '2',
      title: 'Plants and Animals Research Project',
      description: 'Choose a New Zealand native animal or plant and create a poster showing its habitat, diet, and interesting facts.',
      subject: 'Science',
      class: 'Grade 7B Science',
      dueDate: '2024-10-08',
      totalMarks: 40,
      status: 'completed',
      submissionsCount: 20,
      totalStudents: 20,
      gradedCount: 20,
      averageScore: 85,
      createdDate: '2024-09-15',
      instructions: 'Use at least 3 reliable sources. Include pictures and diagrams. Present your poster to the class.',
      attachments: ['research-template.pdf', 'nz-species-list.pdf']
    },
    {
      id: '3',
      title: 'Creative Story Writing',
      description: 'Write an original short story (300-500 words) with a clear beginning, middle, and end.',
      subject: 'English',
      class: 'Grade 7A English',
      dueDate: '2024-10-22',
      totalMarks: 30,
      status: 'published',
      submissionsCount: 18,
      totalStudents: 25,
      gradedCount: 0,
      createdDate: '2024-09-25',
      instructions: 'Include dialogue, descriptive language, and interesting characters. Check spelling and grammar.',
      attachments: ['story-planning-sheet.pdf', 'writing-checklist.pdf']
    },
    {
      id: '4',
      title: 'Whakapapa (Family Tree) Project',
      description: 'Create a simple family tree using Te Reo Māori words for family members.',
      subject: 'Te Reo Māori',
      class: 'Grade 7 Te Reo Māori',
      dueDate: '2024-11-05',
      totalMarks: 25,
      status: 'draft',
      submissionsCount: 0,
      totalStudents: 28,
      gradedCount: 0,
      createdDate: '2024-09-26',
      instructions: 'Include at least 8 family members. Use correct Māori spellings and add pronunciation guides.',
      attachments: []
    }
  ];

  // Demo submissions for the first assignment
  const submissions: Submission[] = [
    {
      id: '1',
      studentName: 'Sarah Chen',
      studentAvatar: 'SC',
      submittedDate: '2024-10-14',
      status: 'graded',
      score: 94,
      maxScore: 100,
      feedback: 'Excellent work! Your integration techniques are very strong. Minor error in problem 12.',
      files: ['sarah_chen_calculus.pdf']
    },
    {
      id: '2',
      studentName: 'Michael Zhang',
      studentAvatar: 'MZ',
      submittedDate: '2024-10-15',
      status: 'graded',
      score: 87,
      maxScore: 100,
      feedback: 'Good understanding of concepts. Work on simplifying final answers.',
      files: ['michael_zhang_calculus.pdf']
    },
    {
      id: '3',
      studentName: 'Emma Wilson',
      studentAvatar: 'EW',
      submittedDate: '2024-10-13',
      status: 'graded',
      score: 92,
      maxScore: 100,
      feedback: 'Very thorough solutions. Excellent presentation and clear working.',
      files: ['emma_wilson_calculus.pdf']
    },
    {
      id: '4',
      studentName: 'James Liu',
      studentAvatar: 'JL',
      submittedDate: '2024-10-15',
      status: 'submitted',
      score: undefined,
      maxScore: 100,
      files: ['james_liu_calculus.pdf']
    },
    {
      id: '5',
      studentName: 'Amy Chen',
      studentAvatar: 'AC',
      submittedDate: '2024-10-16',
      status: 'late',
      score: undefined,
      maxScore: 100,
      files: ['amy_chen_calculus.pdf']
    },
    {
      id: '6',
      studentName: 'David Kim',
      studentAvatar: 'DK',
      submittedDate: '',
      status: 'missing',
      score: undefined,
      maxScore: 100,
      files: []
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'published': return 'bg-green-100 text-green-800 border-green-200';
      case 'completed': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'draft': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getSubmissionStatusColor = (status: string) => {
    switch (status) {
      case 'graded': return 'bg-green-100 text-green-800 border-green-200';
      case 'submitted': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'late': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'missing': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getProgressPercentage = (assignment: Assignment) => {
    if (assignment.status === 'draft') return 0;
    if (assignment.status === 'completed') return 100;
    return Math.round((assignment.submissionsCount / assignment.totalStudents) * 100);
  };

  const filteredAssignments = assignments.filter(assignment => {
    switch (activeTab) {
      case 'published': return assignment.status === 'published';
      case 'completed': return assignment.status === 'completed';
      case 'draft': return assignment.status === 'draft';
      default: return true;
    }
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Assignment Management</h1>
          <p className="text-muted-foreground">
            Create, manage, and grade assignments for your classes
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline" className="flex items-center gap-1">
            <AlertCircle className="w-3 h-3" />
            {assignments.filter(a => a.status === 'published' && a.gradedCount < a.submissionsCount).length} Need Grading
          </Badge>
          <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-1">
                <Plus className="w-4 h-4" />
                Create Assignment
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Assignment</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="title">Assignment Title</Label>
                    <Input id="title" placeholder="Enter assignment title" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select subject" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mathematics">Mathematics</SelectItem>
                        <SelectItem value="science">Science</SelectItem>
                        <SelectItem value="english">English</SelectItem>
                        <SelectItem value="te-reo-maori">Te Reo Māori</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="class">Class</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select class" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="grade7a-math">Grade 7A Mathematics</SelectItem>
                        <SelectItem value="grade7b-math">Grade 7B Mathematics</SelectItem>
                        <SelectItem value="grade7a-science">Grade 7A Science</SelectItem>
                        <SelectItem value="grade7b-science">Grade 7B Science</SelectItem>
                        <SelectItem value="grade7-english">Grade 7 English</SelectItem>
                        <SelectItem value="grade7-maori">Grade 7 Te Reo Māori</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="marks">Total Marks</Label>
                    <Input id="marks" type="number" placeholder="100" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="due-date">Due Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {selectedDate ? format(selectedDate, 'PPP') : 'Pick a date'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={selectedDate}
                        onSelect={setSelectedDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" placeholder="Assignment description..." />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="instructions">Instructions</Label>
                  <Textarea id="instructions" placeholder="Detailed instructions for students..." />
                </div>
                <div className="flex gap-2">
                  <Button type="submit" className="flex-1">Create Assignment</Button>
                  <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>Cancel</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All Assignments</TabsTrigger>
          <TabsTrigger value="published">Published</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="draft">Drafts</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-4 mt-6">
          {filteredAssignments.map((assignment) => (
            <Card key={assignment.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-lg">{assignment.title}</CardTitle>
                      <Badge variant="outline" className={getStatusColor(assignment.status)}>
                        {assignment.status.charAt(0).toUpperCase() + assignment.status.slice(1)}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <FileText className="w-3 h-3" />
                        {assignment.subject}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {assignment.class}
                      </span>
                      <span className="flex items-center gap-1">
                        <CalendarIcon className="w-3 h-3" />
                        Due: {new Date(assignment.dueDate).toLocaleDateString('en-NZ')}
                      </span>
                      <span className="flex items-center gap-1">
                        <Star className="w-3 h-3" />
                        {assignment.totalMarks} marks
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Eye className="w-3 h-3 mr-1" />
                      View
                    </Button>
                    <Button variant="outline" size="sm">
                      <Edit className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{assignment.description}</p>
                
                {assignment.status !== 'draft' && (
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Submissions</span>
                        <span>{assignment.submissionsCount}/{assignment.totalStudents}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full" 
                          style={{ width: `${getProgressPercentage(assignment)}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Graded</span>
                        <span>{assignment.gradedCount}/{assignment.submissionsCount}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-600 h-2 rounded-full" 
                          style={{ width: `${assignment.submissionsCount > 0 ? (assignment.gradedCount / assignment.submissionsCount) * 100 : 0}%` }}
                        ></div>
                      </div>
                    </div>
                    {assignment.averageScore && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Average Score</span>
                          <span>{assignment.averageScore}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-yellow-600 h-2 rounded-full" 
                            style={{ width: `${assignment.averageScore}%` }}
                          ></div>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {assignment.attachments.length > 0 && (
                  <div>
                    <h4 className="font-medium text-sm mb-2">Attachments</h4>
                    <div className="flex gap-2">
                      {assignment.attachments.map((attachment, index) => (
                        <Button key={index} variant="outline" size="sm" className="text-xs">
                          📎 {attachment}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between pt-2 border-t">
                  <div className="text-xs text-muted-foreground">
                    Created: {new Date(assignment.createdDate).toLocaleDateString('en-NZ')}
                  </div>
                  <div className="flex gap-2">
                    {assignment.status === 'published' && assignment.gradedCount < assignment.submissionsCount && (
                      <Button size="sm" className="flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" />
                        Grade Submissions
                      </Button>
                    )}
                    {assignment.status === 'draft' && (
                      <Button size="sm" className="flex items-center gap-1">
                        <Upload className="w-3 h-3" />
                        Publish
                      </Button>
                    )}
                    <Button variant="outline" size="sm" className="flex items-center gap-1">
                      <Download className="w-3 h-3" />
                      Export
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>

      {/* Submissions Section (for demo purposes, showing submissions for first assignment) */}
      {filteredAssignments.length > 0 && filteredAssignments[0].status === 'published' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Recent Submissions - {filteredAssignments[0].title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {submissions.slice(0, 4).map((submission) => (
                <div key={submission.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="text-xs">{submission.studentAvatar}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium text-sm">{submission.studentName}</div>
                      <div className="text-xs text-muted-foreground">
                        {submission.submittedDate ? 
                          `Submitted: ${new Date(submission.submittedDate).toLocaleDateString('en-NZ')}` : 
                          'Not submitted'
                        }
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {submission.score !== undefined && (
                      <span className="text-sm font-medium">{submission.score}/{submission.maxScore}</span>
                    )}
                    <Badge variant="outline" className={getSubmissionStatusColor(submission.status)}>
                      {submission.status.charAt(0).toUpperCase() + submission.status.slice(1)}
                    </Badge>
                    {submission.status === 'submitted' || submission.status === 'late' ? (
                      <Button size="sm" variant="outline">Grade</Button>
                    ) : submission.status === 'graded' ? (
                      <Button size="sm" variant="outline">Review</Button>
                    ) : null}
                  </div>
                </div>
              ))}
              <Button variant="outline" size="sm" className="w-full mt-4">
                View All Submissions
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}