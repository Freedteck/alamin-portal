import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { 
  Users, 
  BookOpen, 
  Calendar, 
  ClipboardCheck,
  MessageSquare,
  TrendingUp,
  Clock,
  Star,
  Award,
  Bell,
  CheckCircle,
  AlertCircle,
  FileText,
  GraduationCap
} from 'lucide-react';

export function StaffDashboard() {
  // Mock data for Dr. Smith Johnson
  const staffStats = {
    totalStudents: 34,
    activeClasses: 6,
    pendingRequests: 8,
    completedAssignments: 127,
    averageGrade: 87,
    attendanceRate: 94
  };

  const upcomingClasses = [
    {
      id: '1',
      subject: 'Mathematics',
      time: '9:00 AM - 10:00 AM',
      date: 'Today',
      students: 25,
      room: 'Room 101',
      topic: 'Fractions and Decimals'
    },
    {
      id: '2',
      subject: 'Science',
      time: '2:00 PM - 3:00 PM',
      date: 'Today',
      students: 20,
      room: 'Science Lab',
      topic: 'Plant Life Cycles'
    },
    {
      id: '3',
      subject: 'English',
      time: '10:00 AM - 11:00 AM',
      date: 'Tomorrow',
      students: 25,
      room: 'Room 105',
      topic: 'Creative Writing'
    },
    {
      id: '4',
      subject: 'Te Reo Māori',
      time: '1:00 PM - 2:00 PM',
      date: 'Tomorrow',
      students: 28,
      room: 'Room 108',
      topic: 'Family Vocabulary'
    }
  ];

  const recentActivity = [
    {
      id: '1',
      type: 'assignment',
      title: 'Graded Fractions Test - Grade 7A Math',
      description: '22 students completed, average score: 87%',
      time: '2 hours ago',
      icon: <CheckCircle className="w-4 h-4 text-green-600" />
    },
    {
      id: '2',
      type: 'request',
      title: 'New help request from Sarah Chen',
      description: 'Extra help with decimal division problems',
      time: '4 hours ago',
      icon: <MessageSquare className="w-4 h-4 text-blue-600" />
    },
    {
      id: '3',
      type: 'attendance',
      title: 'Attendance marked for Grade 7B Science',
      description: '19/20 students present',
      time: '1 day ago',
      icon: <ClipboardCheck className="w-4 h-4 text-orange-600" />
    },
    {
      id: '4',
      type: 'announcement',
      title: 'Posted announcement about Science Fair',
      description: 'Grade 7 science project showcase next month',
      time: '2 days ago',
      icon: <Bell className="w-4 h-4 text-purple-600" />
    }
  ];

  const pendingTasks = [
    {
      id: '1',
      task: 'Review and approve 3 extra help requests',
      priority: 'high',
      dueDate: 'Today'
    },
    {
      id: '2',
      task: 'Grade Science projects (8 pending)',
      priority: 'medium',
      dueDate: 'Tomorrow'
    },
    {
      id: '3',
      task: 'Prepare materials for next week\'s fractions lessons',
      priority: 'medium',
      dueDate: 'Friday'
    },
    {
      id: '4',
      task: 'Submit monthly progress reports',
      priority: 'low',
      dueDate: 'Next Monday'
    }
  ];

  const topStudents = [
    {
      name: 'Sarah Chen',
      subject: 'Mathematics',
      grade: 'A',
      improvement: '+5%',
      avatar: 'SC'
    },
    {
      name: 'Michael Zhang',
      subject: 'Science', 
      grade: 'A-',
      improvement: '+8%',
      avatar: 'MZ'
    },
    {
      name: 'Emma Wilson',
      subject: 'English',
      grade: 'B+',
      improvement: '+12%',
      avatar: 'EW'
    },
    {
      name: 'James Liu',
      subject: 'Te Reo Māori',
      grade: 'B+',
      improvement: '+7%',
      avatar: 'JL'
    }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Staff Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back, Dr. Smith Johnson! Here's your teaching overview.
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline" className="flex items-center gap-1">
            <AlertCircle className="w-3 h-3" />
            {pendingTasks.filter(t => t.priority === 'high').length} High Priority
          </Badge>
          <Button size="sm" className="flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            View Schedule
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Students</p>
                <p className="text-2xl font-bold text-primary">{staffStats.totalStudents}</p>
              </div>
              <Users className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Classes</p>
                <p className="text-2xl font-bold text-primary">{staffStats.activeClasses}</p>
              </div>
              <BookOpen className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending Requests</p>
                <p className="text-2xl font-bold text-primary">{staffStats.pendingRequests}</p>
              </div>
              <MessageSquare className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Assignments Graded</p>
                <p className="text-2xl font-bold text-primary">{staffStats.completedAssignments}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Grade</p>
                <p className="text-2xl font-bold text-primary">{staffStats.averageGrade}%</p>
              </div>
              <Award className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Attendance Rate</p>
                <p className="text-2xl font-bold text-primary">{staffStats.attendanceRate}%</p>
              </div>
              <ClipboardCheck className="w-8 h-8 text-teal-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Upcoming Classes */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Upcoming Classes
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {upcomingClasses.map((class_) => (
              <div key={class_.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="space-y-1">
                  <div className="font-medium">{class_.subject}</div>
                  <div className="text-sm text-muted-foreground">{class_.topic}</div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {class_.time}
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      {class_.students} students
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant="outline" className="mb-1">
                    {class_.date}
                  </Badge>
                  <div className="text-xs text-muted-foreground">{class_.room}</div>
                </div>
              </div>
            ))}
            <Button variant="outline" size="sm" className="w-full mt-4">
              View Full Schedule
            </Button>
          </CardContent>
        </Card>

        {/* Pending Tasks */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ClipboardCheck className="w-5 h-5" />
              Pending Tasks
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {pendingTasks.map((task) => (
              <div key={task.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="space-y-1 flex-1">
                  <div className="font-medium text-sm">{task.task}</div>
                  <div className="text-xs text-muted-foreground">Due: {task.dueDate}</div>
                </div>
                <Badge variant="outline" className={getPriorityColor(task.priority)}>
                  {task.priority}
                </Badge>
              </div>
            ))}
            <Button variant="outline" size="sm" className="w-full mt-4">
              View All Tasks
            </Button>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-start gap-3">
                <div className="mt-0.5">{activity.icon}</div>
                <div className="space-y-1 flex-1">
                  <div className="font-medium text-sm">{activity.title}</div>
                  <div className="text-xs text-muted-foreground">{activity.description}</div>
                  <div className="text-xs text-muted-foreground">{activity.time}</div>
                </div>
              </div>
            ))}
            <Button variant="outline" size="sm" className="w-full mt-4">
              View Activity Log
            </Button>
          </CardContent>
        </Card>

        {/* Top Performing Students */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5" />
              Top Performing Students
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {topStudents.map((student, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className="text-xs">{student.avatar}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium text-sm">{student.name}</div>
                    <div className="text-xs text-muted-foreground">{student.subject}</div>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    {student.grade}
                  </Badge>
                  <div className="text-xs text-green-600 mt-1 flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    {student.improvement}
                  </div>
                </div>
              </div>
            ))}
            <Button variant="outline" size="sm" className="w-full mt-4">
              View All Students
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <Button className="flex items-center gap-2 h-auto p-4 flex-col">
              <FileText className="w-6 h-6" />
              <span>Create Assignment</span>
            </Button>
            <Button variant="outline" className="flex items-center gap-2 h-auto p-4 flex-col">
              <ClipboardCheck className="w-6 h-6" />
              <span>Mark Attendance</span>
            </Button>
            <Button variant="outline" className="flex items-center gap-2 h-auto p-4 flex-col">
              <Bell className="w-6 h-6" />
              <span>Post Announcement</span>
            </Button>
            <Button variant="outline" className="flex items-center gap-2 h-auto p-4 flex-col">
              <GraduationCap className="w-6 h-6" />
              <span>Schedule Class</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}