import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Switch } from '../ui/switch';
import { 
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Clock,
  DollarSign,
  FileText,
  Download,
  Upload,
  Edit,
  Save,
  X,
  Plus,
  BookOpen,
  Calculator,
  Atom,
  Languages,
  Settings,
  Bell,
  Shield,
  Key,
  CreditCard,
  Briefcase,
  GraduationCap,
  Award,
  Heart,
  Coffee,
  Home,
  Car,
  Plane,
  CalendarDays,
  CheckCircle,
  Clock as ClockIcon,
  AlertCircle
} from 'lucide-react';

interface StaffMember {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  dateOfBirth: string;
  startDate: string;
  position: string;
  subjects: string[];
  qualifications: string[];
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  bankDetails: {
    accountName: string;
    accountNumber: string;
    bank: string;
  };
  contractType: 'full-time' | 'part-time' | 'casual';
  hourlyRate: number;
  annualSalary?: number;
}

interface Payslip {
  id: string;
  month: string;
  year: number;
  grossPay: number;
  tax: number;
  kiwisaver: number;
  netPay: number;
  hoursWorked: number;
  overtimeHours: number;
  payDate: string;
  status: 'paid' | 'pending' | 'processing';
}

interface LeaveRequest {
  id: string;
  type: 'annual' | 'sick' | 'personal' | 'maternity' | 'study';
  startDate: string;
  endDate: string;
  days: number;
  reason: string;
  status: 'pending' | 'approved' | 'declined';
  submittedDate: string;
  approvedBy?: string;
  approvedDate?: string;
  notes?: string;
}

interface ResourceRequest {
  id: string;
  category: 'teaching-materials' | 'technology' | 'furniture' | 'stationery' | 'other';
  title: string;
  description: string;
  urgency: 'low' | 'medium' | 'high';
  estimatedCost?: number;
  status: 'pending' | 'approved' | 'ordered' | 'delivered' | 'declined';
  submittedDate: string;
  notes?: string;
}

export function StaffProfile() {
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [showResourceModal, setShowResourceModal] = useState(false);

  // Mock staff data
  const [staffData, setStaffData] = useState<StaffMember>({
    id: 'staff-001',
    name: 'Dr. Smith Johnson',
    email: 'smith.johnson@ilamtuition.co.nz',
    phone: '021 555 1234',
    address: '123 Fendalton Road, Christchurch 8041',
    dateOfBirth: '1985-03-15',
    startDate: '2020-02-01',
    position: 'Senior Mathematics Teacher',
    subjects: ['Mathematics', 'Science'],
    qualifications: [
      'PhD in Mathematics - University of Canterbury',
      'Bachelor of Science (Hons) - University of Otago',
      'Teaching Certificate - Christchurch College of Education'
    ],
    emergencyContact: {
      name: 'Sarah Johnson',
      relationship: 'Spouse',
      phone: '021 555 5678'
    },
    bankDetails: {
      accountName: 'Dr. Smith Johnson',
      accountNumber: '12-3456-0123456-00',
      bank: 'ANZ Bank'
    },
    contractType: 'full-time',
    hourlyRate: 45,
    annualSalary: 72000
  });

  // Mock payslips
  const payslips: Payslip[] = [
    {
      id: 'pay-001',
      month: 'September',
      year: 2024,
      grossPay: 6000,
      tax: 1140,
      kiwisaver: 180,
      netPay: 4680,
      hoursWorked: 160,
      overtimeHours: 0,
      payDate: '2024-09-25',
      status: 'paid'
    },
    {
      id: 'pay-002',
      month: 'August',
      year: 2024,
      grossPay: 6200,
      tax: 1178,
      kiwisaver: 186,
      netPay: 4836,
      hoursWorked: 165,
      overtimeHours: 5,
      payDate: '2024-08-25',
      status: 'paid'
    },
    {
      id: 'pay-003',
      month: 'July',
      year: 2024,
      grossPay: 5800,
      tax: 1102,
      kiwisaver: 174,
      netPay: 4524,
      hoursWorked: 155,
      overtimeHours: 0,
      payDate: '2024-07-25',
      status: 'paid'
    }
  ];

  // Mock leave requests
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>([
    {
      id: 'leave-001',
      type: 'annual',
      startDate: '2024-10-15',
      endDate: '2024-10-18',
      days: 4,
      reason: 'Family holiday',
      status: 'approved',
      submittedDate: '2024-09-20',
      approvedBy: 'Director Ms. Thompson',
      approvedDate: '2024-09-22'
    },
    {
      id: 'leave-002',
      type: 'sick',
      startDate: '2024-09-10',
      endDate: '2024-09-10',
      days: 1,
      reason: 'Medical appointment',
      status: 'approved',
      submittedDate: '2024-09-09',
      approvedBy: 'Director Ms. Thompson',
      approvedDate: '2024-09-09'
    },
    {
      id: 'leave-003',
      type: 'personal',
      startDate: '2024-11-25',
      endDate: '2024-11-25',
      days: 1,
      reason: 'Personal matters',
      status: 'pending',
      submittedDate: '2024-09-25'
    }
  ]);

  // Mock resource requests
  const [resourceRequests, setResourceRequests] = useState<ResourceRequest[]>([
    {
      id: 'resource-001',
      category: 'teaching-materials',
      title: 'Scientific Calculator Set',
      description: 'Need 10 Casio fx-991EX calculators for advanced mathematics classes',
      urgency: 'medium',
      estimatedCost: 500,
      status: 'approved',
      submittedDate: '2024-09-20',
      notes: 'Approved for Term 4 budget'
    },
    {
      id: 'resource-002',
      category: 'technology',
      title: 'Interactive Whiteboard',
      description: 'Request for smart board installation in Room A for better mathematics visualization',
      urgency: 'high',
      estimatedCost: 2500,
      status: 'pending',
      submittedDate: '2024-09-22'
    },
    {
      id: 'resource-003',
      category: 'stationery',
      title: 'Graph Paper & Protractors',
      description: 'Geometry teaching supplies for Grade 7 classes',
      urgency: 'low',
      estimatedCost: 150,
      status: 'delivered',
      submittedDate: '2024-09-15',
      notes: 'Delivered on 2024-09-23'
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
      case 'paid':
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'pending':
      case 'processing':
        return 'bg-yellow-100 text-yellow-800';
      case 'declined':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-blue-100 text-blue-800';
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getSubjectIcon = (subject: string) => {
    switch (subject) {
      case 'Mathematics': return <Calculator className="w-4 h-4" />;
      case 'Science': return <Atom className="w-4 h-4" />;
      case 'English': return <BookOpen className="w-4 h-4" />;
      case 'Te Reo Māori': return <Languages className="w-4 h-4" />;
      default: return <BookOpen className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>👤 My Profile</h1>
          <p className="text-muted-foreground">
            Manage your account, view payslips, request leave and resources
          </p>
        </div>
        <div className="flex gap-2">
          {isEditing ? (
            <div className="flex gap-2">
              <Button onClick={() => setIsEditing(false)} variant="outline">
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
              <Button onClick={() => setIsEditing(false)}>
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          ) : (
            <Button onClick={() => setIsEditing(true)}>
              <Edit className="w-4 h-4 mr-2" />
              Edit Profile
            </Button>
          )}
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="profile">👤 Profile</TabsTrigger>
          <TabsTrigger value="payslips">💰 Payslips</TabsTrigger>
          <TabsTrigger value="leave">🏖️ Leave</TabsTrigger>
          <TabsTrigger value="resources">📋 Resources</TabsTrigger>
          <TabsTrigger value="contracts">📄 Contracts</TabsTrigger>
          <TabsTrigger value="settings">⚙️ Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <div className="grid gap-6">
            {/* Personal Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Personal Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4 mb-4">
                  <Avatar className="w-20 h-20">
                    <AvatarFallback className="text-xl bg-gradient-to-br from-blue-100 to-purple-100">
                      {staffData.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold">{staffData.name}</h3>
                    <p className="text-muted-foreground">{staffData.position}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {staffData.subjects.map((subject, index) => (
                        <Badge key={index} variant="secondary" className="flex items-center gap-1">
                          {getSubjectIcon(subject)}
                          {subject}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  {isEditing && (
                    <Button variant="outline" size="sm">
                      <Upload className="w-4 h-4 mr-2" />
                      Change Photo
                    </Button>
                  )}
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>Full Name</Label>
                    <Input 
                      value={staffData.name} 
                      disabled={!isEditing}
                      className={!isEditing ? "bg-muted/30" : ""}
                    />
                  </div>
                  <div>
                    <Label>Position</Label>
                    <Input 
                      value={staffData.position} 
                      disabled={!isEditing}
                      className={!isEditing ? "bg-muted/30" : ""}
                    />
                  </div>
                  <div>
                    <Label>Email</Label>
                    <Input 
                      value={staffData.email} 
                      disabled={!isEditing}
                      className={!isEditing ? "bg-muted/30" : ""}
                    />
                  </div>
                  <div>
                    <Label>Phone</Label>
                    <Input 
                      value={staffData.phone} 
                      disabled={!isEditing}
                      className={!isEditing ? "bg-muted/30" : ""}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Label>Address</Label>
                    <Input 
                      value={staffData.address} 
                      disabled={!isEditing}
                      className={!isEditing ? "bg-muted/30" : ""}
                    />
                  </div>
                  <div>
                    <Label>Date of Birth</Label>
                    <Input 
                      type="date"
                      value={staffData.dateOfBirth} 
                      disabled={!isEditing}
                      className={!isEditing ? "bg-muted/30" : ""}
                    />
                  </div>
                  <div>
                    <Label>Start Date</Label>
                    <Input 
                      type="date"
                      value={staffData.startDate} 
                      disabled={!isEditing}
                      className={!isEditing ? "bg-muted/30" : ""}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Employment Details */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="w-5 h-5" />
                  Employment Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label>Contract Type</Label>
                    <Badge className="mt-1 bg-blue-100 text-blue-800">
                      {staffData.contractType.replace('-', ' ').toUpperCase()}
                    </Badge>
                  </div>
                  <div>
                    <Label>Hourly Rate</Label>
                    <div className="text-lg font-semibold">${staffData.hourlyRate}/hour</div>
                  </div>
                  {staffData.annualSalary && (
                    <div>
                      <Label>Annual Salary</Label>
                      <div className="text-lg font-semibold">${staffData.annualSalary.toLocaleString()}</div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Qualifications */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <GraduationCap className="w-5 h-5" />
                  Qualifications
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {staffData.qualifications.map((qual, index) => (
                    <div key={index} className="flex items-center gap-2 p-2 bg-muted/30 rounded">
                      <Award className="w-4 h-4 text-blue-600" />
                      <span>{qual}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Emergency Contact */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="w-5 h-5" />
                  Emergency Contact
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label>Name</Label>
                    <Input 
                      value={staffData.emergencyContact.name} 
                      disabled={!isEditing}
                      className={!isEditing ? "bg-muted/30" : ""}
                    />
                  </div>
                  <div>
                    <Label>Relationship</Label>
                    <Input 
                      value={staffData.emergencyContact.relationship} 
                      disabled={!isEditing}
                      className={!isEditing ? "bg-muted/30" : ""}
                    />
                  </div>
                  <div>
                    <Label>Phone</Label>
                    <Input 
                      value={staffData.emergencyContact.phone} 
                      disabled={!isEditing}
                      className={!isEditing ? "bg-muted/30" : ""}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="payslips" className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h2>💰 Payslips & Salary Information</h2>
              <p className="text-muted-foreground">View and download your payslips</p>
            </div>
          </div>

          <div className="grid gap-4">
            {payslips.map((payslip) => (
              <Card key={payslip.id}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-green-100 rounded-lg">
                        <DollarSign className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{payslip.month} {payslip.year}</h3>
                        <div className="text-sm text-muted-foreground">
                          Paid on {new Date(payslip.payDate).toLocaleDateString('en-NZ')}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-green-600">
                        ${payslip.netPay.toLocaleString()}
                      </div>
                      <Badge className={getStatusColor(payslip.status)}>
                        {payslip.status.toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-4">
                    <div>
                      <div className="text-sm text-muted-foreground">Hours Worked</div>
                      <div className="font-medium">{payslip.hoursWorked}h</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Gross Pay</div>
                      <div className="font-medium">${payslip.grossPay.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Tax</div>
                      <div className="font-medium">-${payslip.tax.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">KiwiSaver</div>
                      <div className="font-medium">-${payslip.kiwisaver.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Net Pay</div>
                      <div className="font-medium font-bold">${payslip.netPay.toLocaleString()}</div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 mt-4">
                    <Button size="sm" variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Download PDF
                    </Button>
                    <Button size="sm" variant="outline">
                      <FileText className="w-4 h-4 mr-2" />
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="leave" className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h2>🏖️ Leave Requests</h2>
              <p className="text-muted-foreground">Submit and track your leave requests</p>
            </div>
            <Button onClick={() => setShowLeaveModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Request Leave
            </Button>
          </div>

          {/* Leave Balance */}
          <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
            <CardContent className="p-6">
              <h3 className="font-semibold mb-4">📊 Leave Balance</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">15</div>
                  <div className="text-sm text-muted-foreground">Annual Leave</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">8</div>
                  <div className="text-sm text-muted-foreground">Sick Leave</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">3</div>
                  <div className="text-sm text-muted-foreground">Personal Leave</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">2</div>
                  <div className="text-sm text-muted-foreground">Study Leave</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Leave Requests */}
          <div className="grid gap-4">
            {leaveRequests.map((request) => (
              <Card key={request.id}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`p-3 rounded-lg ${
                        request.type === 'annual' ? 'bg-blue-100' :
                        request.type === 'sick' ? 'bg-red-100' :
                        request.type === 'personal' ? 'bg-purple-100' :
                        'bg-green-100'
                      }`}>
                        {request.type === 'annual' && <Plane className="w-5 h-5 text-blue-600" />}
                        {request.type === 'sick' && <Heart className="w-5 h-5 text-red-600" />}
                        {request.type === 'personal' && <Coffee className="w-5 h-5 text-purple-600" />}
                        {request.type === 'study' && <BookOpen className="w-5 h-5 text-green-600" />}
                      </div>
                      <div>
                        <h3 className="font-semibold capitalize">{request.type.replace('-', ' ')} Leave</h3>
                        <div className="text-sm text-muted-foreground">
                          {new Date(request.startDate).toLocaleDateString('en-NZ')} - 
                          {new Date(request.endDate).toLocaleDateString('en-NZ')} 
                          ({request.days} {request.days === 1 ? 'day' : 'days'})
                        </div>
                        <div className="text-sm mt-1">{request.reason}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className={getStatusColor(request.status)}>
                        {request.status.toUpperCase()}
                      </Badge>
                      <div className="text-xs text-muted-foreground mt-1">
                        Submitted {new Date(request.submittedDate).toLocaleDateString('en-NZ')}
                      </div>
                    </div>
                  </div>
                  
                  {request.status === 'approved' && request.approvedBy && (
                    <div className="mt-4 p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center gap-2 text-green-800">
                        <CheckCircle className="w-4 h-4" />
                        <span className="text-sm">
                          Approved by {request.approvedBy} on {new Date(request.approvedDate!).toLocaleDateString('en-NZ')}
                        </span>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="resources" className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h2>📋 Resource Requests</h2>
              <p className="text-muted-foreground">Request teaching materials and resources</p>
            </div>
            <Button onClick={() => setShowResourceModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Request Resources
            </Button>
          </div>

          <div className="grid gap-4">
            {resourceRequests.map((request) => (
              <Card key={request.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-blue-100 rounded-lg">
                        <FileText className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold">{request.title}</h3>
                        <p className="text-sm text-muted-foreground mt-1">{request.description}</p>
                        <div className="flex items-center gap-4 mt-2">
                          <Badge variant="secondary">{request.category.replace('-', ' ')}</Badge>
                          <Badge className={getUrgencyColor(request.urgency)}>
                            {request.urgency} priority
                          </Badge>
                          {request.estimatedCost && (
                            <span className="text-sm text-muted-foreground">
                              Est. ${request.estimatedCost}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className={getStatusColor(request.status)}>
                        {request.status.toUpperCase()}
                      </Badge>
                      <div className="text-xs text-muted-foreground mt-1">
                        {new Date(request.submittedDate).toLocaleDateString('en-NZ')}
                      </div>
                    </div>
                  </div>
                  
                  {request.notes && (
                    <div className="mt-4 p-3 bg-muted/30 rounded-lg">
                      <div className="text-sm">{request.notes}</div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="contracts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Employment Contract & Agreements
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <FileText className="w-5 h-5 text-blue-600" />
                    <div>
                      <div className="font-medium">Employment Contract</div>
                      <div className="text-sm text-muted-foreground">Signed: 1 February 2020</div>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
                
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Shield className="w-5 h-5 text-green-600" />
                    <div>
                      <div className="font-medium">Confidentiality Agreement</div>
                      <div className="text-sm text-muted-foreground">Signed: 1 February 2020</div>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
                
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <BookOpen className="w-5 h-5 text-purple-600" />
                    <div>
                      <div className="font-medium">Teaching Handbook</div>
                      <div className="text-sm text-muted-foreground">Updated: August 2024</div>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
                
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <CreditCard className="w-5 h-5 text-orange-600" />
                    <div>
                      <div className="font-medium">KiwiSaver Details</div>
                      <div className="text-sm text-muted-foreground">3% employee contribution</div>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    <Edit className="w-4 h-4 mr-2" />
                    Update
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Account Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h4 className="font-medium flex items-center gap-2">
                  <Bell className="w-4 h-4" />
                  Notifications
                </h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Email Notifications</div>
                      <div className="text-sm text-muted-foreground">
                        Receive email updates about schedule changes and announcements
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Leave Request Updates</div>
                      <div className="text-sm text-muted-foreground">
                        Get notified when leave requests are approved or declined
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Payslip Reminders</div>
                      <div className="text-sm text-muted-foreground">
                        Monthly payslip availability notifications
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-medium flex items-center gap-2">
                  <Key className="w-4 h-4" />
                  Security
                </h4>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    <Key className="w-4 h-4 mr-2" />
                    Change Password
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Shield className="w-4 h-4 mr-2" />
                    Two-Factor Authentication
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Leave Request Modal */}
      <LeaveRequestModal 
        isOpen={showLeaveModal} 
        onClose={() => setShowLeaveModal(false)}
      />

      {/* Resource Request Modal */}
      <ResourceRequestModal 
        isOpen={showResourceModal} 
        onClose={() => setShowResourceModal(false)}
      />
    </div>
  );
}

function LeaveRequestModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>🏖️ Request Leave</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Leave Type</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Select leave type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="annual">Annual Leave</SelectItem>
                <SelectItem value="sick">Sick Leave</SelectItem>
                <SelectItem value="personal">Personal Leave</SelectItem>
                <SelectItem value="study">Study Leave</SelectItem>
                <SelectItem value="maternity">Maternity Leave</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Start Date</Label>
              <Input type="date" />
            </div>
            <div>
              <Label>End Date</Label>
              <Input type="date" />
            </div>
          </div>
          
          <div>
            <Label>Reason</Label>
            <Textarea placeholder="Please provide a reason for your leave request..." />
          </div>
          
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={onClose}>Submit Request</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ResourceRequestModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>📋 Request Resources</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Category</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="teaching-materials">Teaching Materials</SelectItem>
                <SelectItem value="technology">Technology</SelectItem>
                <SelectItem value="furniture">Furniture</SelectItem>
                <SelectItem value="stationery">Stationery</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label>Title</Label>
            <Input placeholder="Brief title for your request" />
          </div>
          
          <div>
            <Label>Description</Label>
            <Textarea placeholder="Detailed description of what you need..." />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Urgency</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select urgency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Estimated Cost (optional)</Label>
              <Input type="number" placeholder="$0" />
            </div>
          </div>
          
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={onClose}>Submit Request</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}