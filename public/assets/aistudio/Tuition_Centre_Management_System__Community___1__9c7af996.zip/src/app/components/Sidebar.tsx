import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  Calendar, 
  UserCheck, 
  Settings as SettingsIcon,
  BookOpen 
} from 'lucide-react';
import { Button } from './ui/button';

interface SidebarProps {
  activeModule: string;
  setActiveModule: (module: string) => void;
}

export function Sidebar({ activeModule, setActiveModule }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'teachers', label: 'Teachers', icon: GraduationCap },
    { id: 'schedule', label: 'Schedule', icon: Calendar },
    { id: 'hr', label: 'HR Management', icon: UserCheck },
    { id: 'settings', label: 'Settings', icon: SettingsIcon },
  ];

  return (
    <div className="w-64 bg-sidebar border-r border-sidebar-border p-4">
      <div className="flex items-center gap-2 mb-8">
        <BookOpen className="h-8 w-8 text-sidebar-primary" />
        <div>
          <h1 className="text-xl text-sidebar-foreground">Ilam Tuition Centre</h1>
          <p className="text-xs text-sidebar-foreground/70">Admin Portal</p>
        </div>
      </div>
      
      <nav className="space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Button
              key={item.id}
              variant={activeModule === item.id ? "default" : "ghost"}
              className={`w-full justify-start gap-3 ${
                activeModule === item.id 
                  ? 'bg-sidebar-primary text-sidebar-primary-foreground' 
                  : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
              }`}
              onClick={() => setActiveModule(item.id)}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </Button>
          );
        })}
      </nav>
    </div>
  );
}