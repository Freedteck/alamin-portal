import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Users, GraduationCap, Calendar, TrendingUp, Clock, AlertTriangle } from 'lucide-react';
import { Progress } from './ui/progress';

export function Dashboard() {
  const stats = [
    {
      title: 'Total Students',
      value: '247',
      change: '+12%',
      icon: Users,
      color: 'text-blue-600'
    },
    {
      title: 'Active Teachers',
      value: '18',
      change: '+2',
      icon: GraduationCap,
      color: 'text-green-600'
    },
    {
      title: 'Classes Today',
      value: '24',
      change: '6 ongoing',
      icon: Calendar,
      color: 'text-purple-600'
    },
    {
      title: 'Revenue (Month)',
      value: '₹1,24,500',
      change: '+8.2%',
      icon: TrendingUp,
      color: 'text-orange-600'
    }
  ];

  const recentActivities = [
    { time: '10:30 AM', activity: 'New student enrollment - John Smith', type: 'enrollment' },
    { time: '11:15 AM', activity: 'Class cancelled - Physics Grade 12', type: 'cancellation' },
    { time: '12:00 PM', activity: 'Teacher marked attendance - Math Grade 10', type: 'attendance' },
    { time: '2:30 PM', activity: 'Fee payment received - Sarah Johnson', type: 'payment' },
    { time: '3:45 PM', activity: 'New class scheduled - Chemistry Grade 11', type: 'schedule' }
  ];

  const upcomingClasses = [
    { subject: 'Mathematics', grade: 'Grade 10', time: '4:00 PM', teacher: 'Dr. Smith', students: 15 },
    { subject: 'Physics', grade: 'Grade 12', time: '5:00 PM', teacher: 'Prof. Johnson', students: 12 },
    { subject: 'Chemistry', grade: 'Grade 11', time: '6:00 PM', teacher: 'Dr. Brown', students: 18 }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1>Dashboard</h1>
        <p className="text-muted-foreground">Welcome back! Here's what's happening at your tuition center today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm text-muted-foreground">{stat.title}</CardTitle>
                <Icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl">{stat.value}</div>
                <p className="text-xs text-muted-foreground">
                  {stat.change} from last month
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activities */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Recent Activities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <div className="text-sm text-muted-foreground min-w-fit">
                    {activity.time}
                  </div>
                  <div className="text-sm flex-1">
                    {activity.activity}
                  </div>
                  <div className={`w-2 h-2 rounded-full ${
                    activity.type === 'enrollment' ? 'bg-green-500' :
                    activity.type === 'cancellation' ? 'bg-red-500' :
                    activity.type === 'payment' ? 'bg-blue-500' :
                    'bg-gray-500'
                  }`} />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Classes */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Upcoming Classes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingClasses.map((classItem, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div>
                    <div className="text-sm">{classItem.subject} - {classItem.grade}</div>
                    <div className="text-xs text-muted-foreground">{classItem.teacher}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm">{classItem.time}</div>
                    <div className="text-xs text-muted-foreground">{classItem.students} students</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Attendance Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Today's Attendance Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Student Attendance</span>
                <span>87%</span>
              </div>
              <Progress value={87} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Teacher Attendance</span>
                <span>94%</span>
              </div>
              <Progress value={94} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Classes Completed</span>
                <span>75%</span>
              </div>
              <Progress value={75} className="h-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Alerts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-orange-500" />
            Important Alerts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <div className="w-2 h-2 rounded-full bg-orange-500" />
              <div className="text-sm">Fee payment pending from 15 students for this month</div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="w-2 h-2 rounded-full bg-blue-500" />
              <div className="text-sm">Parent-teacher meeting scheduled for next week</div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-lg">
              <div className="w-2 h-2 rounded-full bg-green-500" />
              <div className="text-sm">Monthly performance reports ready for distribution</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}