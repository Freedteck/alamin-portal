import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Calendar, Users, Clock, TrendingUp, DollarSign, UserCheck, UserX, Search } from 'lucide-react';

interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  role: string;
  date: string;
  clockIn: string;
  clockOut: string;
  hoursWorked: number;
  status: 'present' | 'absent' | 'late' | 'half-day';
}

interface PayrollRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  role: string;
  baseSalary: number;
  bonus: number;
  deductions: number;
  netSalary: number;
  month: string;
  status: 'paid' | 'pending' | 'processing';
}

interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  days: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
}

export function HRManagement() {
  const [selectedMonth, setSelectedMonth] = useState('2024-09');
  const [searchTerm, setSearchTerm] = useState('');

  const [attendanceRecords] = useState<AttendanceRecord[]>([
    {
      id: '1',
      employeeId: 'T001',
      employeeName: 'Dr. Smith Johnson',
      role: 'Senior Teacher',
      date: '2024-09-20',
      clockIn: '08:30',
      clockOut: '17:30',
      hoursWorked: 9,
      status: 'present'
    },
    {
      id: '2',
      employeeId: 'T002',
      employeeName: 'Prof. Sarah Wilson',
      role: 'Physics Teacher',
      date: '2024-09-20',
      clockIn: '09:15',
      clockOut: '17:30',
      hoursWorked: 8.25,
      status: 'late'
    },
    {
      id: '3',
      employeeId: 'T003',
      employeeName: 'Dr. Michael Brown',
      role: 'Chemistry Teacher',
      date: '2024-09-20',
      clockIn: '-',
      clockOut: '-',
      hoursWorked: 0,
      status: 'absent'
    },
    {
      id: '4',
      employeeId: 'A001',
      employeeName: 'John Administrator',
      role: 'Admin Staff',
      date: '2024-09-20',
      clockIn: '09:00',
      clockOut: '13:00',
      hoursWorked: 4,
      status: 'half-day'
    }
  ]);

  const [payrollRecords] = useState<PayrollRecord[]>([
    {
      id: '1',
      employeeId: 'T001',
      employeeName: 'Dr. Smith Johnson',
      role: 'Senior Teacher',
      baseSalary: 65000,
      bonus: 5000,
      deductions: 3000,
      netSalary: 67000,
      month: '2024-09',
      status: 'paid'
    },
    {
      id: '2',
      employeeId: 'T002',
      employeeName: 'Prof. Sarah Wilson',
      role: 'Physics Teacher',
      baseSalary: 55000,
      bonus: 2000,
      deductions: 2500,
      netSalary: 54500,
      month: '2024-09',
      status: 'processing'
    },
    {
      id: '3',
      employeeId: 'T003',
      employeeName: 'Dr. Michael Brown',
      role: 'Chemistry Teacher',
      baseSalary: 70000,
      bonus: 3000,
      deductions: 4000,
      netSalary: 69000,
      month: '2024-09',
      status: 'pending'
    }
  ]);

  const [leaveRequests] = useState<LeaveRequest[]>([
    {
      id: '1',
      employeeId: 'T001',
      employeeName: 'Dr. Smith Johnson',
      leaveType: 'Sick Leave',
      startDate: '2024-09-25',
      endDate: '2024-09-27',
      days: 3,
      reason: 'Medical treatment',
      status: 'approved'
    },
    {
      id: '2',
      employeeId: 'T002',
      employeeName: 'Prof. Sarah Wilson',
      leaveType: 'Annual Leave',
      startDate: '2024-10-01',
      endDate: '2024-10-05',
      days: 5,
      reason: 'Family vacation',
      status: 'pending'
    },
    {
      id: '3',
      employeeId: 'A001',
      employeeName: 'John Administrator',
      leaveType: 'Personal Leave',
      startDate: '2024-09-30',
      endDate: '2024-09-30',
      days: 1,
      reason: 'Personal matters',
      status: 'rejected'
    }
  ]);

  const getAttendanceStatusColor = (status: string) => {
    switch (status) {
      case 'present': return 'bg-green-100 text-green-800';
      case 'late': return 'bg-yellow-100 text-yellow-800';
      case 'absent': return 'bg-red-100 text-red-800';
      case 'half-day': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPayrollStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-100 text-green-800';
      case 'processing': return 'bg-yellow-100 text-yellow-800';
      case 'pending': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getLeaveStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredAttendance = attendanceRecords.filter(record =>
    record.employeeName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredPayroll = payrollRecords.filter(record =>
    record.employeeName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredLeaves = leaveRequests.filter(request =>
    request.employeeName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <h1>HR Management</h1>
        <p className="text-muted-foreground">Manage staff attendance, payroll, and leave requests</p>
      </div>

      {/* HR Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">18</div>
                <p className="text-xs text-muted-foreground">Total Staff</p>
              </div>
              <Users className="h-5 w-5 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">94%</div>
                <p className="text-xs text-muted-foreground">Attendance Rate</p>
              </div>
              <UserCheck className="h-5 w-5 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">₹12.4L</div>
                <p className="text-xs text-muted-foreground">Monthly Payroll</p>
              </div>
              <DollarSign className="h-5 w-5 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">3</div>
                <p className="text-xs text-muted-foreground">Pending Leaves</p>
              </div>
              <Calendar className="h-5 w-5 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search employees..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedMonth} onValueChange={setSelectedMonth}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Select month" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2024-09">September 2024</SelectItem>
                <SelectItem value="2024-08">August 2024</SelectItem>
                <SelectItem value="2024-07">July 2024</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="attendance" className="space-y-4">
        <TabsList>
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="payroll">Payroll</TabsTrigger>
          <TabsTrigger value="leaves">Leave Management</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="attendance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Today's Attendance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Clock In</TableHead>
                    <TableHead>Clock Out</TableHead>
                    <TableHead>Hours</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAttendance.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>
                        <div>
                          <div>{record.employeeName}</div>
                          <div className="text-sm text-muted-foreground">{record.employeeId}</div>
                        </div>
                      </TableCell>
                      <TableCell>{record.role}</TableCell>
                      <TableCell>{record.clockIn}</TableCell>
                      <TableCell>{record.clockOut}</TableCell>
                      <TableCell>{record.hoursWorked}h</TableCell>
                      <TableCell>
                        <Badge className={getAttendanceStatusColor(record.status)}>
                          {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payroll" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Monthly Payroll - {selectedMonth}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Base Salary</TableHead>
                    <TableHead>Bonus</TableHead>
                    <TableHead>Deductions</TableHead>
                    <TableHead>Net Salary</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPayroll.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>
                        <div>
                          <div>{record.employeeName}</div>
                          <div className="text-sm text-muted-foreground">{record.employeeId}</div>
                        </div>
                      </TableCell>
                      <TableCell>{record.role}</TableCell>
                      <TableCell>₹{record.baseSalary.toLocaleString()}</TableCell>
                      <TableCell>₹{record.bonus.toLocaleString()}</TableCell>
                      <TableCell>₹{record.deductions.toLocaleString()}</TableCell>
                      <TableCell>₹{record.netSalary.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge className={getPayrollStatusColor(record.status)}>
                          {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leaves" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Leave Requests
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Leave Type</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Days</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLeaves.map((request) => (
                    <TableRow key={request.id}>
                      <TableCell>
                        <div>
                          <div>{request.employeeName}</div>
                          <div className="text-sm text-muted-foreground">{request.employeeId}</div>
                        </div>
                      </TableCell>
                      <TableCell>{request.leaveType}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {new Date(request.startDate).toLocaleDateString()} -
                          {new Date(request.endDate).toLocaleDateString()}
                        </div>
                      </TableCell>
                      <TableCell>{request.days} days</TableCell>
                      <TableCell className="max-w-[200px] truncate">{request.reason}</TableCell>
                      <TableCell>
                        <Badge className={getLeaveStatusColor(request.status)}>
                          {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {request.status === 'pending' && (
                          <div className="flex gap-1">
                            <Button size="sm" variant="outline" className="h-7 px-2">
                              <UserCheck className="h-3 w-3" />
                            </Button>
                            <Button size="sm" variant="outline" className="h-7 px-2">
                              <UserX className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Attendance Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Present</span>
                    <span>75%</span>
                  </div>
                  <Progress value={75} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Late</span>
                    <span>19%</span>
                  </div>
                  <Progress value={19} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Absent</span>
                    <span>6%</span>
                  </div>
                  <Progress value={6} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Leave Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Approved Leaves</span>
                    <span>12</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Pending Requests</span>
                    <span>3</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Rejected Requests</span>
                    <span>1</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Monthly Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-muted-foreground">
                Attendance has improved by 8% compared to last month. 
                Late arrivals have decreased by 15%. Overall staff satisfaction remains high.
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}