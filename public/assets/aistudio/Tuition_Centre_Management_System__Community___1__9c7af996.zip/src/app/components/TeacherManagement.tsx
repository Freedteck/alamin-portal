import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Search, Plus, Edit, Eye, Phone, Mail, Calendar, Star } from 'lucide-react';

interface Teacher {
  id: string;
  name: string;
  subjects: string[];
  qualifications: string;
  experience: number;
  phone: string;
  email: string;
  joinDate: string;
  salary: number;
  rating: number;
  status: 'active' | 'inactive';
  classes: number;
}

export function TeacherManagement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);

  const [teachers] = useState<Teacher[]>([
    {
      id: '1',
      name: 'Dr. Smith Johnson',
      subjects: ['Mathematics', 'Statistics'],
      qualifications: 'Ph.D. in Mathematics',
      experience: 12,
      phone: '+1-234-567-8901',
      email: 'dr.smith@edumanage.com',
      joinDate: '2020-03-15',
      salary: 65000,
      rating: 4.8,
      status: 'active',
      classes: 15
    },
    {
      id: '2',
      name: 'Prof. Sarah Wilson',
      subjects: ['Physics', 'Chemistry'],
      qualifications: 'M.Sc. Physics, B.Ed.',
      experience: 8,
      phone: '+1-234-567-8902',
      email: 'prof.sarah@edumanage.com',
      joinDate: '2021-08-01',
      salary: 55000,
      rating: 4.6,
      status: 'active',
      classes: 12
    },
    {
      id: '3',
      name: 'Dr. Michael Brown',
      subjects: ['Chemistry', 'Biology'],
      qualifications: 'Ph.D. in Chemistry',
      experience: 15,
      phone: '+1-234-567-8903',
      email: 'dr.michael@edumanage.com',
      joinDate: '2019-01-10',
      salary: 70000,
      rating: 4.9,
      status: 'active',
      classes: 18
    },
    {
      id: '4',
      name: 'Ms. Emily Davis',
      subjects: ['English', 'Literature'],
      qualifications: 'M.A. English Literature',
      experience: 6,
      phone: '+1-234-567-8904',
      email: 'emily.davis@edumanage.com',
      joinDate: '2022-06-15',
      salary: 45000,
      rating: 4.4,
      status: 'active',
      classes: 10
    }
  ]);

  const filteredTeachers = teachers.filter(teacher => {
    const matchesSearch = teacher.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         teacher.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSubject = selectedSubject === 'all' || teacher.subjects.includes(selectedSubject);
    return matchesSearch && matchesSubject;
  });

  const getStatusColor = (status: string) => {
    return status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-3 w-3 ${i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1>Teacher Management</h1>
          <p className="text-muted-foreground">Manage teaching staff, qualifications, and assignments</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Add Teacher
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Teacher</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" placeholder="Enter teacher name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="Teacher email" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" placeholder="Phone number" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="experience">Experience (years)</Label>
                <Input id="experience" type="number" placeholder="Years of experience" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="qualifications">Qualifications</Label>
                <Input id="qualifications" placeholder="Educational qualifications" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="salary">Salary</Label>
                <Input id="salary" type="number" placeholder="Monthly salary" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subjects">Subjects</Label>
                <Input id="subjects" placeholder="Subjects (comma separated)" />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsAddDialogOpen(false)}>
                Add Teacher
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl">{teachers.length}</div>
            <p className="text-xs text-muted-foreground">Total Teachers</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl">{teachers.filter(t => t.status === 'active').length}</div>
            <p className="text-xs text-muted-foreground">Active Teachers</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl">{Math.round(teachers.reduce((acc, t) => acc + t.experience, 0) / teachers.length)}</div>
            <p className="text-xs text-muted-foreground">Avg. Experience</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl">{(teachers.reduce((acc, t) => acc + t.rating, 0) / teachers.length).toFixed(1)}</div>
            <p className="text-xs text-muted-foreground">Avg. Rating</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search teachers by name or email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedSubject} onValueChange={setSelectedSubject}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Filter by subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                <SelectItem value="Mathematics">Mathematics</SelectItem>
                <SelectItem value="Physics">Physics</SelectItem>
                <SelectItem value="Chemistry">Chemistry</SelectItem>
                <SelectItem value="Biology">Biology</SelectItem>
                <SelectItem value="English">English</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Teachers Table */}
      <Card>
        <CardHeader>
          <CardTitle>Teachers ({filteredTeachers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Teacher</TableHead>
                <TableHead>Subjects</TableHead>
                <TableHead>Experience</TableHead>
                <TableHead>Rating</TableHead>
                <TableHead>Classes</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTeachers.map((teacher) => (
                <TableRow key={teacher.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback>
                          {teacher.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div>{teacher.name}</div>
                        <div className="text-sm text-muted-foreground">{teacher.qualifications}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {teacher.subjects.map((subject, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {subject}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>{teacher.experience} years</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      {renderStars(teacher.rating)}
                      <span className="text-sm ml-1">{teacher.rating}</span>
                    </div>
                  </TableCell>
                  <TableCell>{teacher.classes} classes</TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(teacher.status)}>
                      {teacher.status.charAt(0).toUpperCase() + teacher.status.slice(1)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedTeacher(teacher)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Teacher Details Dialog */}
      <Dialog open={!!selectedTeacher} onOpenChange={() => setSelectedTeacher(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Teacher Details</DialogTitle>
          </DialogHeader>
          {selectedTeacher && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarFallback className="text-lg">
                      {selectedTeacher.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3>{selectedTeacher.name}</h3>
                    <p className="text-muted-foreground">{selectedTeacher.qualifications}</p>
                    <div className="flex items-center gap-1 mt-1">
                      {renderStars(selectedTeacher.rating)}
                      <span className="text-sm ml-1">{selectedTeacher.rating}/5.0</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4>Subjects Teaching</h4>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {selectedTeacher.subjects.map((subject, index) => (
                      <Badge key={index} variant="secondary">
                        {subject}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4>Contact Information</h4>
                  <div className="space-y-2 mt-2">
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedTeacher.phone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedTeacher.email}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h4>Employment Details</h4>
                  <div className="space-y-2 mt-2">
                    <div>
                      <span className="text-sm text-muted-foreground">Join Date:</span>
                      <p>{new Date(selectedTeacher.joinDate).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Experience:</span>
                      <p>{selectedTeacher.experience} years</p>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Monthly Salary:</span>
                      <p>₹{selectedTeacher.salary.toLocaleString()}</p>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Current Classes:</span>
                      <p>{selectedTeacher.classes} classes</p>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Status:</span>
                      <Badge className={getStatusColor(selectedTeacher.status)}>
                        {selectedTeacher.status.charAt(0).toUpperCase() + selectedTeacher.status.slice(1)}
                      </Badge>
                    </div>
                  </div>
                </div>

                <div>
                  <h4>Performance Metrics</h4>
                  <div className="space-y-2 mt-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Student Rating</span>
                      <span className="text-sm">{selectedTeacher.rating}/5.0</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Classes Taught</span>
                      <span className="text-sm">{selectedTeacher.classes}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Attendance Rate</span>
                      <span className="text-sm">96%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}