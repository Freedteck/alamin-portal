import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { Calendar } from '../ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  User, 
  BookOpen, 
  Plus,
  CheckCircle,
  XCircle,
  AlertCircle,
  MapPin
} from 'lucide-react';

interface Booking {
  id: string;
  subject: string;
  teacher: string;
  date: string;
  time: string;
  duration: number;
  type: 'extra-class' | 'makeup' | 'consultation';
  status: 'pending' | 'confirmed' | 'rejected' | 'completed';
  room?: string;
  notes?: string;
  requestDate: string;
  reason: string;
}

interface TimeSlot {
  time: string;
  available: boolean;
  teacher?: string;
}

export function StudentBookings() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [newBooking, setNewBooking] = useState({
    subject: '',
    teacher: 'no-preference',
    date: '',
    time: '',
    duration: '1',
    type: 'extra-class' as const,
    reason: '',
    notes: ''
  });

  // Demo bookings for Sarah Chen
  const [bookings, setBookings] = useState<Booking[]>([
    {
      id: '1',
      subject: 'Mathematics',
      teacher: 'Dr. Sarah Williams',
      date: '2024-09-28',
      time: '15:00',
      duration: 1.5,
      type: 'extra-class',
      status: 'confirmed',
      room: 'Room 101',
      notes: 'Focus on quadratic equations and graphing',
      requestDate: '2024-09-22',
      reason: 'Need extra help before the upcoming test'
    },
    {
      id: '2',
      subject: 'Physics',
      teacher: 'Mr. James Thompson',
      date: '2024-09-30',
      time: '16:30',
      duration: 1,
      type: 'consultation',
      status: 'pending',
      requestDate: '2024-09-23',
      reason: 'Discuss lab report feedback and improvement strategies'
    },
    {
      id: '3',
      subject: 'English Literature',
      teacher: 'Ms. Emma Clarke',
      date: '2024-10-01',
      time: '14:00',
      duration: 2,
      type: 'makeup',
      status: 'confirmed',
      room: 'Room 305',
      notes: 'Makeup class for the session missed due to illness',
      requestDate: '2024-09-21',
      reason: 'Missed regular class due to illness'
    }
  ]);

  // Available teachers by subject
  const teachersBySubject = {
    'Mathematics': ['Dr. Sarah Williams', 'Mr. David Chen'],
    'Physics': ['Mr. James Thompson', 'Dr. Maria Garcia'],
    'English Literature': ['Ms. Emma Clarke', 'Ms. Rebecca Johnson'],
    'Chemistry': ['Dr. Alex Smith', 'Ms. Linda Brown']
  };

  // Mock available time slots
  const getAvailableTimeSlots = (date: Date): TimeSlot[] => {
    const slots: TimeSlot[] = [
      { time: '09:00', available: true, teacher: 'Dr. Sarah Williams' },
      { time: '10:30', available: false },
      { time: '12:00', available: true, teacher: 'Mr. James Thompson' },
      { time: '13:30', available: true, teacher: 'Ms. Emma Clarke' },
      { time: '15:00', available: true, teacher: 'Dr. Sarah Williams' },
      { time: '16:30', available: false },
      { time: '18:00', available: true, teacher: 'Mr. James Thompson' }
    ];
    return slots;
  };

  const handleCreateBooking = () => {
    if (!newBooking.subject || !newBooking.reason) {
      alert('Please fill in all required fields');
      return;
    }

    const booking: Booking = {
      id: (bookings.length + 1).toString(),
      subject: newBooking.subject,
      teacher: newBooking.teacher === 'no-preference' || !newBooking.teacher ? 'To be assigned' : newBooking.teacher,
      date: newBooking.date || 'Flexible',
      time: newBooking.time || 'To be scheduled',
      duration: parseFloat(newBooking.duration),
      type: newBooking.type,
      status: 'pending',
      notes: newBooking.notes,
      requestDate: new Date().toISOString().split('T')[0],
      reason: newBooking.reason
    };

    setBookings([booking, ...bookings]);
    setNewBooking({
      subject: '',
      teacher: 'no-preference',
      date: '',
      time: '',
      duration: '1',
      type: 'extra-class',
      reason: '',
      notes: ''
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'rejected':
        return <XCircle className="w-4 h-4 text-red-600" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-blue-600" />;
      default:
        return <AlertCircle className="w-4 h-4 text-yellow-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'completed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'extra-class':
        return 'bg-blue-100 text-blue-800';
      case 'makeup':
        return 'bg-purple-100 text-purple-800';
      case 'consultation':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const pendingCount = bookings.filter(b => b.status === 'pending').length;
  const upcomingCount = bookings.filter(b => 
    b.status === 'confirmed' && new Date(b.date) >= new Date()
  ).length;

  const availableSlots = selectedDate ? getAvailableTimeSlots(selectedDate) : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Book Extra Classes</h1>
          <p className="text-muted-foreground">
            Request additional tutoring sessions, makeup classes, or consultations
          </p>
        </div>
        <div className="flex gap-2">
          {pendingCount > 0 && (
            <Badge variant="outline" className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {pendingCount} Pending
            </Badge>
          )}
          <Badge variant="outline" className="flex items-center gap-1">
            <CalendarIcon className="w-3 h-3" />
            {upcomingCount} Upcoming
          </Badge>
        </div>
      </div>

      <Tabs defaultValue="book" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="book">Book Session</TabsTrigger>
          <TabsTrigger value="bookings">My Bookings</TabsTrigger>
          <TabsTrigger value="availability">Check Availability</TabsTrigger>
        </TabsList>

        <TabsContent value="book" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Booking Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="w-5 h-5" />
                  Request New Session
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Session Type *</label>
                  <Select value={newBooking.type} onValueChange={(value: any) => setNewBooking({ ...newBooking, type: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="extra-class">Extra Class</SelectItem>
                      <SelectItem value="makeup">Makeup Session</SelectItem>
                      <SelectItem value="consultation">Consultation</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Subject *</label>
                  <Select value={newBooking.subject} onValueChange={(value) => setNewBooking({ ...newBooking, subject: value, teacher: 'no-preference' })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select subject" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.keys(teachersBySubject).map((subject) => (
                        <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Preferred Teacher</label>
                  <Select 
                    value={newBooking.teacher} 
                    onValueChange={(value) => setNewBooking({ ...newBooking, teacher: value })}
                    disabled={!newBooking.subject}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={newBooking.subject ? "Select teacher" : "Select subject first"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="no-preference">No preference</SelectItem>
                      {newBooking.subject && teachersBySubject[newBooking.subject as keyof typeof teachersBySubject]?.map((teacher) => (
                        <SelectItem key={teacher} value={teacher}>{teacher}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Preferred Date</label>
                    <Input
                      type="date"
                      value={newBooking.date}
                      onChange={(e) => setNewBooking({ ...newBooking, date: e.target.value })}
                      min={new Date().toISOString().split('T')[0]}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Preferred Time</label>
                    <Input
                      type="time"
                      value={newBooking.time}
                      onChange={(e) => setNewBooking({ ...newBooking, time: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Duration (hours)</label>
                  <Select value={newBooking.duration} onValueChange={(value) => setNewBooking({ ...newBooking, duration: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0.5">30 minutes</SelectItem>
                      <SelectItem value="1">1 hour</SelectItem>
                      <SelectItem value="1.5">1.5 hours</SelectItem>
                      <SelectItem value="2">2 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Reason for Request *</label>
                  <Textarea
                    placeholder="Please explain why you need this additional session..."
                    value={newBooking.reason}
                    onChange={(e) => setNewBooking({ ...newBooking, reason: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Additional Notes</label>
                  <Textarea
                    placeholder="Any specific topics you'd like to focus on or other requirements..."
                    value={newBooking.notes}
                    onChange={(e) => setNewBooking({ ...newBooking, notes: e.target.value })}
                  />
                </div>

                <Button onClick={handleCreateBooking} className="w-full">
                  Submit Booking Request
                </Button>
              </CardContent>
            </Card>

            {/* Booking Guidelines */}
            <Card>
              <CardHeader>
                <CardTitle>Booking Guidelines</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <h4 className="font-medium text-sm">Session Types:</h4>
                    <ul className="text-sm text-muted-foreground space-y-1 mt-1">
                      <li><strong>Extra Class:</strong> Additional tutoring for better understanding</li>
                      <li><strong>Makeup Session:</strong> Replacement for missed regular classes</li>
                      <li><strong>Consultation:</strong> One-on-one discussion with tutor</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-sm">Booking Timeline:</h4>
                    <ul className="text-sm text-muted-foreground space-y-1 mt-1">
                      <li>• Submit requests at least 24 hours in advance</li>
                      <li>• Emergency requests may be accommodated</li>
                      <li>• Cancellations require 2 hours notice</li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm">Response Time:</h4>
                    <p className="text-sm text-muted-foreground">
                      Staff will review and respond to your request within 4-6 hours during business hours.
                    </p>
                  </div>
                </div>

                <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-800">
                    <strong>Tip:</strong> If you're flexible with timing, leave the date and time fields empty 
                    and mention your availability in the notes. This helps staff find the best slot for you.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="bookings" className="space-y-4">
          {bookings.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <CalendarIcon className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Bookings Yet</h3>
                <p className="text-muted-foreground mb-4">
                  You haven't made any booking requests yet.
                </p>
                <Button onClick={() => document.querySelector('[value="book"]')?.click()}>
                  Book Your First Session
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {bookings.map((booking) => (
                <Card key={booking.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-medium">{booking.subject}</h3>
                          <Badge className={getTypeColor(booking.type)}>
                            {booking.type.charAt(0).toUpperCase() + booking.type.slice(1).replace('-', ' ')}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <User className="w-3 h-3" />
                            {booking.teacher}
                          </span>
                          <span className="flex items-center gap-1">
                            <CalendarIcon className="w-3 h-3" />
                            {booking.date === 'Flexible' ? 'Flexible date' : new Date(booking.date).toLocaleDateString('en-NZ')}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {booking.time === 'To be scheduled' ? 'Time TBD' : booking.time} ({booking.duration}h)
                          </span>
                        </div>
                      </div>
                      <Badge variant="outline" className={`flex items-center gap-1 ${getStatusColor(booking.status)}`}>
                        {getStatusIcon(booking.status)}
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium mb-1">Reason for Request:</h4>
                      <p className="text-sm text-muted-foreground">{booking.reason}</p>
                    </div>

                    {booking.notes && (
                      <div>
                        <h4 className="text-sm font-medium mb-1">Additional Notes:</h4>
                        <p className="text-sm text-muted-foreground">{booking.notes}</p>
                      </div>
                    )}

                    {booking.room && (
                      <div className="flex items-center gap-1 text-sm">
                        <MapPin className="w-3 h-3" />
                        <span className="font-medium">Location:</span>
                        <span>{booking.room}</span>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-2 text-xs text-muted-foreground border-t">
                      <span>Requested: {new Date(booking.requestDate).toLocaleDateString('en-NZ')}</span>
                      {booking.status === 'pending' && (
                        <Button variant="outline" size="sm">Cancel Request</Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="availability" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Calendar */}
            <Card>
              <CardHeader>
                <CardTitle>Select Date</CardTitle>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border"
                  disabled={(date) => date < new Date()}
                />
              </CardContent>
            </Card>

            {/* Available Time Slots */}
            <Card>
              <CardHeader>
                <CardTitle>
                  Available Time Slots
                  {selectedDate && (
                    <span className="text-sm font-normal text-muted-foreground ml-2">
                      {selectedDate.toLocaleDateString('en-NZ')}
                    </span>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedDate ? (
                  <div className="space-y-2">
                    {availableSlots.map((slot, index) => (
                      <div 
                        key={index}
                        className={`flex items-center justify-between p-3 rounded-lg border ${
                          slot.available 
                            ? 'bg-green-50 border-green-200' 
                            : 'bg-red-50 border-red-200 opacity-60'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <Clock className={`w-4 h-4 ${slot.available ? 'text-green-600' : 'text-red-600'}`} />
                          <span className="font-medium">{slot.time}</span>
                          {slot.teacher && slot.available && (
                            <span className="text-sm text-muted-foreground">• {slot.teacher}</span>
                          )}
                        </div>
                        <Badge variant={slot.available ? "default" : "secondary"}>
                          {slot.available ? 'Available' : 'Booked'}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-8">
                    Select a date to view available time slots
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}