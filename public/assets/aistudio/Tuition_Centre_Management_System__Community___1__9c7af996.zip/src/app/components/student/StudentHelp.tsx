import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { 
  Phone, 
  Mail, 
  MessageCircle, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Plus,
  Send,
  MapPin,
  Calendar,
  User,
  HelpCircle
} from 'lucide-react';

interface Ticket {
  id: string;
  subject: string;
  description: string;
  category: string;
  priority: 'low' | 'medium' | 'high';
  status: 'open' | 'in-progress' | 'resolved' | 'closed';
  createdDate: string;
  lastUpdated: string;
  assignedTo?: string;
  responses: TicketResponse[];
}

interface TicketResponse {
  id: string;
  author: string;
  authorType: 'student' | 'staff';
  message: string;
  timestamp: string;
}

export function StudentHelp() {
  const [activeTab, setActiveTab] = useState('contact');
  const [newTicket, setNewTicket] = useState({
    subject: '',
    description: '',
    category: '',
    priority: 'medium' as const
  });

  // Demo tickets for Sarah Chen
  const [tickets, setTickets] = useState<Ticket[]>([
    {
      id: '1',
      subject: 'Need help with Physics Lab Equipment',
      description: 'I\'m having trouble setting up the oscilloscope for the wave experiment. Could someone help me understand the correct settings?',
      category: 'Technical Support',
      priority: 'medium',
      status: 'resolved',
      createdDate: '2024-09-20',
      lastUpdated: '2024-09-21',
      assignedTo: 'Mr. James Thompson',
      responses: [
        {
          id: '1',
          author: 'Sarah Chen',
          authorType: 'student',
          message: 'I\'m having trouble setting up the oscilloscope for the wave experiment. Could someone help me understand the correct settings?',
          timestamp: '2024-09-20 14:30'
        },
        {
          id: '2',
          author: 'Mr. James Thompson',
          authorType: 'staff',
          message: 'Hi Sarah! I\'d be happy to help. The oscilloscope settings for our wave experiment should be: Time/div: 0.5ms, Voltage/div: 2V, and make sure the coupling is set to AC. Would you like to schedule a quick session before your next lab?',
          timestamp: '2024-09-20 16:45'
        },
        {
          id: '3',
          author: 'Sarah Chen',
          authorType: 'student',
          message: 'Thank you so much! That worked perfectly. I was able to complete the experiment successfully.',
          timestamp: '2024-09-21 09:15'
        }
      ]
    },
    {
      id: '2',
      subject: 'Schedule Conflict - Math and English',
      description: 'My Math tutorial on Wednesday overlaps with the new English Literature discussion group. Can we find an alternative time?',
      category: 'Scheduling',
      priority: 'high',
      status: 'in-progress',
      createdDate: '2024-09-22',
      lastUpdated: '2024-09-23',
      assignedTo: 'Admin Team',
      responses: [
        {
          id: '1',
          author: 'Sarah Chen',
          authorType: 'student',
          message: 'My Math tutorial on Wednesday overlaps with the new English Literature discussion group. Can we find an alternative time?',
          timestamp: '2024-09-22 10:20'
        },
        {
          id: '2',
          author: 'Admin Team',
          authorType: 'staff',
          message: 'Hi Sarah, we\'re looking into alternative times for your Math tutorial. Dr. Williams has availability on Wednesday at 2 PM or Thursday at 11 AM. Which would work better for you?',
          timestamp: '2024-09-23 11:30'
        }
      ]
    }
  ]);

  const contactInfo = [
    {
      type: 'Phone',
      icon: Phone,
      value: '+64 3 123 4567',
      description: 'Monday to Friday, 8:00 AM - 6:00 PM',
      action: 'Call Now'
    },
    {
      type: 'Email',
      icon: Mail,
      value: 'support@ilamtuition.co.nz',
      description: 'We typically respond within 24 hours',
      action: 'Send Email'
    },
    {
      type: 'Address',
      icon: MapPin,
      value: '123 Education Avenue, Christchurch 8041',
      description: 'Visit us during business hours',
      action: 'Get Directions'
    }
  ];

  const officeHours = [
    { day: 'Monday - Friday', hours: '8:00 AM - 6:00 PM' },
    { day: 'Saturday', hours: '9:00 AM - 4:00 PM' },
    { day: 'Sunday', hours: 'Closed' }
  ];

  const handleCreateTicket = () => {
    if (!newTicket.subject || !newTicket.description || !newTicket.category) {
      alert('Please fill in all required fields');
      return;
    }

    const ticket: Ticket = {
      id: (tickets.length + 1).toString(),
      subject: newTicket.subject,
      description: newTicket.description,
      category: newTicket.category,
      priority: newTicket.priority,
      status: 'open',
      createdDate: new Date().toISOString().split('T')[0],
      lastUpdated: new Date().toISOString().split('T')[0],
      responses: [
        {
          id: '1',
          author: 'Sarah Chen',
          authorType: 'student',
          message: newTicket.description,
          timestamp: new Date().toLocaleString('en-NZ')
        }
      ]
    };

    setTickets([ticket, ...tickets]);
    setNewTicket({ subject: '', description: '', category: '', priority: 'medium' });
    setActiveTab('tickets');
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'open':
        return <AlertCircle className="w-4 h-4 text-blue-600" />;
      case 'in-progress':
        return <Clock className="w-4 h-4 text-yellow-600" />;
      case 'resolved':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'closed':
        return <CheckCircle className="w-4 h-4 text-gray-600" />;
      default:
        return <HelpCircle className="w-4 h-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'in-progress':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'resolved':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'closed':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const openTickets = tickets.filter(t => t.status === 'open' || t.status === 'in-progress').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Request Help</h1>
          <p className="text-muted-foreground">
            Get support from our team or raise a ticket for assistance
          </p>
        </div>
        {openTickets > 0 && (
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {openTickets} Open Ticket{openTickets !== 1 ? 's' : ''}
          </Badge>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="contact">Contact Info</TabsTrigger>
          <TabsTrigger value="tickets">My Tickets</TabsTrigger>
          <TabsTrigger value="new-ticket">New Ticket</TabsTrigger>
        </TabsList>

        <TabsContent value="contact" className="space-y-6">
          {/* Contact Information */}
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5" />
                  Get in Touch
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {contactInfo.map((contact, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <contact.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">{contact.type}</h4>
                      <p className="text-primary">{contact.value}</p>
                      <p className="text-sm text-muted-foreground">{contact.description}</p>
                    </div>
                    <Button variant="outline" size="sm">
                      {contact.action}
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Office Hours
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {officeHours.map((schedule, index) => (
                    <div key={index} className="flex justify-between items-center py-2 border-b last:border-b-0">
                      <span className="font-medium">{schedule.day}</span>
                      <span className="text-muted-foreground">{schedule.hours}</span>
                    </div>
                  ))}
                </div>
                <div className="mt-4 p-3 bg-muted/30 rounded-lg">
                  <p className="text-sm">
                    <strong>Emergency Support:</strong> For urgent academic matters outside office hours, 
                    contact your assigned tutor directly or submit a high-priority ticket.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 md:grid-cols-3">
                <Button variant="outline" className="flex items-center gap-2" onClick={() => setActiveTab('new-ticket')}>
                  <Plus className="w-4 h-4" />
                  Create New Ticket
                </Button>
                <Button variant="outline" className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Book Consultation
                </Button>
                <Button variant="outline" className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  Request Callback
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tickets" className="space-y-4">
          {tickets.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <HelpCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Support Tickets</h3>
                <p className="text-muted-foreground mb-4">
                  You haven't created any support tickets yet.
                </p>
                <Button onClick={() => setActiveTab('new-ticket')}>
                  Create Your First Ticket
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {tickets.map((ticket) => (
                <Card key={ticket.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-medium">{ticket.subject}</h3>
                          <Badge className={getPriorityColor(ticket.priority)}>
                            {ticket.priority.charAt(0).toUpperCase() + ticket.priority.slice(1)}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            Created: {new Date(ticket.createdDate).toLocaleDateString('en-NZ')}
                          </span>
                          <span>Category: {ticket.category}</span>
                          {ticket.assignedTo && (
                            <span className="flex items-center gap-1">
                              <User className="w-3 h-3" />
                              Assigned to: {ticket.assignedTo}
                            </span>
                          )}
                        </div>
                      </div>
                      <Badge variant="outline" className={`flex items-center gap-1 ${getStatusColor(ticket.status)}`}>
                        {getStatusIcon(ticket.status)}
                        {ticket.status.charAt(0).toUpperCase() + ticket.status.slice(1).replace('-', ' ')}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Ticket Responses */}
                      <div className="space-y-3">
                        {ticket.responses.map((response) => (
                          <div key={response.id} className={`flex gap-3 ${
                            response.authorType === 'student' ? 'justify-end' : 'justify-start'
                          }`}>
                            <div className={`max-w-[80%] ${
                              response.authorType === 'student' ? 'order-2' : 'order-1'
                            }`}>
                              <div className={`p-3 rounded-lg ${
                                response.authorType === 'student' 
                                  ? 'bg-primary text-primary-foreground' 
                                  : 'bg-muted'
                              }`}>
                                <p className="text-sm">{response.message}</p>
                              </div>
                              <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                                <span>{response.author}</span>
                                <span>•</span>
                                <span>{response.timestamp}</span>
                              </div>
                            </div>
                            <Avatar className={`w-8 h-8 ${
                              response.authorType === 'student' ? 'order-1' : 'order-2'
                            }`}>
                              <AvatarFallback className="text-xs">
                                {response.author.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                          </div>
                        ))}
                      </div>

                      {/* Reply Section for Open Tickets */}
                      {(ticket.status === 'open' || ticket.status === 'in-progress') && (
                        <div className="flex gap-2 pt-3 border-t">
                          <Input placeholder="Type your reply..." className="flex-1" />
                          <Button size="sm" className="flex items-center gap-1">
                            <Send className="w-3 h-3" />
                            Reply
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="new-ticket" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Create New Support Ticket
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Describe your issue and our team will help you as soon as possible.
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Subject *</label>
                  <Input
                    placeholder="Brief description of your issue"
                    value={newTicket.subject}
                    onChange={(e) => setNewTicket({ ...newTicket, subject: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Category *</label>
                  <Select value={newTicket.category} onValueChange={(value) => setNewTicket({ ...newTicket, category: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Academic Support">Academic Support</SelectItem>
                      <SelectItem value="Technical Support">Technical Support</SelectItem>
                      <SelectItem value="Scheduling">Scheduling</SelectItem>
                      <SelectItem value="Payment/Billing">Payment/Billing</SelectItem>
                      <SelectItem value="General Inquiry">General Inquiry</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Priority</label>
                <Select value={newTicket.priority} onValueChange={(value: 'low' | 'medium' | 'high') => setNewTicket({ ...newTicket, priority: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low - Can wait a few days</SelectItem>
                    <SelectItem value="medium">Medium - Need help within 24 hours</SelectItem>
                    <SelectItem value="high">High - Urgent, need immediate assistance</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Description *</label>
                <Textarea
                  placeholder="Please provide detailed information about your issue, including any error messages or steps you've already tried..."
                  className="min-h-[120px]"
                  value={newTicket.description}
                  onChange={(e) => setNewTicket({ ...newTicket, description: e.target.value })}
                />
              </div>

              <div className="flex gap-2 pt-4">
                <Button onClick={handleCreateTicket} className="flex items-center gap-2">
                  <Send className="w-4 h-4" />
                  Submit Ticket
                </Button>
                <Button variant="outline" onClick={() => setNewTicket({ subject: '', description: '', category: '', priority: 'medium' })}>
                  Clear Form
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}