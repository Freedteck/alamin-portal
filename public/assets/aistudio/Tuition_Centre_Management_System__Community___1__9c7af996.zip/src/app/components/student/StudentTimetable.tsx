import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Clock, MapPin, User, Download, Printer } from 'lucide-react';

interface ClassPeriod {
  time: string;
  subject?: string;
  teacher?: string;
  room?: string;
  color?: string;
}

interface DayTimetable {
  [key: string]: ClassPeriod[];
}

export function StudentTimetable() {
  // Sarah Chen's personal timetable - Grade 7 schedule
  const timetable: DayTimetable = {
    Monday: [
      { time: '08:00-09:00', subject: 'Free Period' },
      { time: '09:00-10:00', subject: 'Mathematics', teacher: 'Ms. Sarah Williams', room: 'Room 101', color: 'bg-blue-100 text-blue-800 border-blue-200' },
      { time: '10:00-10:15', subject: 'Break' },
      { time: '10:15-11:15', subject: 'Science', teacher: 'Mr. James Thompson', room: 'Science Lab', color: 'bg-green-100 text-green-800 border-green-200' },
      { time: '11:15-12:15', subject: 'English', teacher: 'Ms. Emma Clarke', room: 'Room 105', color: 'bg-purple-100 text-purple-800 border-purple-200' },
      { time: '12:15-13:15', subject: 'Lunch Break' },
      { time: '13:15-14:15', subject: 'Te Reo Māori', teacher: 'Whaea Maria Tane', room: 'Room 108', color: 'bg-orange-100 text-orange-800 border-orange-200' },
      { time: '14:15-15:00', subject: 'Free Period' }
    ],
    Tuesday: [
      { time: '08:00-09:00', subject: 'Free Period' },
      { time: '09:00-10:00', subject: 'English', teacher: 'Ms. Emma Clarke', room: 'Room 105', color: 'bg-purple-100 text-purple-800 border-purple-200' },
      { time: '10:00-10:15', subject: 'Break' },
      { time: '10:15-11:15', subject: 'Mathematics', teacher: 'Ms. Sarah Williams', room: 'Room 101', color: 'bg-blue-100 text-blue-800 border-blue-200' },
      { time: '11:15-12:15', subject: 'Free Period' },
      { time: '12:15-13:15', subject: 'Lunch Break' },
      { time: '13:15-14:15', subject: 'Science', teacher: 'Mr. James Thompson', room: 'Science Lab', color: 'bg-green-100 text-green-800 border-green-200' },
      { time: '14:15-15:00', subject: 'Free Period' }
    ],
    Wednesday: [
      { time: '08:00-09:00', subject: 'Free Period' },
      { time: '09:00-10:00', subject: 'Te Reo Māori', teacher: 'Whaea Maria Tane', room: 'Room 108', color: 'bg-orange-100 text-orange-800 border-orange-200' },
      { time: '10:00-10:15', subject: 'Break' },
      { time: '10:15-11:15', subject: 'Mathematics', teacher: 'Ms. Sarah Williams', room: 'Room 101', color: 'bg-blue-100 text-blue-800 border-blue-200' },
      { time: '11:15-12:15', subject: 'English', teacher: 'Ms. Emma Clarke', room: 'Room 105', color: 'bg-purple-100 text-purple-800 border-purple-200' },
      { time: '12:15-13:15', subject: 'Lunch Break' },
      { time: '13:15-14:15', subject: 'Free Period' },
      { time: '14:15-15:00', subject: 'Free Period' }
    ],
    Thursday: [
      { time: '08:00-09:00', subject: 'Free Period' },
      { time: '09:00-10:00', subject: 'Science', teacher: 'Mr. James Thompson', room: 'Science Lab', color: 'bg-green-100 text-green-800 border-green-200' },
      { time: '10:00-10:15', subject: 'Break' },
      { time: '10:15-11:15', subject: 'English', teacher: 'Ms. Emma Clarke', room: 'Room 105', color: 'bg-purple-100 text-purple-800 border-purple-200' },
      { time: '11:15-12:15', subject: 'Mathematics', teacher: 'Ms. Sarah Williams', room: 'Room 101', color: 'bg-blue-100 text-blue-800 border-blue-200' },
      { time: '12:15-13:15', subject: 'Lunch Break' },
      { time: '13:15-14:15', subject: 'Te Reo Māori', teacher: 'Whaea Maria Tane', room: 'Room 108', color: 'bg-orange-100 text-orange-800 border-orange-200' },
      { time: '14:15-15:00', subject: 'Free Period' }
    ],
    Friday: [
      { time: '08:00-09:00', subject: 'Free Period' },
      { time: '09:00-10:00', subject: 'Mathematics', teacher: 'Ms. Sarah Williams', room: 'Room 101', color: 'bg-blue-100 text-blue-800 border-blue-200' },
      { time: '10:00-10:15', subject: 'Break' },
      { time: '10:15-11:15', subject: 'Science', teacher: 'Mr. James Thompson', room: 'Science Lab', color: 'bg-green-100 text-green-800 border-green-200' },
      { time: '11:15-12:15', subject: 'Free Period' },
      { time: '12:15-13:15', subject: 'Lunch Break' },
      { time: '13:15-14:15', subject: 'English', teacher: 'Ms. Emma Clarke', room: 'Room 105', color: 'bg-purple-100 text-purple-800 border-purple-200' },
      { time: '14:15-15:00', subject: 'Free Period' }
    ],
    Saturday: [
      { time: '08:00-09:00', subject: 'Free Period' },
      { time: '09:00-10:00', subject: 'Te Reo Māori', teacher: 'Whaea Maria Tane', room: 'Room 108', color: 'bg-orange-100 text-orange-800 border-orange-200' },
      { time: '10:00-10:15', subject: 'Break' },
      { time: '10:15-11:15', subject: 'Mathematics', teacher: 'Ms. Sarah Williams', room: 'Room 101', color: 'bg-blue-100 text-blue-800 border-blue-200' },
      { time: '11:15-12:15', subject: 'Free Period' },
      { time: '12:15-13:15', subject: 'Lunch Break' },
      { time: '13:15-14:15', subject: 'Free Period' }
    ]
  };

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const currentDate = new Date();
  const currentDay = currentDate.toLocaleDateString('en-NZ', { weekday: 'long' });

  // Get unique time slots across all days for the grid
  const allTimeSlots = Array.from(
    new Set(
      Object.values(timetable)
        .flat()
        .map(period => period.time)
        .filter(time => !time.includes('Break') && !time.includes('Lunch') && !time.includes('Free'))
    )
  ).sort();

  // Calculate total class hours per week
  const totalClassHours = Object.values(timetable)
    .flat()
    .filter(period => period.subject && !period.subject.includes('Free') && !period.subject.includes('Break') && !period.subject.includes('Lunch'))
    .reduce((total, period) => {
      const [start, end] = period.time.split('-');
      const startTime = parseFloat(start.replace(':', '.'));
      const endTime = parseFloat(end.replace(':', '.'));
      return total + (endTime - startTime);
    }, 0);

  // Get class periods for each subject
  const subjectSummary = Object.values(timetable)
    .flat()
    .filter(period => period.subject && !period.subject.includes('Free') && !period.subject.includes('Break') && !period.subject.includes('Lunch'))
    .reduce((acc, period) => {
      const subject = period.subject!;
      if (!acc[subject]) {
        acc[subject] = { count: 0, teacher: period.teacher, hours: 0 };
      }
      acc[subject].count++;
      
      const [start, end] = period.time.split('-');
      const startHour = parseFloat(start.replace(':', '.'));
      const endHour = parseFloat(end.replace(':', '.'));
      acc[subject].hours += (endHour - startHour);
      
      return acc;
    }, {} as Record<string, { count: number; teacher?: string; hours: number }>);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>My Timetable</h1>
          <p className="text-muted-foreground">
            Your personal class schedule at a glance
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Download className="w-3 h-3" />
            Download
          </Button>
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Printer className="w-3 h-3" />
            Print
          </Button>
        </div>
      </div>

      {/* Quick Summary */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">{Object.keys(subjectSummary).length}</div>
            <p className="text-sm text-muted-foreground">Subjects</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">{totalClassHours.toFixed(1)}</div>
            <p className="text-sm text-muted-foreground">Hours/Week</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">
              {Object.values(subjectSummary).reduce((total, subject) => total + subject.count, 0)}
            </div>
            <p className="text-sm text-muted-foreground">Classes/Week</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">6</div>
            <p className="text-sm text-muted-foreground">Study Days</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Compact Timetable */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Weekly Timetable</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <div className="grid grid-cols-7 gap-1 min-w-[700px]">
                  {/* Header */}
                  <div className="p-2 font-medium text-sm border-b">Time</div>
                  {days.map((day) => (
                    <div 
                      key={day} 
                      className={`p-2 font-medium text-sm text-center border-b ${
                        day === currentDay ? 'bg-primary/5 text-primary' : ''
                      }`}
                    >
                      {day}
                    </div>
                  ))}

                  {/* Timetable Body - Simplified */}
                  {['09:00-10:00', '10:00-11:00', '11:00-12:00', '12:00-13:00', '13:00-14:00', '14:00-15:00', '15:00-16:00', '16:00-17:00'].map((timeSlot) => (
                    <div key={timeSlot} className="contents">
                      <div className="p-2 text-xs font-medium border-r border-b bg-muted/30">
                        {timeSlot}
                      </div>
                      {days.map((day) => {
                        // Find the class that overlaps with this time slot
                        const daySchedule = timetable[day] || [];
                        const classInSlot = daySchedule.find(period => {
                          if (!period.subject || period.subject.includes('Free') || period.subject.includes('Break') || period.subject.includes('Lunch')) {
                            return false;
                          }
                          const [classStart, classEnd] = period.time.split('-');
                          const slotStart = timeSlot.split('-')[0];
                          const slotEnd = timeSlot.split('-')[1];
                          
                          return (classStart <= slotStart && classEnd > slotStart) || 
                                 (classStart < slotEnd && classEnd >= slotEnd) ||
                                 (classStart >= slotStart && classEnd <= slotEnd);
                        });

                        return (
                          <div 
                            key={`${day}-${timeSlot}`} 
                            className={`p-1 border-r border-b min-h-[50px] text-xs ${
                              day === currentDay ? 'bg-primary/5' : ''
                            }`}
                          >
                            {classInSlot && (
                              <div className={`p-1 rounded text-xs h-full ${classInSlot.color} border`}>
                                <div className="font-medium truncate">{classInSlot.subject}</div>
                                <div className="truncate opacity-75">{classInSlot.room}</div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Subject Summary */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Subject Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {Object.entries(subjectSummary).map(([subject, info]) => (
                <div key={subject} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-sm">{subject}</span>
                    <Badge variant="outline" className="text-xs">
                      {info.hours}h/week
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground space-y-1">
                    <div className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {info.teacher}
                    </div>
                    <div>{info.count} classes per week</div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Today's Classes */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Today's Classes</CardTitle>
              <p className="text-sm text-muted-foreground">{currentDay}</p>
            </CardHeader>
            <CardContent>
              {timetable[currentDay] ? (
                <div className="space-y-2">
                  {timetable[currentDay]
                    .filter(period => period.subject && !period.subject.includes('Free') && !period.subject.includes('Break') && !period.subject.includes('Lunch'))
                    .map((period, index) => (
                    <div key={index} className={`p-2 rounded-lg border ${period.color}`}>
                      <div className="font-medium text-sm">{period.subject}</div>
                      <div className="text-xs opacity-75 mt-1 space-y-1">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {period.time}
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {period.room}
                        </div>
                        <div className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {period.teacher}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No classes scheduled for today</p>
              )}
            </CardContent>
          </Card>

          {/* Legend */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Subject Colors</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-blue-100 border border-blue-200 rounded"></div>
                <span className="text-sm">Mathematics</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-green-100 border border-green-200 rounded"></div>
                <span className="text-sm">Science</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-purple-100 border border-purple-200 rounded"></div>
                <span className="text-sm">English</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-orange-100 border border-orange-200 rounded"></div>
                <span className="text-sm">Te Reo Māori</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}