import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Button } from '../ui/button';
import { 
  Calendar, 
  Clock, 
  BookOpen, 
  FileText, 
  Bell, 
  TrendingUp,
  CheckCircle,
  AlertCircle,
  Upload
} from 'lucide-react';

export function StudentDashboard() {
  const upcomingClasses = [
    {
      subject: 'Mathematics',
      teacher: 'Ms. Sarah Williams',
      date: 'Today',
      time: '9:00 AM - 10:00 AM',
      room: 'Room 101',
      type: 'Grade 7'
    },
    {
      subject: 'Science',
      teacher: 'Mr. James Thompson',
      date: 'Today',
      time: '2:00 PM - 3:00 PM',
      room: 'Science Lab',
      type: 'Grade 7'
    },
    {
      subject: 'English',
      teacher: 'Ms. Emma Clarke',
      date: 'Tomorrow',
      time: '10:00 AM - 11:00 AM',
      room: 'Room 105',
      type: 'Grade 7'
    },
    {
      subject: 'Te Reo Māori',
      teacher: 'Whaea Maria Tane',
      date: 'Tomorrow',
      time: '1:00 PM - 2:00 PM',
      room: 'Room 108',
      type: 'Grade 7'
    }
  ];

  const recentGrades = [
    { subject: 'Mathematics', assessment: 'Fractions Test', grade: 'A', date: '2024-09-15' },
    { subject: 'Science', assessment: 'Plants Project', grade: 'B+', date: '2024-09-12' },
    { subject: 'English', assessment: 'Story Writing', grade: 'A-', date: '2024-09-10' },
    { subject: 'Te Reo Māori', assessment: 'Vocabulary Quiz', grade: 'B+', date: '2024-09-08' }
  ];

  const pendingAssignments = [
    {
      subject: 'Mathematics',
      title: 'Fractions Practice Worksheet',
      dueDate: '2024-09-25',
      status: 'not-started'
    },
    {
      subject: 'Science',
      title: 'Animal Research Project',
      dueDate: '2024-09-27',
      status: 'in-progress'
    },
    {
      subject: 'English',
      title: 'Creative Story',
      dueDate: '2024-09-30',
      status: 'submitted'
    },
    {
      subject: 'Te Reo Māori',
      title: 'Family Tree (Whakapapa)',
      dueDate: '2024-10-05',
      status: 'not-started'
    }
  ];

  const announcements = [
    {
      title: 'Grade 7 Tests Next Week',
      message: 'Mathematics fractions test on Monday, Science quiz on Wednesday. Check your schedule for details.',
      date: '2024-09-20',
      priority: 'high'
    },
    {
      title: 'Extra Help Sessions Available',
      message: 'Additional help sessions available for Mathematics and Science students after school.',
      date: '2024-09-18',
      priority: 'medium'
    },
    {
      title: 'School Science Fair Coming Up',
      message: 'Start thinking about your science fair projects! Projects due in two weeks.',
      date: '2024-09-15',
      priority: 'low'
    }
  ];

  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'A': return 'bg-green-100 text-green-800';
      case 'A-': return 'bg-green-100 text-green-800';
      case 'B+': return 'bg-blue-100 text-blue-800';
      case 'B': return 'bg-blue-100 text-blue-800';
      case 'B-': return 'bg-yellow-100 text-yellow-800';
      case 'C+': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getAssignmentStatusColor = (status: string) => {
    switch (status) {
      case 'submitted': return 'bg-green-100 text-green-800';
      case 'in-progress': return 'bg-blue-100 text-blue-800';
      case 'not-started': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'medium': return <Bell className="h-4 w-4 text-yellow-500" />;
      default: return <Bell className="h-4 w-4 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1>Student Dashboard</h1>
        <p className="text-muted-foreground">Welcome back! Here's your learning progress and upcoming activities.</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl">4</div>
            <p className="text-xs text-muted-foreground">Subjects Enrolled</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl">87%</div>
            <p className="text-xs text-muted-foreground">Attendance Rate</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl">3</div>
            <p className="text-xs text-muted-foreground">Pending Assignments</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl">B+</div>
            <p className="text-xs text-muted-foreground">Average Grade</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Classes */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Upcoming Classes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingClasses.map((classItem, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div>
                    <div className="font-medium">{classItem.subject}</div>
                    <div className="text-sm text-muted-foreground">{classItem.teacher}</div>
                    <div className="text-sm text-muted-foreground">{classItem.type}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium">{classItem.date}</div>
                    <div className="text-xs text-muted-foreground">{classItem.time}</div>
                    <div className="text-xs text-muted-foreground">{classItem.room}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Grades */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Recent Grades
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentGrades.map((grade, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div>
                    <div className="font-medium">{grade.subject}</div>
                    <div className="text-sm text-muted-foreground">{grade.assessment}</div>
                  </div>
                  <div className="text-right space-y-1">
                    <Badge className={getGradeColor(grade.grade)}>
                      {grade.grade}
                    </Badge>
                    <div className="text-xs text-muted-foreground">{grade.date}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Assignments & Progress */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Assignments & Tasks
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {pendingAssignments.map((assignment, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div className="flex-1">
                    <div className="font-medium text-sm">{assignment.title}</div>
                    <div className="text-sm text-muted-foreground">{assignment.subject}</div>
                    <div className="text-xs text-muted-foreground">Due: {assignment.dueDate}</div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <Badge className={getAssignmentStatusColor(assignment.status)}>
                      {assignment.status === 'not-started' ? 'Not Started' :
                       assignment.status === 'in-progress' ? 'In Progress' : 'Submitted'}
                    </Badge>
                    {assignment.status !== 'submitted' && (
                      <Button size="sm" variant="outline">
                        <Upload className="h-3 w-3 mr-1" />
                        Submit
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Subject Progress */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Subject Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Mathematics - Grade 7</span>
                  <span>85%</span>
                </div>
                <Progress value={85} className="h-2" />
                <div className="text-xs text-muted-foreground mt-1">Great with fractions, practice decimal division</div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Science - Grade 7</span>
                  <span>78%</span>
                </div>
                <Progress value={78} className="h-2" />
                <div className="text-xs text-muted-foreground mt-1">Strong with plants topic, work on animal classification</div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>English - Grade 7</span>
                  <span>82%</span>
                </div>
                <Progress value={82} className="h-2" />
                <div className="text-xs text-muted-foreground mt-1">Excellent creative writing, improve spelling</div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Te Reo Māori - Grade 7</span>
                  <span>75%</span>
                </div>
                <Progress value={75} className="h-2" />
                <div className="text-xs text-muted-foreground mt-1">Good vocabulary, practice pronunciation</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Announcements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Recent Announcements
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {announcements.map((announcement, index) => (
              <div key={index} className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                {getPriorityIcon(announcement.priority)}
                <div className="flex-1">
                  <div className="font-medium text-sm">{announcement.title}</div>
                  <div className="text-sm text-muted-foreground mt-1">{announcement.message}</div>
                  <div className="text-xs text-muted-foreground mt-2">{announcement.date}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}