import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Separator } from '../ui/separator';
import { 
  Megaphone, 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  BookOpen,
  PartyPopper,
  AlertTriangle,
  Info,
  Star,
  Gift,
  Trophy,
  Heart,
  Bell
} from 'lucide-react';

interface Announcement {
  id: string;
  title: string;
  content: string;
  type: 'general' | 'event' | 'test' | 'birthday' | 'achievement' | 'urgent';
  author: string;
  authorRole: string;
  date: string;
  expiryDate?: string;
  isPinned: boolean;
  targetAudience: string[];
  eventDate?: string;
  eventTime?: string;
  location?: string;
  attachments?: string[];
}

export function StudentAnnouncements() {
  // Demo announcements for the tuition center
  const announcements: Announcement[] = [
    {
      id: '1',
      title: '🎉 Monthly Math Challenge - October 2024',
      content: 'Get ready for our exciting monthly math challenge! This month we\'re focusing on calculus problems. Prizes for top 3 performers include scientific calculators and math reference books. All students welcome to participate!',
      type: 'event',
      author: 'Dr. Sarah Williams',
      authorRole: 'Mathematics Coordinator',
      date: '2024-09-24',
      eventDate: '2024-10-15',
      eventTime: '3:00 PM - 5:00 PM',
      location: 'Main Hall',
      isPinned: true,
      targetAudience: ['All Students'],
      attachments: ['math-challenge-rules.pdf']
    },
    {
      id: '2',
      title: '📝 Physics Mid-term Exam Schedule',
      content: 'The Physics mid-term examinations are scheduled for next week. Please review the thermodynamics chapters and practice problem sets. Study groups are available in the library from 6-8 PM daily.',
      type: 'test',
      author: 'Mr. James Thompson',
      authorRole: 'Physics Teacher',
      date: '2024-09-23',
      eventDate: '2024-10-05',
      eventTime: '2:00 PM',
      location: 'Lab 202',
      isPinned: true,
      targetAudience: ['Physics Students'],
      attachments: ['physics-exam-guide.pdf', 'formula-sheet.pdf']
    },
    {
      id: '3',
      title: '🎂 Birthday Wishes - September Celebrants!',
      content: 'Let\'s celebrate our September birthday stars! 🌟 Happy Birthday to Emma Watson (Sept 28), Liam Chen (Sept 30), and Priya Patel (Sept 25). Don\'t forget to join us for cake in the common room during lunch break!',
      type: 'birthday',
      author: 'Student Council',
      authorRole: 'Student Activities',
      date: '2024-09-25',
      eventDate: '2024-09-28',
      eventTime: '12:30 PM',
      location: 'Common Room',
      isPinned: false,
      targetAudience: ['All Students']
    },
    {
      id: '4',
      title: '📚 Study Group Formation - English Literature',
      content: 'Ms. Clarke is organizing study groups for the upcoming poetry analysis assessment. Groups will meet twice weekly to discuss poetic devices, themes, and practice comparative analysis. Limited spots available!',
      type: 'event',
      author: 'Ms. Emma Clarke',
      authorRole: 'English Literature Teacher',
      date: '2024-09-22',
      eventDate: '2024-09-26',
      eventTime: '4:00 PM',
      location: 'Room 305',
      isPinned: false,
      targetAudience: ['English Literature Students']
    },
    {
      id: '5',
      title: '🏆 Congratulations to Our Academic Stars!',
      content: 'Outstanding performance in the recent assessments! Special recognition to Sarah Chen (Mathematics Excellence), Michael Zhang (Physics Innovation Award), and Amy Liu (Literature Analysis Prize). Your dedication inspires us all!',
      type: 'achievement',
      author: 'Academic Office',
      authorRole: 'Administration',
      date: '2024-09-21',
      isPinned: false,
      targetAudience: ['All Students', 'Staff']
    },
    {
      id: '6',
      title: '⚠️ Library Schedule Change',
      content: 'Due to maintenance work, the library will close early at 6:00 PM instead of 8:00 PM on Wednesday, October 2nd. Study rooms will remain available until normal closing time. Plan accordingly!',
      type: 'urgent',
      author: 'Library Staff',
      authorRole: 'Support Services',
      date: '2024-09-20',
      expiryDate: '2024-10-02',
      isPinned: true,
      targetAudience: ['All Students', 'Staff']
    },
    {
      id: '7',
      title: '🎭 Drama Club Performance - "A Midsummer Night\'s Dream"',
      content: 'Our talented drama club presents Shakespeare\'s beloved comedy! Join us for an evening of laughter and brilliant performances. Tickets are $5 for students and $10 for adults. Proceeds support the arts program.',
      type: 'event',
      author: 'Drama Club',
      authorRole: 'Student Activities',
      date: '2024-09-19',
      eventDate: '2024-10-12',
      eventTime: '7:00 PM',
      location: 'School Theater',
      isPinned: false,
      targetAudience: ['All Students', 'Parents', 'Staff']
    },
    {
      id: '8',
      title: '💡 Science Fair 2024 - Call for Participants',
      content: 'Unleash your scientific creativity! The annual science fair is accepting project proposals. Categories include Physics, Chemistry, Biology, and Environmental Science. Mentorship available from our experienced teachers.',
      type: 'event',
      author: 'Science Department',
      authorRole: 'Science Coordinators',
      date: '2024-09-18',
      eventDate: '2024-11-15',
      location: 'Science Wing',
      isPinned: false,
      targetAudience: ['Science Students']
    },
    {
      id: '9',
      title: '🌟 New Student Welcome Event',
      content: 'Welcome to our newest students joining this term! Join us for a meet and greet session with games, refreshments, and introduction to school facilities. Current students are encouraged to be buddy mentors.',
      type: 'event',
      author: 'Student Services',
      authorRole: 'Student Support',
      date: '2024-09-17',
      eventDate: '2024-09-29',
      eventTime: '11:00 AM - 1:00 PM',
      location: 'Main Courtyard',
      isPinned: false,
      targetAudience: ['New Students', 'Volunteer Mentors']
    },
    {
      id: '10',
      title: '🍕 Friday Food Festival',
      content: 'End the week on a delicious note! Our monthly food festival features cuisines from around the world. This month: Italian theme with pizza, pasta, and gelato. Funds raised go to our scholarship program.',
      type: 'event',
      author: 'Parent Association',
      authorRole: 'Community Events',
      date: '2024-09-16',
      eventDate: '2024-09-27',
      eventTime: '12:00 PM - 2:00 PM',
      location: 'Cafeteria',
      isPinned: false,
      targetAudience: ['All Students', 'Staff', 'Parents']
    }
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'event': return <Calendar className="w-4 h-4" />;
      case 'test': return <BookOpen className="w-4 h-4" />;
      case 'birthday': return <PartyPopper className="w-4 h-4" />;
      case 'achievement': return <Trophy className="w-4 h-4" />;
      case 'urgent': return <AlertTriangle className="w-4 h-4" />;
      default: return <Info className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'event': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'test': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'birthday': return 'bg-pink-100 text-pink-800 border-pink-200';
      case 'achievement': return 'bg-green-100 text-green-800 border-green-200';
      case 'urgent': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeBgColor = (type: string) => {
    switch (type) {
      case 'event': return 'bg-blue-50 border-blue-200';
      case 'test': return 'bg-orange-50 border-orange-200';
      case 'birthday': return 'bg-pink-50 border-pink-200';
      case 'achievement': return 'bg-green-50 border-green-200';
      case 'urgent': return 'bg-red-50 border-red-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  const formatTypeLabel = (type: string) => {
    switch (type) {
      case 'test': return 'Exam/Test';
      case 'birthday': return 'Birthday';
      case 'achievement': return 'Achievement';
      case 'urgent': return 'Important';
      case 'event': return 'Event';
      default: return 'General';
    }
  };

  // Sort announcements: pinned first, then by date (newest first)
  const sortedAnnouncements = [...announcements].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return new Date(b.date).getTime() - new Date(a.date).getTime();
  });

  const pinnedCount = announcements.filter(a => a.isPinned).length;
  const activeEvents = announcements.filter(a => 
    a.eventDate && new Date(a.eventDate) >= new Date()
  ).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Announcements</h1>
          <p className="text-muted-foreground">
            Stay updated with school news, events, and important information
          </p>
        </div>
        <div className="flex gap-2">
          {pinnedCount > 0 && (
            <Badge variant="outline" className="flex items-center gap-1">
              <Star className="w-3 h-3" />
              {pinnedCount} Pinned
            </Badge>
          )}
          <Badge variant="outline" className="flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            {activeEvents} Upcoming Event{activeEvents !== 1 ? 's' : ''}
          </Badge>
        </div>
      </div>

      {/* Quick Filter Buttons */}
      <div className="flex flex-wrap gap-2">
        <Button variant="outline" size="sm" className="flex items-center gap-1">
          <Megaphone className="w-3 h-3" />
          All
        </Button>
        <Button variant="outline" size="sm" className="flex items-center gap-1">
          <Calendar className="w-3 h-3" />
          Events
        </Button>
        <Button variant="outline" size="sm" className="flex items-center gap-1">
          <BookOpen className="w-3 h-3" />
          Exams
        </Button>
        <Button variant="outline" size="sm" className="flex items-center gap-1">
          <PartyPopper className="w-3 h-3" />
          Celebrations
        </Button>
        <Button variant="outline" size="sm" className="flex items-center gap-1">
          <Trophy className="w-3 h-3" />
          Achievements
        </Button>
      </div>

      <div className="space-y-4">
        {sortedAnnouncements.map((announcement) => (
          <Card key={announcement.id} className={`${announcement.isPinned ? 'ring-2 ring-primary/20' : ''} ${getTypeBgColor(announcement.type)}`}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2">
                    {announcement.isPinned && (
                      <Star className="w-4 h-4 text-yellow-600 fill-yellow-200" />
                    )}
                    <CardTitle className="text-lg flex items-center gap-2">
                      {announcement.title}
                    </CardTitle>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Avatar className="w-4 h-4">
                        <AvatarFallback className="text-xs">
                          {announcement.author.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      {announcement.author} • {announcement.authorRole}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(announcement.date).toLocaleDateString('en-NZ')}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={`flex items-center gap-1 ${getTypeColor(announcement.type)}`}>
                    {getTypeIcon(announcement.type)}
                    {formatTypeLabel(announcement.type)}
                  </Badge>
                  {announcement.type === 'urgent' && (
                    <Bell className="w-4 h-4 text-red-600" />
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">{announcement.content}</p>
              
              {/* Event Details */}
              {(announcement.eventDate || announcement.location) && (
                <div className="bg-background/50 p-3 rounded-lg border">
                  <h4 className="font-medium text-sm mb-2 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    Event Details
                  </h4>
                  <div className="space-y-1 text-sm">
                    {announcement.eventDate && (
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3 h-3 text-muted-foreground" />
                        <span>{new Date(announcement.eventDate).toLocaleDateString('en-NZ', { 
                          weekday: 'long', 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}</span>
                      </div>
                    )}
                    {announcement.eventTime && (
                      <div className="flex items-center gap-2">
                        <Clock className="w-3 h-3 text-muted-foreground" />
                        <span>{announcement.eventTime}</span>
                      </div>
                    )}
                    {announcement.location && (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3 h-3 text-muted-foreground" />
                        <span>{announcement.location}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Target Audience */}
              <div className="flex items-center gap-2">
                <Users className="w-3 h-3 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">For:</span>
                <div className="flex gap-1">
                  {announcement.targetAudience.map((audience, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {audience}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Attachments */}
              {announcement.attachments && announcement.attachments.length > 0 && (
                <div>
                  <h4 className="font-medium text-sm mb-2">Attachments</h4>
                  <div className="flex gap-2">
                    {announcement.attachments.map((attachment, index) => (
                      <Button key={index} variant="outline" size="sm" className="text-xs">
                        📎 {attachment}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {/* Expiry Notice */}
              {announcement.expiryDate && (
                <div className="text-xs text-muted-foreground border-t pt-2">
                  <span className="flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" />
                    This announcement expires on {new Date(announcement.expiryDate).toLocaleDateString('en-NZ')}
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Load More Button */}
      <div className="text-center pt-4">
        <Button variant="outline">
          Load More Announcements
        </Button>
      </div>
    </div>
  );
}