import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Clock, 
  Award, 
  Target,
  BookOpen,
  AlertCircle,
  CheckCircle,
  BarChart3,
  Download,
  Eye
} from 'lucide-react';

interface TestResult {
  id: string;
  subject: string;
  testName: string;
  date: string;
  score: number;
  maxScore: number;
  percentage: number;
  grade: string;
  teacher: string;
  feedback?: string;
  topicsStrong: string[];
  topicsImprove: string[];
}

interface UpcomingTest {
  id: string;
  subject: string;
  testName: string;
  date: string;
  time: string;
  duration: string;
  topics: string[];
  teacher: string;
  room?: string;
  instructions?: string;
}

export function StudentProgressReports() {
  // Demo test results for Sarah Chen (Grade 7 student)
  const testResults: TestResult[] = [
    {
      id: '1',
      subject: 'Mathematics',
      testName: 'Fractions and Decimals Test',
      date: '2024-09-20',
      score: 87,
      maxScore: 100,
      percentage: 87,
      grade: 'A-',
      teacher: 'Ms. Sarah Williams',
      feedback: 'Excellent understanding of fraction operations. Your decimal conversion skills are strong. Focus on mixed number calculations for even better results.',
      topicsStrong: ['Adding fractions', 'Decimal multiplication', 'Word problems'],
      topicsImprove: ['Mixed numbers', 'Complex fraction division']
    },
    {
      id: '2',
      subject: 'Science',
      testName: 'Plants and Animals Quiz',
      date: '2024-09-15',
      score: 76,
      maxScore: 90,
      percentage: 84,
      grade: 'B+',
      teacher: 'Mr. James Thompson',
      feedback: 'Good understanding of plant and animal classification. Your diagrams are clear and accurate. Work on learning more scientific vocabulary.',
      topicsStrong: ['Animal groups', 'Plant parts', 'Life cycles'],
      topicsImprove: ['Scientific names', 'Habitat descriptions']
    },
    {
      id: '3',
      subject: 'English',
      testName: 'Story Writing Assessment',
      date: '2024-09-10',
      score: 92,
      maxScore: 100,
      percentage: 92,
      grade: 'A',
      teacher: 'Ms. Emma Clarke',
      feedback: 'Outstanding creative writing! Your story has a clear beginning, middle, and end. Great use of descriptive language and dialogue.',
      topicsStrong: ['Story structure', 'Character development', 'Descriptive writing'],
      topicsImprove: ['Punctuation', 'Paragraph transitions']
    },
    {
      id: '4',
      subject: 'Te Reo Māori',
      testName: 'Basic Vocabulary Test',
      date: '2024-09-05',
      score: 68,
      maxScore: 80,
      percentage: 85,
      grade: 'B+',
      teacher: 'Whaea Maria Tane',
      feedback: 'Ka pai! Good progress with basic vocabulary. Keep practicing pronunciation and try using more Māori phrases in conversation.',
      topicsStrong: ['Family words', 'Colours', 'Numbers 1-20'],
      topicsImprove: ['Pronunciation', 'Simple sentences']
    },
    {
      id: '5',
      subject: 'Mathematics',
      testName: 'Shapes and Measurement',
      date: '2024-08-28',
      score: 94,
      maxScore: 100,
      percentage: 94,
      grade: 'A',
      teacher: 'Ms. Sarah Williams',
      feedback: 'Excellent work with geometry! You understand area and perimeter very well. Keep up the great measuring skills.',
      topicsStrong: ['Area calculations', 'Shape identification', 'Unit conversion'],
      topicsImprove: ['Complex shapes', 'Volume concepts']
    }
  ];

  // Demo upcoming tests
  const upcomingTests: UpcomingTest[] = [
    {
      id: '1',
      subject: 'Mathematics',
      testName: 'Percentages and Ratios Test',
      date: '2024-09-30',
      time: '10:00 AM',
      duration: '1 hour',
      topics: ['Converting percentages', 'Simple ratios', 'Proportion problems', 'Real-world applications'],
      teacher: 'Ms. Sarah Williams',
      room: 'Room 101',
      instructions: 'Calculator allowed. Bring spare pens and pencils.'
    },
    {
      id: '2',
      subject: 'Science',
      testName: 'Earth and Space Quiz',
      date: '2024-10-05',
      time: '2:00 PM',
      duration: '45 minutes',
      topics: ['Solar system', 'Day and night', 'Seasons', 'Moon phases'],
      teacher: 'Mr. James Thompson',
      room: 'Science Room',
      instructions: 'Study your planet fact sheets. Diagrams will be provided.'
    },
    {
      id: '3',
      subject: 'English',
      testName: 'Reading Comprehension Test',
      date: '2024-10-08',
      time: '11:00 AM',
      duration: '1 hour',
      topics: ['Main ideas', 'Supporting details', 'Making inferences', 'Vocabulary in context'],
      teacher: 'Ms. Emma Clarke',
      room: 'Room 305',
      instructions: 'Read carefully and answer all questions. Check your work.'
    },
    {
      id: '4',
      subject: 'Te Reo Māori',
      testName: 'Greetings and Introductions',
      date: '2024-10-10',
      time: '9:00 AM',
      duration: '30 minutes',
      topics: ['Formal greetings', 'Introducing yourself', 'Basic questions', 'Polite responses'],
      teacher: 'Whaea Maria Tane',
      room: 'Room 201',
      instructions: 'Part of the test will be spoken. Practice your pronunciation.'
    }
  ];

  // Calculate performance statistics
  const subjectAverages = testResults.reduce((acc, test) => {
    if (!acc[test.subject]) {
      acc[test.subject] = { total: 0, count: 0, scores: [] };
    }
    acc[test.subject].total += test.percentage;
    acc[test.subject].count += 1;
    acc[test.subject].scores.push(test.percentage);
    return acc;
  }, {} as Record<string, { total: number; count: number; scores: number[] }>);

  const getSubjectAverage = (subject: string) => {
    const data = subjectAverages[subject];
    return data ? Math.round(data.total / data.count) : 0;
  };

  const getTrend = (subject: string) => {
    const scores = subjectAverages[subject]?.scores || [];
    if (scores.length < 2) return null;
    const recent = scores.slice(-2);
    return recent[1] > recent[0] ? 'up' : recent[1] < recent[0] ? 'down' : 'stable';
  };

  const getGradeColor = (grade: string) => {
    switch (grade.charAt(0)) {
      case 'A': return 'bg-green-100 text-green-800 border-green-200';
      case 'B': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'C': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'D': return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-red-100 text-red-800 border-red-200';
    }
  };

  const getSubjectColor = (subject: string) => {
    switch (subject) {
      case 'Mathematics': return 'bg-blue-100 text-blue-800';
      case 'Science': return 'bg-green-100 text-green-800';
      case 'English': return 'bg-purple-100 text-purple-800';
      case 'Te Reo Māori': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const overallAverage = Math.round(
    testResults.reduce((sum, test) => sum + test.percentage, 0) / testResults.length
  );

  const upcomingCount = upcomingTests.length;
  const recentTests = testResults.slice(0, 3);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Progress Reports</h1>
          <p className="text-muted-foreground">
            Track your academic performance and upcoming assessments
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline" className="flex items-center gap-1">
            <AlertCircle className="w-3 h-3" />
            {upcomingCount} Upcoming Test{upcomingCount !== 1 ? 's' : ''}
          </Badge>
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Download className="w-3 h-3" />
            Download Report
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Overall Average</p>
                <p className="text-2xl font-bold text-primary">{overallAverage}%</p>
              </div>
              <Award className="w-8 h-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Tests Completed</p>
                <p className="text-2xl font-bold text-primary">{testResults.length}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Best Score</p>
                <p className="text-2xl font-bold text-primary">
                  {Math.max(...testResults.map(t => t.percentage))}%
                </p>
              </div>
              <Target className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Subjects</p>
                <p className="text-2xl font-bold text-primary">{Object.keys(subjectAverages).length}</p>
              </div>
              <BookOpen className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="results" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="results">Test Results</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming Tests</TabsTrigger>
          <TabsTrigger value="analytics">Performance Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="results" className="space-y-4">
          <div className="space-y-4">
            {testResults.map((test) => (
              <Card key={test.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-lg">{test.testName}</CardTitle>
                        <Badge className={getSubjectColor(test.subject)}>
                          {test.subject}
                        </Badge>
                        <Badge variant="outline" className={getGradeColor(test.grade)}>
                          {test.grade}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(test.date).toLocaleDateString('en-NZ')}
                        </span>
                        <span className="flex items-center gap-1">
                          <Avatar className="w-4 h-4">
                            <AvatarFallback className="text-xs">
                              {test.teacher.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          {test.teacher}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">{test.score}/{test.maxScore}</div>
                      <div className="text-sm text-muted-foreground">{test.percentage}%</div>
                      <Progress value={test.percentage} className="w-20 mt-1" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {test.feedback && (
                    <div className="bg-muted/30 p-4 rounded-lg">
                      <h4 className="font-medium mb-2">Teacher Feedback</h4>
                      <p className="text-sm">{test.feedback}</p>
                    </div>
                  )}
                  
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <h4 className="font-medium text-sm mb-2 flex items-center gap-1 text-green-700">
                        <CheckCircle className="w-3 h-3" />
                        Strengths
                      </h4>
                      <ul className="text-sm space-y-1">
                        {test.topicsStrong.map((topic, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="w-1 h-1 rounded-full bg-green-600 mt-2 flex-shrink-0" />
                            {topic}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium text-sm mb-2 flex items-center gap-1 text-orange-700">
                        <Target className="w-3 h-3" />
                        Areas for Improvement
                      </h4>
                      <ul className="text-sm space-y-1">
                        {test.topicsImprove.map((topic, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="w-1 h-1 rounded-full bg-orange-600 mt-2 flex-shrink-0" />
                            {topic}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button variant="outline" size="sm" className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      View Full Results
                    </Button>
                    <Button variant="outline" size="sm" className="flex items-center gap-1">
                      <Download className="w-3 h-3" />
                      Download
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="upcoming" className="space-y-4">
          {upcomingTests.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Upcoming Tests</h3>
                <p className="text-muted-foreground">
                  You're all caught up! No tests scheduled at the moment.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {upcomingTests.map((test) => (
                <Card key={test.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <CardTitle className="text-lg">{test.testName}</CardTitle>
                          <Badge className={getSubjectColor(test.subject)}>
                            {test.subject}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {new Date(test.date).toLocaleDateString('en-NZ')}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {test.time} ({test.duration})
                          </span>
                          <span className="flex items-center gap-1">
                            <Avatar className="w-4 h-4">
                              <AvatarFallback className="text-xs">
                                {test.teacher.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            {test.teacher}
                          </span>
                        </div>
                      </div>
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                        {Math.ceil((new Date(test.date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-medium text-sm mb-2">Topics to Study</h4>
                      <div className="flex flex-wrap gap-1">
                        {test.topics.map((topic, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {topic}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    {test.room && (
                      <div className="text-sm">
                        <span className="font-medium">Location:</span> {test.room}
                      </div>
                    )}

                    {test.instructions && (
                      <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                        <h4 className="font-medium text-sm mb-1 text-blue-800">Instructions</h4>
                        <p className="text-sm text-blue-700">{test.instructions}</p>
                      </div>
                    )}

                    <Button size="sm" className="flex items-center gap-1">
                      <BookOpen className="w-3 h-3" />
                      Study Resources
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* Subject Performance */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Subject Performance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.keys(subjectAverages).map((subject) => {
                  const average = getSubjectAverage(subject);
                  const trend = getTrend(subject);
                  return (
                    <div key={subject} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm">{subject}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm">{average}%</span>
                          {trend === 'up' && <TrendingUp className="w-3 h-3 text-green-600" />}
                          {trend === 'down' && <TrendingDown className="w-3 h-3 text-red-600" />}
                        </div>
                      </div>
                      <Progress value={average} className="h-2" />
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Recent Performance */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Test Scores</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentTests.map((test) => (
                    <div key={test.id} className="flex items-center justify-between p-2 border rounded">
                      <div>
                        <div className="font-medium text-sm">{test.testName}</div>
                        <div className="text-xs text-muted-foreground">{test.subject}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">{test.percentage}%</div>
                        <Badge variant="outline" size="sm" className={getGradeColor(test.grade)}>
                          {test.grade}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}