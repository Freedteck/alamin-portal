import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Clock, MapPin, User } from 'lucide-react';

interface ClassSession {
  id: string;
  subject: string;
  teacher: string;
  room: string;
  time: string;
  duration: number; // in hours
  color: string;
}

interface DaySchedule {
  [key: string]: ClassSession[];
}

export function StudentSchedule() {
  const currentDate = new Date();
  const currentDay = currentDate.toLocaleDateString('en-NZ', { weekday: 'long' });
  const currentTime = currentDate.getHours();

  // Demo schedule for Sarah Chen (Grade 7)
  const weekSchedule: DaySchedule = {
    Monday: [
      {
        id: '1',
        subject: 'Mathematics',
        teacher: 'Ms. Sarah Williams',
        room: 'Room 101',
        time: '09:00',
        duration: 1,
        color: 'bg-blue-100 text-blue-800 border-blue-200'
      },
      {
        id: '2',
        subject: 'Science',
        teacher: 'Mr. James Thompson',
        room: 'Science Lab',
        time: '14:00',
        duration: 1,
        color: 'bg-green-100 text-green-800 border-green-200'
      }
    ],
    Tuesday: [
      {
        id: '3',
        subject: 'English',
        teacher: 'Ms. Emma Clarke',
        room: 'Room 105',
        time: '10:00',
        duration: 1,
        color: 'bg-purple-100 text-purple-800 border-purple-200'
      },
      {
        id: '4',
        subject: 'Te Reo Māori',
        teacher: 'Whaea Maria Tane',
        room: 'Room 108',
        time: '13:00',
        duration: 1,
        color: 'bg-orange-100 text-orange-800 border-orange-200'
      }
    ],
    Wednesday: [
      {
        id: '5',
        subject: 'Mathematics',
        teacher: 'Ms. Sarah Williams',
        room: 'Room 101',
        time: '09:00',
        duration: 1,
        color: 'bg-blue-100 text-blue-800 border-blue-200'
      },
      {
        id: '6',
        subject: 'Science',
        teacher: 'Mr. James Thompson',
        room: 'Science Lab',
        time: '15:00',
        duration: 1,
        color: 'bg-green-100 text-green-800 border-green-200'
      }
    ],
    Thursday: [
      {
        id: '7',
        subject: 'English',
        teacher: 'Ms. Emma Clarke',
        room: 'Room 105',
        time: '11:00',
        duration: 1,
        color: 'bg-purple-100 text-purple-800 border-purple-200'
      },
      {
        id: '8',
        subject: 'Te Reo Māori',
        teacher: 'Whaea Maria Tane',
        room: 'Room 108',
        time: '14:00',
        duration: 1,
        color: 'bg-orange-100 text-orange-800 border-orange-200'
      }
    ],
    Friday: [
      {
        id: '9',
        subject: 'Mathematics',
        teacher: 'Ms. Sarah Williams',
        room: 'Room 101',
        time: '09:00',
        duration: 1,
        color: 'bg-blue-100 text-blue-800 border-blue-200'
      }
    ],
    Saturday: [
      {
        id: '10',
        subject: 'Science',
        teacher: 'Mr. James Thompson',
        room: 'Science Lab',
        time: '10:00',
        duration: 1,
        color: 'bg-green-100 text-green-800 border-green-200'
      }
    ],
    Sunday: []
  };

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const timeSlots = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];

  const isCurrentDay = (day: string) => day === currentDay;
  const isCurrentTimeSlot = (time: string) => {
    const slotHour = parseInt(time.split(':')[0]);
    return isCurrentDay(currentDay) && currentTime >= slotHour && currentTime < slotHour + 1;
  };

  const getClassAtTime = (day: string, time: string): ClassSession | null => {
    const dayClasses = weekSchedule[day] || [];
    return dayClasses.find(cls => cls.time === time) || null;
  };

  const getTodaysClasses = () => {
    return weekSchedule[currentDay] || [];
  };

  const getUpcomingClasses = () => {
    const upcoming = [];
    const currentHour = currentTime;
    
    // Get remaining classes today
    const todaysClasses = getTodaysClasses().filter(cls => {
      const classHour = parseInt(cls.time.split(':')[0]);
      return classHour > currentHour;
    });
    
    upcoming.push(...todaysClasses);

    // Get classes from next few days if needed
    const currentDayIndex = days.indexOf(currentDay);
    for (let i = 1; i < days.length && upcoming.length < 3; i++) {
      const nextDayIndex = (currentDayIndex + i) % days.length;
      const nextDay = days[nextDayIndex];
      const nextDayClasses = weekSchedule[nextDay] || [];
      upcoming.push(...nextDayClasses.slice(0, 3 - upcoming.length));
    }

    return upcoming.slice(0, 3);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>My Class Schedule</h1>
          <p className="text-muted-foreground">
            Week of {currentDate.toLocaleDateString('en-NZ', { 
              day: 'numeric', 
              month: 'long', 
              year: 'numeric' 
            })}
          </p>
        </div>
        <Badge variant="outline" className="px-4 py-2">
          <Clock className="w-4 h-4 mr-2" />
          Current: {currentDate.toLocaleTimeString('en-NZ', { 
            hour: '2-digit', 
            minute: '2-digit' 
          })}
        </Badge>
      </div>

      {/* Today's Classes Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Today's Classes ({currentDay})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {getTodaysClasses().length > 0 ? (
            <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
              {getTodaysClasses().map((cls) => (
                <div key={cls.id} className={`p-3 rounded-lg border-2 ${cls.color}`}>
                  <div className="space-y-1">
                    <p className="font-medium">{cls.subject}</p>
                    <div className="flex items-center gap-1 text-sm opacity-80">
                      <Clock className="w-3 h-3" />
                      {cls.time} ({cls.duration}h)
                    </div>
                    <div className="flex items-center gap-1 text-sm opacity-80">
                      <User className="w-3 h-3" />
                      {cls.teacher}
                    </div>
                    <div className="flex items-center gap-1 text-sm opacity-80">
                      <MapPin className="w-3 h-3" />
                      {cls.room}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground">No classes scheduled for today</p>
          )}
        </CardContent>
      </Card>

      {/* Weekly Calendar */}
      <Card>
        <CardHeader>
          <CardTitle>Weekly Schedule</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <div className="grid grid-cols-8 gap-1 min-w-[800px]">
              {/* Header Row */}
              <div className="p-3 border-b font-medium">Time</div>
              {days.map((day) => (
                <div 
                  key={day} 
                  className={`p-3 border-b font-medium text-center ${
                    isCurrentDay(day) ? 'bg-primary/5 text-primary' : ''
                  }`}
                >
                  {day}
                </div>
              ))}

              {/* Time Slots */}
              {timeSlots.map((time) => (
                <div key={time} className="contents">
                  <div className={`p-3 border-r text-sm font-medium ${
                    isCurrentTimeSlot(time) ? 'bg-primary/5' : ''
                  }`}>
                    {time}
                  </div>
                  {days.map((day) => {
                    const cls = getClassAtTime(day, time);
                    return (
                      <div 
                        key={`${day}-${time}`} 
                        className={`p-2 border-r border-b min-h-[60px] ${
                          isCurrentDay(day) && isCurrentTimeSlot(time) 
                            ? 'bg-primary/5 ring-2 ring-primary/20' 
                            : ''
                        }`}
                      >
                        {cls && (
                          <div className={`p-2 rounded border-2 text-xs ${cls.color} h-full`}>
                            <div className="font-medium truncate">{cls.subject}</div>
                            <div className="truncate opacity-80">{cls.teacher}</div>
                            <div className="truncate opacity-80">{cls.room}</div>
                            {cls.duration > 1 && (
                              <div className="opacity-60">{cls.duration}h</div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Classes */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Classes</CardTitle>
        </CardHeader>
        <CardContent>
          {getUpcomingClasses().length > 0 ? (
            <div className="space-y-3">
              {getUpcomingClasses().map((cls) => (
                <div key={cls.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                  <div className="space-y-1">
                    <p className="font-medium">{cls.subject}</p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <User className="w-3 h-3" />
                        {cls.teacher}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {cls.room}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {cls.time} ({cls.duration}h)
                      </span>
                    </div>
                  </div>
                  <Badge className={cls.color}>{cls.subject}</Badge>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground">No upcoming classes in the next few days</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}