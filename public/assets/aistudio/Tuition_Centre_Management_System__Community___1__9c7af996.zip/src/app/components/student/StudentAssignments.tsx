import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Separator } from '../ui/separator';
import { Progress } from '../ui/progress';
import { 
  Calendar, 
  FileText, 
  Download, 
  Upload, 
  MessageSquare, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  BookOpen,
  File,
  ExternalLink
} from 'lucide-react';

interface Assignment {
  id: string;
  title: string;
  subject: string;
  description: string;
  dueDate: string;
  status: 'pending' | 'submitted' | 'graded' | 'overdue';
  grade?: string;
  maxPoints: number;
  earnedPoints?: number;
  teacher: string;
  teacherAvatar?: string;
  submissionDate?: string;
  feedback?: string;
  attachments?: string[];
  requirements: string[];
}

interface Resource {
  id: string;
  title: string;
  type: 'pdf' | 'doc' | 'video' | 'link' | 'image';
  subject: string;
  uploadedBy: string;
  uploadDate: string;
  size?: string;
  description: string;
  url: string;
}

export function StudentAssignments() {
  // Demo assignments for Sarah Chen
  const assignments: Assignment[] = [
    {
      id: '1',
      title: 'Fractions Practice Worksheet',
      subject: 'Mathematics',
      description: 'Complete exercises 1-20 on adding and subtracting fractions. Show all working steps and simplify your answers.',
      dueDate: '2024-09-25',
      status: 'submitted',
      grade: 'A-',
      maxPoints: 50,
      earnedPoints: 45,
      teacher: 'Ms. Sarah Williams',
      teacherAvatar: 'SW',
      submissionDate: '2024-09-23',
      feedback: 'Great work Sarah! You understand fraction operations very well. Just be careful with simplifying your final answers in questions 15 and 18.',
      attachments: ['fractions-worksheet.pdf'],
      requirements: [
        'Show all working steps clearly',
        'Simplify all final answers',
        'Use proper fraction notation',
        'Complete all 20 problems'
      ]
    },
    {
      id: '2',
      title: 'Animal Research Project',
      subject: 'Science',
      description: 'Choose a New Zealand native animal and create a poster showing its habitat, diet, and interesting facts.',
      dueDate: '2024-09-27',
      status: 'pending',
      maxPoints: 40,
      teacher: 'Mr. James Thompson',
      teacherAvatar: 'JT',
      requirements: [
        'Choose a New Zealand native animal',
        'Include pictures and diagrams',
        'Research habitat and diet',
        'List 5 interesting facts',
        'Present to the class'
      ]
    },
    {
      id: '3',
      title: 'Creative Story Writing',
      subject: 'English',
      description: 'Write an original short story (300-500 words) with a clear beginning, middle, and end. Include dialogue and descriptive language.',
      dueDate: '2024-10-02',
      status: 'graded',
      grade: 'A',
      maxPoints: 30,
      earnedPoints: 28,
      teacher: 'Ms. Emma Clarke',
      teacherAvatar: 'EC',
      submissionDate: '2024-09-30',
      feedback: 'Excellent story Sarah! Your characters are well-developed and the dialogue feels natural. Great use of descriptive language. Just check your spelling in paragraph 3.',
      attachments: ['my-story.docx'],
      requirements: [
        '300-500 words',
        'Include dialogue',
        'Use descriptive language',
        'Clear story structure',
        'Check spelling and grammar'
      ]
    },
    {
      id: '4',
      title: 'Family Tree (Whakapapa)',
      subject: 'Te Reo Māori',
      description: 'Create a family tree using Te Reo Māori words for family members. Include at least 8 family members with correct spellings.',
      dueDate: '2024-10-05',
      status: 'overdue',
      maxPoints: 25,
      teacher: 'Whaea Maria Tane',
      teacherAvatar: 'MT',
      requirements: [
        'Use Te Reo Māori family words',
        'Include at least 8 family members',
        'Correct spelling and pronunciation',
        'Draw or create digitally',
        'Add pronunciation guide'
      ]
    }
  ];

  // Demo resources uploaded by tutors
  const resources: Resource[] = [
    {
      id: '1',
      title: 'Fractions Study Guide',
      type: 'pdf',
      subject: 'Mathematics',
      uploadedBy: 'Ms. Sarah Williams',
      uploadDate: '2024-09-15',
      size: '1.2 MB',
      description: 'Easy guide for adding, subtracting, multiplying and dividing fractions.',
      url: '#'
    },
    {
      id: '2',
      title: 'NZ Animals Video Series',
      type: 'video',
      subject: 'Science',
      uploadedBy: 'Mr. James Thompson',
      uploadDate: '2024-09-18',
      description: 'Short videos about New Zealand native animals and their habitats.',
      url: '#'
    },
    {
      id: '3',
      title: 'Story Writing Tips',
      type: 'pdf',
      subject: 'English',
      uploadedBy: 'Ms. Emma Clarke',
      uploadDate: '2024-09-20',
      size: '800 KB',
      description: 'Helpful tips for creating interesting characters and exciting stories.',
      url: '#'
    },
    {
      id: '4',
      title: 'Te Reo Māori Family Words',
      type: 'pdf',
      subject: 'Te Reo Māori',
      uploadedBy: 'Whaea Maria Tane',
      uploadDate: '2024-09-22',
      size: '600 KB',
      description: 'List of family member names in Te Reo Māori with pronunciation guide.',
      url: '#'
    },
    {
      id: '5',
      title: 'Online Math Games',
      type: 'link',
      subject: 'Mathematics',
      uploadedBy: 'Ms. Sarah Williams',
      uploadDate: '2024-09-10',
      description: 'Fun online games to practice fractions and decimals.',
      url: 'https://www.mathplayground.com/fractions.html'
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'submitted':
        return <CheckCircle className="w-4 h-4 text-blue-600" />;
      case 'graded':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'overdue':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Clock className="w-4 h-4 text-yellow-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'submitted':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'graded':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'overdue':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    }
  };

  const getSubjectColor = (subject: string) => {
    switch (subject) {
      case 'Mathematics':
        return 'bg-blue-100 text-blue-800';
      case 'Science':
        return 'bg-green-100 text-green-800';
      case 'English':
        return 'bg-purple-100 text-purple-800';
      case 'Te Reo Māori':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <div className="w-8 h-8 bg-red-100 rounded flex items-center justify-center">
          <FileText className="w-4 h-4 text-red-600" />
        </div>;
      case 'pdf':
        return <div className="w-8 h-8 bg-red-100 rounded flex items-center justify-center">
          <File className="w-4 h-4 text-red-600" />
        </div>;
      case 'link':
        return <div className="w-8 h-8 bg-blue-100 rounded flex items-center justify-center">
          <ExternalLink className="w-4 h-4 text-blue-600" />
        </div>;
      default:
        return <div className="w-8 h-8 bg-gray-100 rounded flex items-center justify-center">
          <FileText className="w-4 h-4 text-gray-600" />
        </div>;
    }
  };

  const pendingCount = assignments.filter(a => a.status === 'pending').length;
  const overdueCount = assignments.filter(a => a.status === 'overdue').length;
  const completedCount = assignments.filter(a => a.status === 'graded').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>My Assignments</h1>
          <p className="text-muted-foreground">
            Track your assignments, submissions, and feedback from tutors
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {pendingCount} Pending
          </Badge>
          {overdueCount > 0 && (
            <Badge variant="destructive" className="flex items-center gap-1">
              <AlertCircle className="w-3 h-3" />
              {overdueCount} Overdue
            </Badge>
          )}
        </div>
      </div>

      <Tabs defaultValue="assignments" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="assignments">Assignments</TabsTrigger>
          <TabsTrigger value="resources">Study Resources</TabsTrigger>
        </TabsList>
        
        <TabsContent value="assignments" className="space-y-4">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Pending</p>
                    <p className="text-2xl font-bold">{pendingCount}</p>
                  </div>
                  <Clock className="w-8 h-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Completed</p>
                    <p className="text-2xl font-bold">{completedCount}</p>
                  </div>
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Overdue</p>
                    <p className="text-2xl font-bold text-red-600">{overdueCount}</p>
                  </div>
                  <AlertCircle className="w-8 h-8 text-red-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Assignments List */}
          <div className="space-y-4">
            {assignments.map((assignment) => (
              <Card key={assignment.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-lg">{assignment.title}</CardTitle>
                        <Badge className={getSubjectColor(assignment.subject)}>
                          {assignment.subject}
                        </Badge>
                        <Badge variant="outline" className={`flex items-center gap-1 ${getStatusColor(assignment.status)}`}>
                          {getStatusIcon(assignment.status)}
                          {assignment.status.charAt(0).toUpperCase() + assignment.status.slice(1)}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          Due: {new Date(assignment.dueDate).toLocaleDateString('en-NZ')}
                        </span>
                        <span className="flex items-center gap-1">
                          <Avatar className="w-4 h-4">
                            <AvatarFallback className="text-xs">{assignment.teacherAvatar}</AvatarFallback>
                          </Avatar>
                          {assignment.teacher}
                        </span>
                      </div>
                    </div>
                    {assignment.grade && (
                      <div className="text-right">
                        <div className="text-2xl font-bold text-primary">{assignment.grade}</div>
                        <div className="text-sm text-muted-foreground">
                          {assignment.earnedPoints}/{assignment.maxPoints} pts
                        </div>
                        <Progress 
                          value={(assignment.earnedPoints! / assignment.maxPoints) * 100} 
                          className="w-20 mt-1"
                        />
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">{assignment.description}</p>
                  
                  {/* Requirements */}
                  <div>
                    <h4 className="text-sm font-medium mb-2">Requirements:</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      {assignment.requirements.map((req, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="w-1 h-1 rounded-full bg-current mt-2 flex-shrink-0" />
                          {req}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Feedback Section */}
                  {assignment.feedback && (
                    <div className="bg-muted/30 p-4 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <MessageSquare className="w-4 h-4" />
                        <span className="font-medium">Tutor Feedback</span>
                      </div>
                      <p className="text-sm">{assignment.feedback}</p>
                      {assignment.submissionDate && (
                        <p className="text-xs text-muted-foreground mt-2">
                          Submitted on {new Date(assignment.submissionDate).toLocaleDateString('en-NZ')}
                        </p>
                      )}
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-2 pt-2">
                    {assignment.status === 'pending' || assignment.status === 'overdue' ? (
                      <Button size="sm" className="flex items-center gap-1">
                        <Upload className="w-3 h-3" />
                        Submit Assignment
                      </Button>
                    ) : (
                      <Button variant="outline" size="sm" className="flex items-center gap-1">
                        <Download className="w-3 h-3" />
                        Download Submission
                      </Button>
                    )}
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="resources" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                Study Resources
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Resources uploaded by your tutors to help with your studies
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {resources.map((resource) => (
                  <div key={resource.id} className="flex items-start gap-3 p-3 border rounded-lg hover:bg-muted/30 transition-colors">
                    {getFileIcon(resource.type)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-medium truncate">{resource.title}</h4>
                          <p className="text-sm text-muted-foreground">{resource.description}</p>
                          <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                            <Badge variant="outline" className={getSubjectColor(resource.subject)}>
                              {resource.subject}
                            </Badge>
                            <span>By {resource.uploadedBy}</span>
                            <span>{new Date(resource.uploadDate).toLocaleDateString('en-NZ')}</span>
                            {resource.size && <span>{resource.size}</span>}
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="flex items-center gap-1 ml-2">
                          {resource.type === 'link' ? (
                            <>
                              <ExternalLink className="w-3 h-3" />
                              Open
                            </>
                          ) : (
                            <>
                              <Download className="w-3 h-3" />
                              Download
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}