import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  Calendar, 
  UserCheck, 
  Settings as SettingsIcon,
  DollarSign,
  BarChart3,
  FileText,
  MessageSquare,
  Database,
  LogOut
} from 'lucide-react';
import { Button } from '../ui/button';

interface AdminSidebarProps {
  activeModule: string;
  setActiveModule: (module: string) => void;
  onLogout: () => void;
}

export function AdminSidebar({ activeModule, setActiveModule, onLogout }: AdminSidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'students', label: 'Student Management', icon: Users },
    { id: 'teachers', label: 'Staff Management', icon: GraduationCap },
    { id: 'hr', label: 'HR Management', icon: UserCheck },
    { id: 'finance', label: 'Finance & Fees', icon: DollarSign },
    { id: 'reports', label: 'Reports & Analytics', icon: BarChart3 },
    { id: 'communications', label: 'Communications', icon: MessageSquare },
    { id: 'resources', label: 'Resources', icon: Database },
    { id: 'documents', label: 'Documents', icon: FileText },
    { id: 'settings', label: 'Settings', icon: SettingsIcon },
  ];

  return (
    <div className="w-64 bg-sidebar border-r border-sidebar-border p-4 flex flex-col h-full">
      <div className="flex items-center gap-2 mb-8">
        <GraduationCap className="h-8 w-8 text-sidebar-primary" />
        <div>
          <h1 className="text-lg text-sidebar-foreground">Ilam Tuition Centre</h1>
          <p className="text-xs text-sidebar-foreground/70">Admin Portal</p>
        </div>
      </div>
      
      <nav className="space-y-2 flex-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Button
              key={item.id}
              variant={activeModule === item.id ? "default" : "ghost"}
              className={`w-full justify-start gap-3 ${
                activeModule === item.id 
                  ? 'bg-sidebar-primary text-sidebar-primary-foreground' 
                  : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
              }`}
              onClick={() => setActiveModule(item.id)}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </Button>
          );
        })}
      </nav>

      <div className="mt-auto pt-4 border-t border-sidebar-border">
        <Button
          variant="ghost"
          className="w-full justify-start gap-3 text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
          onClick={onLogout}
        >
          <LogOut className="h-5 w-5" />
          Logout
        </Button>
      </div>
    </div>
  );
}