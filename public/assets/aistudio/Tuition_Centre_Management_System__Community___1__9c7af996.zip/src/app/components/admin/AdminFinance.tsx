import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Label } from '../ui/label';
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  CreditCard, 
  AlertCircle,
  Search,
  Plus,
  Download,
  Eye
} from 'lucide-react';

interface Transaction {
  id: string;
  studentName: string;
  studentId: string;
  type: 'fee_payment' | 'refund' | 'late_fee' | 'registration';
  amount: number;
  date: string;
  status: 'completed' | 'pending' | 'failed';
  method: 'cash' | 'card' | 'bank_transfer' | 'online';
  description: string;
}

interface FeeStructure {
  id: string;
  subject: string;
  grade: string;
  monthlyFee: number;
  registrationFee: number;
  materialFee: number;
}

export function AdminFinance() {
  const [selectedMonth, setSelectedMonth] = useState('2024-09');
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddFeeDialogOpen, setIsAddFeeDialogOpen] = useState(false);

  const [transactions] = useState<Transaction[]>([
    {
      id: '1',
      studentName: 'Sarah Chen',
      studentId: 'STU001',
      type: 'fee_payment',
      amount: 120,
      date: '2024-09-20',
      status: 'completed',
      method: 'online',
      description: 'Math Grade 7 - September 2024'
    },
    {
      id: '2',
      studentName: 'Tommy Wilson',
      studentId: 'STU002',
      type: 'registration',
      amount: 50,
      date: '2024-09-18',
      status: 'completed',
      method: 'card',
      description: 'New student registration fee'
    },
    {
      id: '3',
      studentName: 'Mia Johnson',
      studentId: 'STU003',
      type: 'fee_payment',
      amount: 160,
      date: '2024-09-15',
      status: 'pending',
      method: 'bank_transfer',
      description: 'Math & Science Grade 6 - September 2024'
    },
    {
      id: '4',
      studentName: 'Alex Brown',
      studentId: 'STU004',
      type: 'late_fee',
      amount: 25,
      date: '2024-09-12',
      status: 'completed',
      method: 'cash',
      description: 'Late payment penalty'
    }
  ]);

  const [feeStructure] = useState<FeeStructure[]>([
    { id: '1', subject: 'Mathematics', grade: 'Grade 1-3', monthlyFee: 80, registrationFee: 50, materialFee: 20 },
    { id: '2', subject: 'Mathematics', grade: 'Grade 4-7', monthlyFee: 100, registrationFee: 50, materialFee: 25 },
    { id: '3', subject: 'Science', grade: 'Grade 1-3', monthlyFee: 80, registrationFee: 50, materialFee: 30 },
    { id: '4', subject: 'Science', grade: 'Grade 4-7', monthlyFee: 100, registrationFee: 50, materialFee: 35 },
    { id: '5', subject: 'English', grade: 'Grade 1-3', monthlyFee: 70, registrationFee: 50, materialFee: 15 },
    { id: '6', subject: 'English', grade: 'Grade 4-7', monthlyFee: 90, registrationFee: 50, materialFee: 20 },
    { id: '7', subject: 'Te Reo Māori', grade: 'Grade 1-3', monthlyFee: 70, registrationFee: 50, materialFee: 15 },
    { id: '8', subject: 'Te Reo Māori', grade: 'Grade 4-7', monthlyFee: 90, registrationFee: 50, materialFee: 20 }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getMethodColor = (method: string) => {
    switch (method) {
      case 'online': return 'bg-blue-100 text-blue-800';
      case 'card': return 'bg-purple-100 text-purple-800';
      case 'bank_transfer': return 'bg-indigo-100 text-indigo-800';
      case 'cash': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredTransactions = transactions.filter(transaction =>
    transaction.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    transaction.studentId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalRevenue = transactions
    .filter(t => t.status === 'completed' && t.type !== 'refund')
    .reduce((sum, t) => sum + t.amount, 0);

  const pendingPayments = transactions
    .filter(t => t.status === 'pending')
    .reduce((sum, t) => sum + t.amount, 0);

  const overdueCount = transactions.filter(t => t.status === 'pending').length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1>Finance & Fees</h1>
          <p className="text-muted-foreground">Manage payments, fees, and financial reports</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export Report
          </Button>
          <Dialog open={isAddFeeDialogOpen} onOpenChange={setIsAddFeeDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Record Payment
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Record New Payment</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Student</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select student" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="stu001">Sarah Chen (STU001)</SelectItem>
                        <SelectItem value="stu002">Tommy Wilson (STU002)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Payment Type</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fee_payment">Fee Payment</SelectItem>
                        <SelectItem value="registration">Registration</SelectItem>
                        <SelectItem value="late_fee">Late Fee</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Amount ($)</Label>
                    <Input type="number" placeholder="0.00" />
                  </div>
                  <div className="space-y-2">
                    <Label>Payment Method</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">Cash</SelectItem>
                        <SelectItem value="card">Card</SelectItem>
                        <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                        <SelectItem value="online">Online</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Input placeholder="Payment description" />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsAddFeeDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsAddFeeDialogOpen(false)}>
                    Record Payment
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Financial Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">${totalRevenue}</div>
                <p className="text-xs text-muted-foreground">Total Revenue</p>
              </div>
              <TrendingUp className="h-5 w-5 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">${pendingPayments}</div>
                <p className="text-xs text-muted-foreground">Pending Payments</p>
              </div>
              <CreditCard className="h-5 w-5 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">{overdueCount}</div>
                <p className="text-xs text-muted-foreground">Overdue Payments</p>
              </div>
              <AlertCircle className="h-5 w-5 text-red-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">247</div>
                <p className="text-xs text-muted-foreground">Active Students</p>
              </div>
              <DollarSign className="h-5 w-5 text-blue-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="transactions" className="space-y-4">
        <TabsList>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="fees">Fee Structure</TabsTrigger>
          <TabsTrigger value="reports">Financial Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="transactions" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by student name or ID..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                  <SelectTrigger className="w-full md:w-[200px]">
                    <SelectValue placeholder="Select month" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2024-09">September 2024</SelectItem>
                    <SelectItem value="2024-08">August 2024</SelectItem>
                    <SelectItem value="2024-07">July 2024</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Transactions Table */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions ({filteredTransactions.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTransactions.map((transaction) => (
                    <TableRow key={transaction.id}>
                      <TableCell>
                        <div>
                          <div>{transaction.studentName}</div>
                          <div className="text-sm text-muted-foreground">{transaction.studentId}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="capitalize">{transaction.type.replace('_', ' ')}</div>
                          <div className="text-sm text-muted-foreground">{transaction.description}</div>
                        </div>
                      </TableCell>
                      <TableCell>${transaction.amount}</TableCell>
                      <TableCell>{new Date(transaction.date).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Badge className={getMethodColor(transaction.method)}>
                          {transaction.method.replace('_', ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(transaction.status)}>
                          {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fees" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Fee Structure</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Subject</TableHead>
                    <TableHead>Grade Level</TableHead>
                    <TableHead>Monthly Fee</TableHead>
                    <TableHead>Registration Fee</TableHead>
                    <TableHead>Material Fee</TableHead>
                    <TableHead>Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {feeStructure.map((fee) => (
                    <TableRow key={fee.id}>
                      <TableCell>{fee.subject}</TableCell>
                      <TableCell>{fee.grade}</TableCell>
                      <TableCell>${fee.monthlyFee}</TableCell>
                      <TableCell>${fee.registrationFee}</TableCell>
                      <TableCell>${fee.materialFee}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          ${fee.monthlyFee + fee.registrationFee + fee.materialFee}
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Monthly Revenue Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>September 2024</span>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-green-600" />
                      <span className="text-green-600">+12.5%</span>
                    </div>
                  </div>
                  <div className="text-2xl">${totalRevenue}</div>
                  <p className="text-sm text-muted-foreground">
                    Revenue increased by 12.5% compared to last month
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Payment Methods Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Online Payments</span>
                    <span>45%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Card Payments</span>
                    <span>30%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Bank Transfer</span>
                    <span>15%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cash</span>
                    <span>10%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Outstanding Payments Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-muted-foreground">
                {overdueCount} students have outstanding payments totaling ${pendingPayments}. 
                Follow-up reminders have been sent to all affected families.
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}