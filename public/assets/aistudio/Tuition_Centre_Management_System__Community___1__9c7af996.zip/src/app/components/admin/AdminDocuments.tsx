import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { 
  FileText, 
  Upload, 
  Download, 
  Plus,
  Search,
  Filter,
  Eye,
  Edit,
  Trash2,
  FolderOpen,
  Calendar,
  User,
  Clock,
  Shield,
  Share2
} from 'lucide-react';

interface Document {
  id: string;
  name: string;
  type: 'policy' | 'contract' | 'certificate' | 'report' | 'form' | 'other';
  category: 'hr' | 'academic' | 'administrative' | 'legal' | 'financial';
  size: string;
  uploadDate: string;
  lastModified: string;
  uploadedBy: string;
  accessLevel: 'public' | 'staff' | 'admin';
  status: 'active' | 'draft' | 'archived';
  description: string;
}

interface Folder {
  id: string;
  name: string;
  documentCount: number;
  lastModified: string;
  color: string;
}

interface DocumentVersion {
  id: string;
  documentId: string;
  version: string;
  uploadDate: string;
  uploadedBy: string;
  changes: string;
  fileSize: string;
}

export function AdminDocuments() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedAccessLevel, setSelectedAccessLevel] = useState('all');
  const [isNewDocumentOpen, setIsNewDocumentOpen] = useState(false);
  const [isNewFolderOpen, setIsNewFolderOpen] = useState(false);

  const [documents] = useState<Document[]>([
    {
      id: '1',
      name: 'Employee Handbook 2024',
      type: 'policy',
      category: 'hr',
      size: '2.3 MB',
      uploadDate: '2024-01-15',
      lastModified: '2024-09-10',
      uploadedBy: 'Admin',
      accessLevel: 'staff',
      status: 'active',
      description: 'Complete guide for all staff members including policies and procedures'
    },
    {
      id: '2',
      name: 'Student Registration Form',
      type: 'form',
      category: 'administrative',
      size: '156 KB',
      uploadDate: '2024-02-01',
      lastModified: '2024-08-20',
      uploadedBy: 'Admin',
      accessLevel: 'public',
      status: 'active',
      description: 'Standard form for new student enrollments'
    },
    {
      id: '3',
      name: 'Teaching License - Dr. Smith',
      type: 'certificate',
      category: 'hr',
      size: '945 KB',
      uploadDate: '2024-03-15',
      lastModified: '2024-03-15',
      uploadedBy: 'HR Manager',
      accessLevel: 'admin',
      status: 'active',
      description: 'Valid teaching certificate for Dr. Smith Johnson'
    },
    {
      id: '4',
      name: 'Monthly Performance Report - Sept',
      type: 'report',
      category: 'academic',
      size: '1.8 MB',
      uploadDate: '2024-09-20',
      lastModified: '2024-09-20',
      uploadedBy: 'Dr. Smith Johnson',
      accessLevel: 'admin',
      status: 'draft',
      description: 'Comprehensive performance analysis for September 2024'
    },
    {
      id: '5',
      name: 'Safety Protocol Guidelines',
      type: 'policy',
      category: 'administrative',
      size: '1.2 MB',
      uploadDate: '2024-04-10',
      lastModified: '2024-07-15',
      uploadedBy: 'Admin',
      accessLevel: 'staff',
      status: 'active',
      description: 'Emergency procedures and safety guidelines for all staff'
    },
    {
      id: '6',
      name: 'Financial Audit Report Q2',
      type: 'report',
      category: 'financial',
      size: '3.2 MB',
      uploadDate: '2024-07-01',
      lastModified: '2024-07-01',
      uploadedBy: 'Finance Team',
      accessLevel: 'admin',
      status: 'active',
      description: 'Quarterly financial audit and compliance report'
    }
  ]);

  const [folders] = useState<Folder[]>([
    { id: '1', name: 'HR Documents', documentCount: 15, lastModified: '2024-09-20', color: 'bg-blue-100' },
    { id: '2', name: 'Academic Reports', documentCount: 8, lastModified: '2024-09-18', color: 'bg-green-100' },
    { id: '3', name: 'Financial Records', documentCount: 12, lastModified: '2024-09-15', color: 'bg-orange-100' },
    { id: '4', name: 'Legal Documents', documentCount: 6, lastModified: '2024-09-10', color: 'bg-purple-100' },
    { id: '5', name: 'Student Records', documentCount: 247, lastModified: '2024-09-19', color: 'bg-pink-100' }
  ]);

  const [documentVersions] = useState<DocumentVersion[]>([
    {
      id: '1',
      documentId: '1',
      version: '2.1',
      uploadDate: '2024-09-10',
      uploadedBy: 'Admin',
      changes: 'Updated leave policy and remote work guidelines',
      fileSize: '2.3 MB'
    },
    {
      id: '2',
      documentId: '1',
      version: '2.0',
      uploadDate: '2024-06-15',
      uploadedBy: 'HR Manager',
      changes: 'Major revision - added new sections on professional development',
      fileSize: '2.1 MB'
    },
    {
      id: '3',
      documentId: '2',
      version: '1.2',
      uploadDate: '2024-08-20',
      uploadedBy: 'Admin',
      changes: 'Added fields for emergency contact information',
      fileSize: '156 KB'
    }
  ]);

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'policy': return 'bg-blue-100 text-blue-800';
      case 'contract': return 'bg-green-100 text-green-800';
      case 'certificate': return 'bg-purple-100 text-purple-800';
      case 'report': return 'bg-orange-100 text-orange-800';
      case 'form': return 'bg-pink-100 text-pink-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'hr': return 'bg-blue-100 text-blue-800';
      case 'academic': return 'bg-green-100 text-green-800';
      case 'administrative': return 'bg-yellow-100 text-yellow-800';
      case 'legal': return 'bg-purple-100 text-purple-800';
      case 'financial': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getAccessLevelColor = (accessLevel: string) => {
    switch (accessLevel) {
      case 'public': return 'bg-green-100 text-green-800';
      case 'staff': return 'bg-yellow-100 text-yellow-800';
      case 'admin': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'draft': return 'bg-yellow-100 text-yellow-800';
      case 'archived': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doc.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || doc.category === selectedCategory;
    const matchesAccessLevel = selectedAccessLevel === 'all' || doc.accessLevel === selectedAccessLevel;
    return matchesSearch && matchesCategory && matchesAccessLevel;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1>Documents</h1>
          <p className="text-muted-foreground">Manage organizational documents and files</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isNewFolderOpen} onOpenChange={setIsNewFolderOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <FolderOpen className="h-4 w-4" />
                New Folder
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Folder</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Folder Name</Label>
                  <Input placeholder="Enter folder name" />
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Input placeholder="Folder description (optional)" />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsNewFolderOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsNewFolderOpen(false)}>
                    Create Folder
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Dialog open={isNewDocumentOpen} onOpenChange={setIsNewDocumentOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Upload Document
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Upload New Document</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Document Name</Label>
                    <Input placeholder="Document name" />
                  </div>
                  <div className="space-y-2">
                    <Label>Type</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="policy">Policy</SelectItem>
                        <SelectItem value="contract">Contract</SelectItem>
                        <SelectItem value="certificate">Certificate</SelectItem>
                        <SelectItem value="report">Report</SelectItem>
                        <SelectItem value="form">Form</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hr">HR</SelectItem>
                        <SelectItem value="academic">Academic</SelectItem>
                        <SelectItem value="administrative">Administrative</SelectItem>
                        <SelectItem value="legal">Legal</SelectItem>
                        <SelectItem value="financial">Financial</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Access Level</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select access level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="public">Public</SelectItem>
                        <SelectItem value="staff">Staff Only</SelectItem>
                        <SelectItem value="admin">Admin Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Input placeholder="Document description" />
                </div>
                <div className="space-y-2">
                  <Label>File</Label>
                  <div className="border-2 border-dashed border-muted rounded-lg p-6 text-center">
                    <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">
                      Drop your file here or click to browse
                    </p>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsNewDocumentOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsNewDocumentOpen(false)}>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Document
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Document Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">{documents.length}</div>
                <p className="text-xs text-muted-foreground">Total Documents</p>
              </div>
              <FileText className="h-5 w-5 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">{folders.length}</div>
                <p className="text-xs text-muted-foreground">Folders</p>
              </div>
              <FolderOpen className="h-5 w-5 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">{documents.filter(d => d.status === 'active').length}</div>
                <p className="text-xs text-muted-foreground">Active Documents</p>
              </div>
              <Shield className="h-5 w-5 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">98.2%</div>
                <p className="text-xs text-muted-foreground">Compliance Rate</p>
              </div>
              <Calendar className="h-5 w-5 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="documents" className="space-y-4">
        <TabsList>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="folders">Folders</TabsTrigger>
          <TabsTrigger value="versions">Version History</TabsTrigger>
          <TabsTrigger value="access">Access Control</TabsTrigger>
        </TabsList>

        <TabsContent value="documents" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search documents..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full md:w-[150px]">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="hr">HR</SelectItem>
                    <SelectItem value="academic">Academic</SelectItem>
                    <SelectItem value="administrative">Administrative</SelectItem>
                    <SelectItem value="legal">Legal</SelectItem>
                    <SelectItem value="financial">Financial</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={selectedAccessLevel} onValueChange={setSelectedAccessLevel}>
                  <SelectTrigger className="w-full md:w-[150px]">
                    <SelectValue placeholder="Access Level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Access</SelectItem>
                    <SelectItem value="public">Public</SelectItem>
                    <SelectItem value="staff">Staff Only</SelectItem>
                    <SelectItem value="admin">Admin Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Documents Table */}
          <Card>
            <CardHeader>
              <CardTitle>Documents ({filteredDocuments.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Access Level</TableHead>
                    <TableHead>Size</TableHead>
                    <TableHead>Last Modified</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDocuments.map((document) => (
                    <TableRow key={document.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <div>{document.name}</div>
                            <div className="text-sm text-muted-foreground truncate max-w-[200px]">
                              {document.description}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getTypeColor(document.type)}>
                          {document.type.charAt(0).toUpperCase() + document.type.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getCategoryColor(document.category)}>
                          {document.category.toUpperCase()}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getAccessLevelColor(document.accessLevel)}>
                          {document.accessLevel.charAt(0).toUpperCase() + document.accessLevel.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>{document.size}</TableCell>
                      <TableCell>
                        <div>
                          <div className="text-sm">{new Date(document.lastModified).toLocaleDateString()}</div>
                          <div className="text-xs text-muted-foreground">by {document.uploadedBy}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(document.status)}>
                          {document.status.charAt(0).toUpperCase() + document.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Download className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Share2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="folders" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {folders.map((folder) => (
              <Card key={folder.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-lg ${folder.color}`}>
                      <FolderOpen className="h-6 w-6" />
                    </div>
                    <div className="flex-1">
                      <h3>{folder.name}</h3>
                      <div className="text-sm text-muted-foreground">
                        {folder.documentCount} documents
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Modified: {new Date(folder.lastModified).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="versions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Document Version History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Document</TableHead>
                    <TableHead>Version</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Uploaded By</TableHead>
                    <TableHead>Changes</TableHead>
                    <TableHead>Size</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {documentVersions.map((version) => (
                    <TableRow key={version.id}>
                      <TableCell>
                        {documents.find(d => d.id === version.documentId)?.name || 'Unknown Document'}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">v{version.version}</Badge>
                      </TableCell>
                      <TableCell>{new Date(version.uploadDate).toLocaleDateString()}</TableCell>
                      <TableCell>{version.uploadedBy}</TableCell>
                      <TableCell className="max-w-[300px]">
                        <div className="truncate">{version.changes}</div>
                      </TableCell>
                      <TableCell>{version.fileSize}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">
                            <Download className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="access" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Access Level Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                      <span className="text-sm">Public Access</span>
                    </div>
                    <span className="text-sm">
                      {documents.filter(d => d.accessLevel === 'public').length} documents
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                      <span className="text-sm">Staff Only</span>
                    </div>
                    <span className="text-sm">
                      {documents.filter(d => d.accessLevel === 'staff').length} documents
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-red-500"></div>
                      <span className="text-sm">Admin Only</span>
                    </div>
                    <span className="text-sm">
                      {documents.filter(d => d.accessLevel === 'admin').length} documents
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Access Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <div className="flex-1">
                      <div className="text-sm">Dr. Smith Johnson accessed Employee Handbook</div>
                      <div className="text-xs text-muted-foreground">2 hours ago</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <div className="flex-1">
                      <div className="text-sm">Admin downloaded Financial Audit Report</div>
                      <div className="text-xs text-muted-foreground">5 hours ago</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <div className="flex-1">
                      <div className="text-sm">HR Manager updated Safety Protocols</div>
                      <div className="text-xs text-muted-foreground">1 day ago</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Document Compliance Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-muted-foreground">
                All critical documents are up to date and compliant with current regulations. 
                Next compliance review scheduled for December 2024.
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}