import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { 
  MessageSquare, 
  Send, 
  Users, 
  Mail, 
  Phone,
  Plus,
  Search,
  Filter,
  Eye,
  Bell,
  Calendar,
  FileText
} from 'lucide-react';

interface Announcement {
  id: string;
  title: string;
  content: string;
  audience: 'all' | 'students' | 'parents' | 'staff';
  priority: 'low' | 'medium' | 'high';
  date: string;
  author: string;
  status: 'draft' | 'published' | 'scheduled';
}

interface Message {
  id: string;
  recipient: string;
  recipientType: 'student' | 'parent' | 'staff';
  subject: string;
  content: string;
  date: string;
  status: 'sent' | 'delivered' | 'read';
  type: 'individual' | 'group';
}

interface Template {
  id: string;
  name: string;
  category: 'academic' | 'administrative' | 'event' | 'reminder';
  subject: string;
  content: string;
  variables: string[];
}

export function AdminCommunications() {
  const [searchTerm, setSearchTerm] = useState('');
  const [isNewAnnouncementOpen, setIsNewAnnouncementOpen] = useState(false);
  const [isNewMessageOpen, setIsNewMessageOpen] = useState(false);

  const [announcements] = useState<Announcement[]>([
    {
      id: '1',
      title: 'Welcome Back - New Term Starting',
      content: 'Welcome back everyone! The new term begins next Monday. Please ensure all materials are ready.',
      audience: 'all',
      priority: 'high',
      date: '2024-09-20',
      author: 'Admin',
      status: 'published'
    },
    {
      id: '2',
      title: 'Parent-Teacher Meeting Schedule',
      content: 'Parent-teacher meetings will be held next Friday. Booking links have been sent via email.',
      audience: 'parents',
      priority: 'medium',
      date: '2024-09-18',
      author: 'Admin',
      status: 'published'
    },
    {
      id: '3',
      title: 'Math Competition Registration Open',
      content: 'Registration is now open for the inter-school mathematics competition. Deadline: October 1st.',
      audience: 'students',
      priority: 'medium',
      date: '2024-09-15',
      author: 'Dr. Smith Johnson',
      status: 'published'
    },
    {
      id: '4',
      title: 'Staff Development Workshop',
      content: 'Mandatory staff development workshop on new teaching methodologies scheduled for next Saturday.',
      audience: 'staff',
      priority: 'high',
      date: '2024-09-25',
      author: 'Admin',
      status: 'scheduled'
    }
  ]);

  const [messages] = useState<Message[]>([
    {
      id: '1',
      recipient: 'Sarah Chen',
      recipientType: 'student',
      subject: 'Assignment Submission Reminder',
      content: 'Please remember to submit your math assignment by Friday.',
      date: '2024-09-20',
      status: 'read',
      type: 'individual'
    },
    {
      id: '2',
      recipient: 'Grade 7 Students',
      recipientType: 'student',
      subject: 'Science Fair Preparation',
      content: 'Science fair is approaching. Please prepare your projects and submit proposals.',
      date: '2024-09-19',
      status: 'delivered',
      type: 'group'
    },
    {
      id: '3',
      recipient: 'Parent - Tommy Wilson',
      recipientType: 'parent',
      subject: 'Progress Update',
      content: 'Tommy has shown excellent improvement in mathematics this month.',
      date: '2024-09-18',
      status: 'read',
      type: 'individual'
    }
  ]);

  const [templates] = useState<Template[]>([
    {
      id: '1',
      name: 'Assignment Reminder',
      category: 'academic',
      subject: 'Assignment Due Reminder - {{subject}}',
      content: 'Dear {{student_name}}, this is a reminder that your {{assignment_name}} assignment for {{subject}} is due on {{due_date}}.',
      variables: ['student_name', 'assignment_name', 'subject', 'due_date']
    },
    {
      id: '2',
      name: 'Fee Payment Reminder',
      category: 'administrative',
      subject: 'Monthly Fee Payment Reminder',
      content: 'Dear {{parent_name}}, the monthly fee of ${{amount}} for {{student_name}} is due on {{due_date}}.',
      variables: ['parent_name', 'student_name', 'amount', 'due_date']
    },
    {
      id: '3',
      name: 'Event Invitation',
      category: 'event',
      subject: 'Invitation: {{event_name}}',
      content: 'You are invited to {{event_name}} on {{event_date}} at {{event_time}}. Location: {{location}}.',
      variables: ['event_name', 'event_date', 'event_time', 'location']
    }
  ]);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'published': return 'bg-green-100 text-green-800';
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'sent': return 'bg-blue-100 text-blue-800';
      case 'delivered': return 'bg-green-100 text-green-800';
      case 'read': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getAudienceColor = (audience: string) => {
    switch (audience) {
      case 'all': return 'bg-purple-100 text-purple-800';
      case 'students': return 'bg-blue-100 text-blue-800';
      case 'parents': return 'bg-green-100 text-green-800';
      case 'staff': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredAnnouncements = announcements.filter(announcement =>
    announcement.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    announcement.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredMessages = messages.filter(message =>
    message.recipient.toLowerCase().includes(searchTerm.toLowerCase()) ||
    message.subject.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1>Communications</h1>
          <p className="text-muted-foreground">Manage announcements, messages, and templates</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isNewMessageOpen} onOpenChange={setIsNewMessageOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Send className="h-4 w-4" />
                Send Message
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Send New Message</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Recipient Type</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select recipient type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="individual">Individual</SelectItem>
                        <SelectItem value="group">Group</SelectItem>
                        <SelectItem value="all_students">All Students</SelectItem>
                        <SelectItem value="all_parents">All Parents</SelectItem>
                        <SelectItem value="all_staff">All Staff</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Recipient</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select recipient" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sarah">Sarah Chen</SelectItem>
                        <SelectItem value="tommy">Tommy Wilson</SelectItem>
                        <SelectItem value="grade7">Grade 7 Students</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Subject</Label>
                  <Input placeholder="Message subject" />
                </div>
                <div className="space-y-2">
                  <Label>Message</Label>
                  <Textarea placeholder="Type your message here..." rows={6} />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsNewMessageOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsNewMessageOpen(false)}>
                    <Send className="h-4 w-4 mr-2" />
                    Send Message
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Dialog open={isNewAnnouncementOpen} onOpenChange={setIsNewAnnouncementOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                New Announcement
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Announcement</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Title</Label>
                  <Input placeholder="Announcement title" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Audience</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select audience" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Everyone</SelectItem>
                        <SelectItem value="students">Students Only</SelectItem>
                        <SelectItem value="parents">Parents Only</SelectItem>
                        <SelectItem value="staff">Staff Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Priority</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Content</Label>
                  <Textarea placeholder="Announcement content..." rows={6} />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsNewAnnouncementOpen(false)}>
                    Save as Draft
                  </Button>
                  <Button onClick={() => setIsNewAnnouncementOpen(false)}>
                    <Bell className="h-4 w-4 mr-2" />
                    Publish Now
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Communication Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">12</div>
                <p className="text-xs text-muted-foreground">Active Announcements</p>
              </div>
              <Bell className="h-5 w-5 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">248</div>
                <p className="text-xs text-muted-foreground">Messages Sent</p>
              </div>
              <Send className="h-5 w-5 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">94%</div>
                <p className="text-xs text-muted-foreground">Read Rate</p>
              </div>
              <Eye className="h-5 w-5 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">8</div>
                <p className="text-xs text-muted-foreground">Message Templates</p>
              </div>
              <FileText className="h-5 w-5 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search communications..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Button variant="outline" className="gap-2">
              <Filter className="h-4 w-4" />
              Filter
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="announcements" className="space-y-4">
        <TabsList>
          <TabsTrigger value="announcements">Announcements</TabsTrigger>
          <TabsTrigger value="messages">Messages</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="announcements" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Announcements ({filteredAnnouncements.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Audience</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAnnouncements.map((announcement) => (
                    <TableRow key={announcement.id}>
                      <TableCell>
                        <div>
                          <div>{announcement.title}</div>
                          <div className="text-sm text-muted-foreground truncate max-w-[300px]">
                            {announcement.content}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getAudienceColor(announcement.audience)}>
                          {announcement.audience.charAt(0).toUpperCase() + announcement.audience.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getPriorityColor(announcement.priority)}>
                          {announcement.priority.charAt(0).toUpperCase() + announcement.priority.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>{new Date(announcement.date).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(announcement.status)}>
                          {announcement.status.charAt(0).toUpperCase() + announcement.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <FileText className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="messages" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Recent Messages ({filteredMessages.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Recipient</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMessages.map((message) => (
                    <TableRow key={message.id}>
                      <TableCell>
                        <div>
                          <div>{message.recipient}</div>
                          <div className="text-sm text-muted-foreground capitalize">
                            {message.recipientType}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div>{message.subject}</div>
                          <div className="text-sm text-muted-foreground truncate max-w-[200px]">
                            {message.content}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">
                          {message.type.charAt(0).toUpperCase() + message.type.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>{new Date(message.date).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(message.status)}>
                          {message.status.charAt(0).toUpperCase() + message.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3>Message Templates</h3>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              New Template
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {templates.map((template) => (
              <Card key={template.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{template.name}</CardTitle>
                      <Badge variant="secondary" className="mt-1">
                        {template.category}
                      </Badge>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div>
                      <span className="text-sm text-muted-foreground">Subject:</span>
                      <p className="text-sm">{template.subject}</p>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Content:</span>
                      <p className="text-sm truncate">{template.content}</p>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Variables:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {template.variables.map((variable, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {`{{${variable}}}`}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Communication Preferences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Default Message Priority</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select default priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Auto-archive after (days)</Label>
                  <Input type="number" placeholder="30" />
                </div>
                <div className="space-y-2">
                  <Label>Sender Name</Label>
                  <Input placeholder="Ilam Tuition Centre" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Email notifications for new messages</Label>
                  <Button variant="outline" size="sm">Enable</Button>
                </div>
                <div className="flex items-center justify-between">
                  <Label>SMS notifications for urgent announcements</Label>
                  <Button variant="outline" size="sm">Enable</Button>
                </div>
                <div className="flex items-center justify-between">
                  <Label>Daily communication summary</Label>
                  <Button variant="outline" size="sm">Enable</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}