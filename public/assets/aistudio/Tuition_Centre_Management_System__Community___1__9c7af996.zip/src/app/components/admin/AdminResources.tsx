import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Progress } from '../ui/progress';
import { 
  Database, 
  BookOpen, 
  Monitor, 
  Wifi, 
  Printer,
  Plus,
  Search,
  Download,
  Upload,
  Edit,
  Trash2,
  AlertTriangle,
  CheckCircle,
  Clock,
  Users
} from 'lucide-react';

interface LearningResource {
  id: string;
  title: string;
  type: 'worksheet' | 'video' | 'presentation' | 'book' | 'assessment';
  subject: string;
  grade: string;
  description: string;
  uploadDate: string;
  fileSize: string;
  downloads: number;
  status: 'active' | 'archived';
}

interface EquipmentItem {
  id: string;
  name: string;
  type: 'computer' | 'projector' | 'printer' | 'whiteboard' | 'furniture' | 'other';
  location: string;
  status: 'available' | 'in_use' | 'maintenance' | 'damaged';
  condition: 'excellent' | 'good' | 'fair' | 'poor';
  purchaseDate: string;
  lastMaintenance: string;
  assignedTo?: string;
}

interface MaintenanceRequest {
  id: string;
  equipmentId: string;
  equipmentName: string;
  reportedBy: string;
  issue: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  reportDate: string;
  estimatedCost?: number;
}

export function AdminResources() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('all');
  const [isNewResourceOpen, setIsNewResourceOpen] = useState(false);
  const [isNewMaintenanceOpen, setIsNewMaintenanceOpen] = useState(false);

  const [learningResources] = useState<LearningResource[]>([
    {
      id: '1',
      title: 'Grade 7 Mathematics - Fractions Worksheet',
      type: 'worksheet',
      subject: 'Mathematics',
      grade: 'Grade 7',
      description: 'Comprehensive worksheet covering addition and subtraction of fractions',
      uploadDate: '2024-09-15',
      fileSize: '2.3 MB',
      downloads: 45,
      status: 'active'
    },
    {
      id: '2',
      title: 'Introduction to Photosynthesis',
      type: 'video',
      subject: 'Science',
      grade: 'Grade 6',
      description: 'Animated video explaining the process of photosynthesis',
      uploadDate: '2024-09-12',
      fileSize: '15.7 MB',
      downloads: 78,
      status: 'active'
    },
    {
      id: '3',
      title: 'English Grammar Assessment',
      type: 'assessment',
      subject: 'English',
      grade: 'Grade 5',
      description: 'End of term assessment covering tenses and sentence structure',
      uploadDate: '2024-09-10',
      fileSize: '1.8 MB',
      downloads: 32,
      status: 'active'
    },
    {
      id: '4',
      title: 'Te Reo Māori Basic Vocabulary',
      type: 'presentation',
      subject: 'Te Reo Māori',
      grade: 'Grade 4',
      description: 'Interactive presentation with basic Māori words and pronunciation',
      uploadDate: '2024-09-08',
      fileSize: '8.2 MB',
      downloads: 56,
      status: 'active'
    }
  ]);

  const [equipment] = useState<EquipmentItem[]>([
    {
      id: '1',
      name: 'Dell OptiPlex 7090',
      type: 'computer',
      location: 'Computer Lab',
      status: 'available',
      condition: 'excellent',
      purchaseDate: '2024-01-15',
      lastMaintenance: '2024-08-01',
      assignedTo: 'Dr. Smith Johnson'
    },
    {
      id: '2',
      name: 'Epson PowerLite Projector',
      type: 'projector',
      location: 'Classroom A',
      status: 'in_use',
      condition: 'good',
      purchaseDate: '2023-06-20',
      lastMaintenance: '2024-07-15'
    },
    {
      id: '3',
      name: 'HP LaserJet Pro',
      type: 'printer',
      location: 'Office',
      status: 'maintenance',
      condition: 'fair',
      purchaseDate: '2023-03-10',
      lastMaintenance: '2024-09-18'
    },
    {
      id: '4',
      name: 'Interactive Whiteboard',
      type: 'whiteboard',
      location: 'Classroom B',
      status: 'damaged',
      condition: 'poor',
      purchaseDate: '2022-09-05',
      lastMaintenance: '2024-08-20'
    }
  ]);

  const [maintenanceRequests] = useState<MaintenanceRequest[]>([
    {
      id: '1',
      equipmentId: '3',
      equipmentName: 'HP LaserJet Pro',
      reportedBy: 'Admin Staff',
      issue: 'Paper jam and print quality issues',
      priority: 'high',
      status: 'in_progress',
      reportDate: '2024-09-18',
      estimatedCost: 150
    },
    {
      id: '2',
      equipmentId: '4',
      equipmentName: 'Interactive Whiteboard',
      reportedBy: 'Prof. Sarah Wilson',
      issue: 'Touch screen not responding in bottom right corner',
      priority: 'medium',
      status: 'pending',
      reportDate: '2024-09-16',
      estimatedCost: 300
    },
    {
      id: '3',
      equipmentId: '2',
      equipmentName: 'Epson PowerLite Projector',
      reportedBy: 'Dr. Michael Brown',
      issue: 'Bulb replacement needed',
      priority: 'low',
      status: 'completed',
      reportDate: '2024-09-10',
      estimatedCost: 80
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
      case 'available':
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in_use':
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      case 'maintenance':
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'damaged':
      case 'cancelled': return 'bg-red-100 text-red-800';
      case 'archived': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'excellent': return 'bg-green-100 text-green-800';
      case 'good': return 'bg-blue-100 text-blue-800';
      case 'fair': return 'bg-yellow-100 text-yellow-800';
      case 'poor': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'computer': return <Monitor className="h-4 w-4" />;
      case 'projector': return <Monitor className="h-4 w-4" />;
      case 'printer': return <Printer className="h-4 w-4" />;
      case 'whiteboard': return <BookOpen className="h-4 w-4" />;
      default: return <Database className="h-4 w-4" />;
    }
  };

  const filteredResources = learningResources.filter(resource =>
    (resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
     resource.description.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (selectedSubject === 'all' || resource.subject === selectedSubject)
  );

  const filteredEquipment = equipment.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1>Resources</h1>
          <p className="text-muted-foreground">Manage learning materials and equipment</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isNewMaintenanceOpen} onOpenChange={setIsNewMaintenanceOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <AlertTriangle className="h-4 w-4" />
                Report Issue
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Report Maintenance Issue</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Equipment</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select equipment" />
                    </SelectTrigger>
                    <SelectContent>
                      {equipment.map((item) => (
                        <SelectItem key={item.id} value={item.id}>
                          {item.name} - {item.location}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Priority</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Issue Description</Label>
                  <Input placeholder="Describe the issue..." />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsNewMaintenanceOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsNewMaintenanceOpen(false)}>
                    Submit Report
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Dialog open={isNewResourceOpen} onOpenChange={setIsNewResourceOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Add Resource
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add Learning Resource</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Title</Label>
                    <Input placeholder="Resource title" />
                  </div>
                  <div className="space-y-2">
                    <Label>Type</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="worksheet">Worksheet</SelectItem>
                        <SelectItem value="video">Video</SelectItem>
                        <SelectItem value="presentation">Presentation</SelectItem>
                        <SelectItem value="book">Book</SelectItem>
                        <SelectItem value="assessment">Assessment</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Subject</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select subject" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Mathematics">Mathematics</SelectItem>
                        <SelectItem value="Science">Science</SelectItem>
                        <SelectItem value="English">English</SelectItem>
                        <SelectItem value="Te Reo Māori">Te Reo Māori</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Grade</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select grade" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Grade 1">Grade 1</SelectItem>
                        <SelectItem value="Grade 2">Grade 2</SelectItem>
                        <SelectItem value="Grade 3">Grade 3</SelectItem>
                        <SelectItem value="Grade 4">Grade 4</SelectItem>
                        <SelectItem value="Grade 5">Grade 5</SelectItem>
                        <SelectItem value="Grade 6">Grade 6</SelectItem>
                        <SelectItem value="Grade 7">Grade 7</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Input placeholder="Resource description" />
                </div>
                <div className="space-y-2">
                  <Label>File</Label>
                  <div className="border-2 border-dashed border-muted rounded-lg p-6 text-center">
                    <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">
                      Drop your file here or click to browse
                    </p>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsNewResourceOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsNewResourceOpen(false)}>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Resource
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Resource Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">{learningResources.length}</div>
                <p className="text-xs text-muted-foreground">Learning Resources</p>
              </div>
              <BookOpen className="h-5 w-5 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">{equipment.length}</div>
                <p className="text-xs text-muted-foreground">Equipment Items</p>
              </div>
              <Monitor className="h-5 w-5 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">{maintenanceRequests.filter(r => r.status === 'pending').length}</div>
                <p className="text-xs text-muted-foreground">Pending Maintenance</p>
              </div>
              <AlertTriangle className="h-5 w-5 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">{learningResources.reduce((sum, r) => sum + r.downloads, 0)}</div>
                <p className="text-xs text-muted-foreground">Total Downloads</p>
              </div>
              <Download className="h-5 w-5 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="learning" className="space-y-4">
        <TabsList>
          <TabsTrigger value="learning">Learning Resources</TabsTrigger>
          <TabsTrigger value="equipment">Equipment</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
          <TabsTrigger value="inventory">Inventory</TabsTrigger>
        </TabsList>

        <TabsContent value="learning" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search resources..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                  <SelectTrigger className="w-full md:w-[200px]">
                    <SelectValue placeholder="Filter by subject" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Subjects</SelectItem>
                    <SelectItem value="Mathematics">Mathematics</SelectItem>
                    <SelectItem value="Science">Science</SelectItem>
                    <SelectItem value="English">English</SelectItem>
                    <SelectItem value="Te Reo Māori">Te Reo Māori</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Resources Table */}
          <Card>
            <CardHeader>
              <CardTitle>Learning Resources ({filteredResources.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Grade</TableHead>
                    <TableHead>Downloads</TableHead>
                    <TableHead>Size</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredResources.map((resource) => (
                    <TableRow key={resource.id}>
                      <TableCell>
                        <div>
                          <div>{resource.title}</div>
                          <div className="text-sm text-muted-foreground">
                            {resource.description}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">
                          {resource.type.charAt(0).toUpperCase() + resource.type.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>{resource.subject}</TableCell>
                      <TableCell>{resource.grade}</TableCell>
                      <TableCell>{resource.downloads}</TableCell>
                      <TableCell>{resource.fileSize}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(resource.status)}>
                          {resource.status.charAt(0).toUpperCase() + resource.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">
                            <Download className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="equipment" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Equipment Inventory</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Equipment</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Condition</TableHead>
                    <TableHead>Last Maintenance</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEquipment.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getTypeIcon(item.type)}
                          <div>
                            <div>{item.name}</div>
                            {item.assignedTo && (
                              <div className="text-sm text-muted-foreground">
                                Assigned to: {item.assignedTo}
                              </div>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">
                          {item.type.replace('_', ' ').charAt(0).toUpperCase() + item.type.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>{item.location}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(item.status)}>
                          {item.status.replace('_', ' ').charAt(0).toUpperCase() + item.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getConditionColor(item.condition)}>
                          {item.condition.charAt(0).toUpperCase() + item.condition.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>{new Date(item.lastMaintenance).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <AlertTriangle className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Maintenance Requests</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Equipment</TableHead>
                    <TableHead>Issue</TableHead>
                    <TableHead>Reported By</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Estimated Cost</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {maintenanceRequests.map((request) => (
                    <TableRow key={request.id}>
                      <TableCell>
                        <div>
                          <div>{request.equipmentName}</div>
                          <div className="text-sm text-muted-foreground">
                            ID: {request.equipmentId}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="max-w-[200px]">
                        <div className="truncate">{request.issue}</div>
                      </TableCell>
                      <TableCell>{request.reportedBy}</TableCell>
                      <TableCell>
                        <Badge className={getPriorityColor(request.priority)}>
                          {request.priority.charAt(0).toUpperCase() + request.priority.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(request.status)}>
                          {request.status.replace('_', ' ').charAt(0).toUpperCase() + request.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {request.estimatedCost ? `$${request.estimatedCost}` : 'TBD'}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          {request.status === 'pending' && (
                            <Button variant="ghost" size="sm">
                              <CheckCircle className="h-4 w-4" />
                            </Button>
                          )}
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inventory" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Equipment Status Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Available</span>
                      <span>25%</span>
                    </div>
                    <Progress value={25} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>In Use</span>
                      <span>50%</span>
                    </div>
                    <Progress value={50} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Maintenance</span>
                      <span>15%</span>
                    </div>
                    <Progress value={15} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Damaged</span>
                      <span>10%</span>
                    </div>
                    <Progress value={10} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Resource Utilization</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Classroom Computers</span>
                    <span className="text-sm">12/15 in use</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Projectors</span>
                    <span className="text-sm">3/4 in use</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Printers</span>
                    <span className="text-sm">2/3 operational</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Interactive Whiteboards</span>
                    <span className="text-sm">4/5 operational</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Upcoming Maintenance Schedule</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <div className="flex-1">
                    <div className="text-sm">Dell OptiPlex Computers - Monthly Update</div>
                    <div className="text-xs text-muted-foreground">Scheduled for October 1, 2024</div>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <div className="flex-1">
                    <div className="text-sm">Projector Lens Cleaning</div>
                    <div className="text-xs text-muted-foreground">Scheduled for October 5, 2024</div>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <div className="flex-1">
                    <div className="text-sm">Network Equipment Check</div>
                    <div className="text-xs text-muted-foreground">Scheduled for October 10, 2024</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}