import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { Badge } from '../ui/badge';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  GraduationCap, 
  DollarSign,
  Calendar,
  Download,
  Filter,
  Award,
  Clock,
  BookOpen
} from 'lucide-react';

interface SubjectPerformance {
  subject: string;
  averageScore: number;
  totalStudents: number;
  passRate: number;
  trend: 'up' | 'down' | 'stable';
}

interface AttendanceData {
  month: string;
  studentAttendance: number;
  teacherAttendance: number;
  classesHeld: number;
  classesCancelled: number;
}

export function AdminReports() {
  const [selectedPeriod, setSelectedPeriod] = useState('current-month');
  const [selectedGrade, setSelectedGrade] = useState('all');

  const [subjectPerformance] = useState<SubjectPerformance[]>([
    { subject: 'Mathematics', averageScore: 78, totalStudents: 120, passRate: 85, trend: 'up' },
    { subject: 'Science', averageScore: 82, totalStudents: 98, passRate: 89, trend: 'up' },
    { subject: 'English', averageScore: 75, totalStudents: 85, passRate: 81, trend: 'stable' },
    { subject: 'Te Reo Māori', averageScore: 88, totalStudents: 45, passRate: 95, trend: 'up' }
  ]);

  const [attendanceData] = useState<AttendanceData[]>([
    { month: 'September', studentAttendance: 87, teacherAttendance: 94, classesHeld: 124, classesCancelled: 6 },
    { month: 'August', studentAttendance: 85, teacherAttendance: 92, classesHeld: 118, classesCancelled: 8 },
    { month: 'July', studentAttendance: 83, teacherAttendance: 90, classesHeld: 115, classesCancelled: 12 }
  ]);

  const getTrendIcon = (trend: string) => {
    if (trend === 'up') return <TrendingUp className="h-4 w-4 text-green-600" />;
    if (trend === 'down') return <TrendingUp className="h-4 w-4 text-red-600 rotate-180" />;
    return <div className="h-4 w-4" />;
  };

  const getPerformanceColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1>Reports & Analytics</h1>
          <p className="text-muted-foreground">Comprehensive insights into center performance</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Filter className="h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Period and Grade Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Select period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="current-month">Current Month</SelectItem>
                <SelectItem value="last-month">Last Month</SelectItem>
                <SelectItem value="quarter">This Quarter</SelectItem>
                <SelectItem value="year">This Year</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedGrade} onValueChange={setSelectedGrade}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Select grade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Grades</SelectItem>
                <SelectItem value="grade-1">Grade 1</SelectItem>
                <SelectItem value="grade-2">Grade 2</SelectItem>
                <SelectItem value="grade-3">Grade 3</SelectItem>
                <SelectItem value="grade-4">Grade 4</SelectItem>
                <SelectItem value="grade-5">Grade 5</SelectItem>
                <SelectItem value="grade-6">Grade 6</SelectItem>
                <SelectItem value="grade-7">Grade 7</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">247</div>
                <p className="text-xs text-muted-foreground">Active Students</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3 text-green-600" />
                  <span className="text-xs text-green-600">+5.2%</span>
                </div>
              </div>
              <Users className="h-5 w-5 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">18</div>
                <p className="text-xs text-muted-foreground">Active Teachers</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3 text-green-600" />
                  <span className="text-xs text-green-600">+2</span>
                </div>
              </div>
              <GraduationCap className="h-5 w-5 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">87%</div>
                <p className="text-xs text-muted-foreground">Avg Attendance</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3 text-green-600" />
                  <span className="text-xs text-green-600">+2.1%</span>
                </div>
              </div>
              <Clock className="h-5 w-5 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">$24,500</div>
                <p className="text-xs text-muted-foreground">Monthly Revenue</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3 text-green-600" />
                  <span className="text-xs text-green-600">+8.2%</span>
                </div>
              </div>
              <DollarSign className="h-5 w-5 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="academic" className="space-y-4">
        <TabsList>
          <TabsTrigger value="academic">Academic Performance</TabsTrigger>
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="financial">Financial</TabsTrigger>
          <TabsTrigger value="operational">Operational</TabsTrigger>
        </TabsList>

        <TabsContent value="academic" className="space-y-4">
          {/* Subject Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Subject Performance Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {subjectPerformance.map((subject, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <h3>{subject.subject}</h3>
                        {getTrendIcon(subject.trend)}
                      </div>
                      <Badge variant="secondary">{subject.totalStudents} students</Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Average Score</span>
                          <span className={getPerformanceColor(subject.averageScore)}>
                            {subject.averageScore}%
                          </span>
                        </div>
                        <Progress value={subject.averageScore} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Pass Rate</span>
                          <span className={getPerformanceColor(subject.passRate)}>
                            {subject.passRate}%
                          </span>
                        </div>
                        <Progress value={subject.passRate} className="h-2" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Grade Distribution */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Grade Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">A Grade (90-100%)</span>
                    <div className="flex items-center gap-2">
                      <Progress value={25} className="w-20 h-2" />
                      <span className="text-sm">25%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">B Grade (80-89%)</span>
                    <div className="flex items-center gap-2">
                      <Progress value={35} className="w-20 h-2" />
                      <span className="text-sm">35%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">C Grade (70-79%)</span>
                    <div className="flex items-center gap-2">
                      <Progress value={25} className="w-20 h-2" />
                      <span className="text-sm">25%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">D Grade (60-69%)</span>
                    <div className="flex items-center gap-2">
                      <Progress value={12} className="w-20 h-2" />
                      <span className="text-sm">12%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">F Grade (Below 60%)</span>
                    <div className="flex items-center gap-2">
                      <Progress value={3} className="w-20 h-2" />
                      <span className="text-sm">3%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Top Performers
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-2 bg-muted/50 rounded">
                    <div>
                      <div className="text-sm">Sarah Chen</div>
                      <div className="text-xs text-muted-foreground">Grade 7 - Mathematics</div>
                    </div>
                    <Badge className="bg-yellow-100 text-yellow-800">98%</Badge>
                  </div>
                  <div className="flex justify-between items-center p-2 bg-muted/50 rounded">
                    <div>
                      <div className="text-sm">Tommy Wilson</div>
                      <div className="text-xs text-muted-foreground">Grade 6 - Science</div>
                    </div>
                    <Badge className="bg-yellow-100 text-yellow-800">97%</Badge>
                  </div>
                  <div className="flex justify-between items-center p-2 bg-muted/50 rounded">
                    <div>
                      <div className="text-sm">Mia Johnson</div>
                      <div className="text-xs text-muted-foreground">Grade 5 - English</div>
                    </div>
                    <Badge className="bg-yellow-100 text-yellow-800">96%</Badge>
                  </div>
                  <div className="flex justify-between items-center p-2 bg-muted/50 rounded">
                    <div>
                      <div className="text-sm">Alex Brown</div>
                      <div className="text-xs text-muted-foreground">Grade 7 - Te Reo Māori</div>
                    </div>
                    <Badge className="bg-yellow-100 text-yellow-800">95%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="attendance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Student Attendance Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {attendanceData.map((data, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span>{data.month}</span>
                        <span className="text-sm text-muted-foreground">
                          {data.studentAttendance}% attendance
                        </span>
                      </div>
                      <Progress value={data.studentAttendance} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Class Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {attendanceData.map((data, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-sm">{data.month}</span>
                      <div className="text-right">
                        <div className="text-sm">{data.classesHeld} held</div>
                        <div className="text-xs text-muted-foreground">
                          {data.classesCancelled} cancelled
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Attendance Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-2xl text-green-600">87%</div>
                  <p className="text-sm text-muted-foreground">Average Student Attendance</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl text-blue-600">94%</div>
                  <p className="text-sm text-muted-foreground">Average Teacher Attendance</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl text-purple-600">92%</div>
                  <p className="text-sm text-muted-foreground">Classes Completion Rate</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="financial" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Mathematics Classes</span>
                    <span>$12,000 (49%)</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Science Classes</span>
                    <span>$7,800 (32%)</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>English Classes</span>
                    <span>$3,200 (13%)</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Te Reo Māori Classes</span>
                    <span>$1,500 (6%)</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Payment Collection</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Collected on Time</span>
                      <span>82%</span>
                    </div>
                    <Progress value={82} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Late Payments</span>
                      <span>15%</span>
                    </div>
                    <Progress value={15} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Outstanding</span>
                      <span>3%</span>
                    </div>
                    <Progress value={3} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="operational" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Resource Utilization</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Classroom Capacity</span>
                      <span>78%</span>
                    </div>
                    <Progress value={78} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Teacher Workload</span>
                      <span>85%</span>
                    </div>
                    <Progress value={85} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Equipment Usage</span>
                      <span>65%</span>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Student Satisfaction</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl text-green-600 mb-2">4.6/5</div>
                  <p className="text-sm text-muted-foreground">Average Rating</p>
                  <div className="mt-4 space-y-2">
                    <div className="flex justify-between text-xs">
                      <span>Teaching Quality</span>
                      <span>4.8/5</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span>Learning Environment</span>
                      <span>4.5/5</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span>Support Services</span>
                      <span>4.4/5</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Growth Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">New Enrollments</span>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="h-3 w-3 text-green-600" />
                      <span className="text-sm text-green-600">+12</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Student Retention</span>
                    <span className="text-sm">94%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Referral Rate</span>
                    <span className="text-sm">23%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}