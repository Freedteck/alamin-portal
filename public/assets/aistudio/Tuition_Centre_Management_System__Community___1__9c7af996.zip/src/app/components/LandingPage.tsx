import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import heroBackground from 'figma:asset/16a5afdd0d20b686fbe8f4927b7495dc36874501.png';
import { 
  GraduationCap, 
  Users, 
  Award, 
  Clock, 
  BookOpen, 
  Calculator, 
  Atom, 
  Globe, 
  Languages,
  Star,
  Phone,
  Mail,
  MapPin,
  ChevronRight,
  CalendarCheck
} from 'lucide-react';

interface LandingPageProps {
  onEnquireNow: () => void;
  onLogin: () => void;
  onBookAppointment: () => void;
}

export function LandingPage({ onEnquireNow, onLogin, onBookAppointment }: LandingPageProps) {
  const subjects = [
    {
      name: 'Mathematics',
      icon: Calculator,
      description: 'From basic arithmetic to advanced calculus, our expert tutors help students excel in all areas of mathematics.',
      levels: ['NCEA Level 1', 'NCEA Level 2', 'NCEA Level 3', 'Scholarship']
    },
    {
      name: 'Science',
      icon: Atom,
      description: 'Comprehensive science tutoring covering Physics, Chemistry, and Biology with hands-on learning approaches.',
      levels: ['Year 9-10', 'NCEA Level 1', 'NCEA Level 2', 'NCEA Level 3']
    },
    {
      name: 'English',
      icon: BookOpen,
      description: 'Improve reading, writing, and critical thinking skills with our qualified English language specialists.',
      levels: ['Year 9-13', 'NCEA All Levels', 'University Preparation']
    },
    {
      name: 'Te Reo Māori',
      icon: Languages,
      description: 'Learn New Zealand\'s indigenous language with native speakers and culturally authentic teaching methods.',
      levels: ['Beginner', 'Intermediate', 'NCEA Levels', 'Conversational']
    }
  ];

  const features = [
    {
      icon: Users,
      title: 'Qualified Tutors',
      description: 'Our team consists of qualified teachers with university degrees and teaching credentials.'
    },
    {
      icon: Clock,
      title: 'Flexible Scheduling',
      description: 'Choose from various time slots that fit your busy schedule, including weekends and holidays.'
    },
    {
      icon: Award,
      title: 'Proven Results',
      description: '95% of our students show significant improvement in their grades within the first term.'
    },
    {
      icon: Globe,
      title: 'Online & In-Person',
      description: 'Hybrid learning options available - attend classes in person or join online from home.'
    }
  ];

  const testimonials = [
    {
      name: 'Emma Rodriguez',
      subject: 'Year 6 Mathematics',
      rating: 5,
      comment: 'The tutors helped my daughter improve her maths skills and build confidence. Her grades have improved so much!'
    },
    {
      name: 'Michael Thompson',
      subject: 'Year 5 English',
      rating: 5,
      comment: 'My son\'s reading and writing have improved dramatically. The teachers make learning fun and engaging.'
    },
    {
      name: 'Kaia Williams',
      subject: 'Te Reo Māori',
      rating: 5,
      comment: 'Learning Te Reo with native speakers made all the difference. Kia ora to the amazing team!'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-xl font-semibold">Ilam Tuition Centre</h1>
              <p className="text-xs text-muted-foreground">Excellence in Education</p>
            </div>
          </div>
          <Button onClick={onLogin} variant="outline">
            Login
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section 
        className="py-24 bg-gradient-to-br from-slate-50 to-blue-50/50 relative overflow-hidden"
        style={{
          backgroundImage: `url(${heroBackground})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      >
        {/* Overlay for better text readability */}
        <div className="absolute inset-0 bg-white/85"></div>
        
        <div className="container mx-auto px-4 text-center relative z-10">
          <Badge variant="secondary" className="mb-6 bg-slate-100/95 text-slate-800 border-slate-200/60 backdrop-blur-sm">
            Christchurch's Premier Tuition Centre
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-foreground">
            Unlock Your Academic
            <span className="text-slate-700 block">
              Potential
            </span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Specialised tutoring in Mathematics, Science, English, and Te Reo Māori 
            with qualified teachers dedicated to your success.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button onClick={onEnquireNow} size="lg" className="text-lg px-8 bg-slate-700 hover:bg-slate-800 text-white shadow-lg">
              Enquire Now
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
            <Button onClick={onBookAppointment} variant="outline" size="lg" className="text-lg px-8 border-slate-300 text-slate-700 hover:bg-slate-100/80 bg-white/90 backdrop-blur-sm shadow-lg">
              <CalendarCheck className="mr-2 h-5 w-5" />
              Book an Appointment
            </Button>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16 max-w-4xl mx-auto">
            <div className="text-center p-4 rounded-lg bg-white/95 border border-slate-200/60 backdrop-blur-sm shadow-lg">
              <div className="text-3xl font-bold text-slate-700">500+</div>
              <div className="text-sm text-slate-600">Students Taught</div>
            </div>
            <div className="text-center p-4 rounded-lg bg-white/95 border border-slate-200/60 backdrop-blur-sm shadow-lg">
              <div className="text-3xl font-bold text-slate-700">15+</div>
              <div className="text-sm text-slate-600">Qualified Tutors</div>
            </div>
            <div className="text-center p-4 rounded-lg bg-white/95 border border-slate-200/60 backdrop-blur-sm shadow-lg">
              <div className="text-3xl font-bold text-slate-700">95%</div>
              <div className="text-sm text-slate-600">Success Rate</div>
            </div>
            <div className="text-center p-4 rounded-lg bg-white/95 border border-slate-200/60 backdrop-blur-sm shadow-lg">
              <div className="text-3xl font-bold text-slate-700">8</div>
              <div className="text-sm text-slate-600">Years Experience</div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">About Ilam Tuition Centre</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Located in the heart of Christchurch, we've been providing exceptional tutoring services 
              to students across Canterbury for over 8 years. Our mission is to help every student 
              reach their full academic potential through personalized learning approaches.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-semibold mb-6">Why Choose Us?</h3>
              <div className="space-y-6">
                {features.map((feature, index) => {
                  const Icon = feature.icon;
                  return (
                    <div key={index} className="flex gap-4">
                      <div className="flex-shrink-0">
                        <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                          <Icon className="h-6 w-6 text-blue-400/80" />
                        </div>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2">{feature.title}</h4>
                        <p className="text-muted-foreground">{feature.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="bg-blue-50/30 rounded-lg p-8 border border-blue-100/30">
              <h3 className="text-xl font-semibold mb-6">Our Commitment</h3>
              <ul className="space-y-4 text-muted-foreground">
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-300/70 rounded-full mt-2 flex-shrink-0"></div>
                  <span>Small class sizes for personalized attention</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-300/70 rounded-full mt-2 flex-shrink-0"></div>
                  <span>Regular progress assessments and reports</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-300/70 rounded-full mt-2 flex-shrink-0"></div>
                  <span>Experienced NCEA and Scholarship specialists</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-300/70 rounded-full mt-2 flex-shrink-0"></div>
                  <span>Flexible learning options (in-person & online)</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-300/70 rounded-full mt-2 flex-shrink-0"></div>
                  <span>Supportive and encouraging learning environment</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-300/70 rounded-full mt-2 flex-shrink-0"></div>
                  <span>Additional exam preparation and study skills</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Subjects Section */}
      <section className="py-20 bg-slate-50/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Subjects</h2>
            <p className="text-xl text-muted-foreground">
              Comprehensive tutoring across key academic areas
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            {subjects.map((subject, index) => {
              const Icon = subject.icon;
              const colors = [
                { bg: 'bg-blue-50', icon: 'text-blue-400/80', border: 'border-blue-100/60' },
                { bg: 'bg-green-50', icon: 'text-green-400/80', border: 'border-green-100/60' },
                { bg: 'bg-purple-50', icon: 'text-purple-400/80', border: 'border-purple-100/60' },
                { bg: 'bg-orange-50', icon: 'text-orange-400/80', border: 'border-orange-100/60' }
              ];
              const color = colors[index];
              
              return (
                <Card key={index} className={`hover:shadow-lg transition-all duration-300 border ${color.border} hover:border-opacity-80 bg-white/90`}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <div className={`w-12 h-12 ${color.bg} rounded-lg flex items-center justify-center`}>
                        <Icon className={`h-6 w-6 ${color.icon}`} />
                      </div>
                      <span>{subject.name}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">{subject.description}</p>
                    <div>
                      <p className="text-sm font-medium mb-3 text-blue-500/80">Available Levels:</p>
                      <div className="flex flex-wrap gap-2">
                        {subject.levels.map((level, levelIndex) => (
                          <Badge key={levelIndex} variant="secondary" className="bg-blue-50/80 text-blue-500/80 border-blue-100/60">
                            {level}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Students Say</h2>
            <p className="text-xl text-muted-foreground">
              Real success stories from our students
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow duration-300 border-blue-100/40 bg-gradient-to-b from-white to-blue-50/10">
                <CardContent className="pt-6">
                  <div className="flex items-center mb-4">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-300/80 fill-current" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4 italic">"{testimonial.comment}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-300/70 rounded-full flex items-center justify-center text-white font-semibold">
                      {testimonial.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-semibold">{testimonial.name}</div>
                      <div className="text-sm text-blue-400/70">{testimonial.subject}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gradient-to-br from-slate-700 via-slate-800 to-slate-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">Ready to Get Started?</h2>
          <p className="text-xl mb-12 text-slate-200 max-w-2xl mx-auto">
            Contact us today to discuss your learning goals and find the perfect tutor for you.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12 max-w-4xl mx-auto">
            <div className="flex items-center justify-center gap-3 text-slate-100">
              <div className="p-3 bg-white/20 rounded-full">
                <Phone className="h-5 w-5" />
              </div>
              <span>(03) 555-0123</span>
            </div>
            <div className="flex items-center justify-center gap-3 text-slate-100">
              <div className="p-3 bg-white/20 rounded-full">
                <Mail className="h-5 w-5" />
              </div>
              <span>info@ilamtuition.co.nz</span>
            </div>
            <div className="flex items-center justify-center gap-3 text-slate-100">
              <div className="p-3 bg-white/20 rounded-full">
                <MapPin className="h-5 w-5" />
              </div>
              <span>Ilam Road, Christchurch</span>
            </div>
          </div>
          
          <Button onClick={onEnquireNow} size="lg" variant="secondary" className="text-lg px-8 bg-white text-slate-700 hover:bg-slate-50 shadow-lg">
            Enquire Now - Free Consultation
            <ChevronRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-muted">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <GraduationCap className="h-6 w-6 text-primary" />
                <span className="font-semibold">Ilam Tuition Centre</span>
              </div>
              <p className="text-muted-foreground text-sm">
                Excellence in education for over 8 years. Helping Christchurch students achieve their academic goals.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Subjects</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>Mathematics</li>
                <li>Science</li>
                <li>English</li>
                <li>Te Reo Māori</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Services</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>Individual Tutoring</li>
                <li>Group Classes</li>
                <li>Online Learning</li>
                <li>Exam Preparation</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Contact</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>(03) 555-0123</li>
                <li>info@ilamtuition.co.nz</li>
                <li>Ilam Road, Christchurch</li>
                <li>New Zealand</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
            © 2024 Ilam Tuition Centre. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}