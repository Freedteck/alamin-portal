import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { Mail, Phone, User, MessageSquare } from 'lucide-react';

interface EnquireModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function EnquireModal({ isOpen, onClose }: EnquireModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    studentName: '',
    yearLevel: '',
    subjects: [] as string[],
    preferredTime: '',
    message: '',
    contactMethod: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const subjects = [
    'Mathematics - NCEA Level 1',
    'Mathematics - NCEA Level 2', 
    'Mathematics - NCEA Level 3',
    'Mathematics - Scholarship',
    'Physics - NCEA Level 1',
    'Physics - NCEA Level 2',
    'Physics - NCEA Level 3',
    'Chemistry - NCEA Level 1',
    'Chemistry - NCEA Level 2', 
    'Chemistry - NCEA Level 3',
    'Biology - NCEA Level 1',
    'Biology - NCEA Level 2',
    'Biology - NCEA Level 3',
    'English - Year 9-10',
    'English - NCEA Level 1',
    'English - NCEA Level 2',
    'English - NCEA Level 3',
    'Te Reo Māori - Beginner',
    'Te Reo Māori - Intermediate',
    'Te Reo Māori - NCEA'
  ];

  const handleSubjectToggle = (subject: string) => {
    setFormData(prev => ({
      ...prev,
      subjects: prev.subjects.includes(subject)
        ? prev.subjects.filter(s => s !== subject)
        : [...prev.subjects, subject]
    }));
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.email || !formData.phone || !formData.studentName) {
      alert('Please fill in all required fields');
      return;
    }

    if (formData.subjects.length === 0) {
      alert('Please select at least one subject');
      return;
    }

    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setSubmitted(true);
    
    // Auto close after 3 seconds
    setTimeout(() => {
      setSubmitted(false);
      onClose();
      // Reset form
      setFormData({
        name: '',
        email: '',
        phone: '',
        studentName: '',
        yearLevel: '',
        subjects: [],
        preferredTime: '',
        message: '',
        contactMethod: ''
      });
    }, 3000);
  };

  if (submitted) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-md text-center">
          <DialogHeader>
            <DialogTitle className="text-center text-green-600">
              Enquiry Submitted Successfully!
            </DialogTitle>
            <DialogDescription className="text-center">
              Your enquiry has been received and we will contact you soon
            </DialogDescription>
          </DialogHeader>
          <div className="py-6">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="h-8 w-8 text-green-600" />
            </div>
            <p className="text-muted-foreground mb-4">
              Thank you for your interest in Ilam Tuition Centre!
            </p>
            <p className="text-sm text-muted-foreground">
              Our team will contact you within 24 hours to discuss your tutoring needs and schedule a free consultation.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <MessageSquare className="h-6 w-6 text-primary" />
              Enquire About Tutoring
            </div>
          </DialogTitle>
          <DialogDescription className="text-center">
            Fill out this form for a free consultation with our qualified tutors
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Parent/Guardian Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <User className="h-5 w-5" />
              Parent/Guardian Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  placeholder="Your full name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  placeholder="(03) 123-4567"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contactMethod">Preferred Contact Method</Label>
                <Select value={formData.contactMethod} onValueChange={(value) => setFormData(prev => ({ ...prev, contactMethod: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="How should we contact you?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="phone">Phone Call</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="text">Text Message</SelectItem>
                    <SelectItem value="whatsapp">WhatsApp</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Student Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Student Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="studentName">Student Name *</Label>
                <Input
                  id="studentName"
                  placeholder="Student's full name"
                  value={formData.studentName}
                  onChange={(e) => setFormData(prev => ({ ...prev, studentName: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="yearLevel">Year Level</Label>
                <Select value={formData.yearLevel} onValueChange={(value) => setFormData(prev => ({ ...prev, yearLevel: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select year level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="year-9">Year 9</SelectItem>
                    <SelectItem value="year-10">Year 10</SelectItem>
                    <SelectItem value="year-11">Year 11</SelectItem>
                    <SelectItem value="year-12">Year 12</SelectItem>
                    <SelectItem value="year-13">Year 13</SelectItem>
                    <SelectItem value="adult">Adult Learner</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Subjects */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Subjects of Interest *</h3>
            <p className="text-sm text-muted-foreground">Select all subjects you're interested in:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {subjects.map((subject) => (
                <div key={subject} className="flex items-center space-x-2">
                  <Checkbox
                    id={subject}
                    checked={formData.subjects.includes(subject)}
                    onCheckedChange={() => handleSubjectToggle(subject)}
                  />
                  <Label
                    htmlFor={subject}
                    className="text-sm cursor-pointer"
                  >
                    {subject}
                  </Label>
                </div>
              ))}
            </div>
            {formData.subjects.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {formData.subjects.map((subject) => (
                  <Badge key={subject} variant="secondary">
                    {subject}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Preferences */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Tutoring Preferences</h3>
            <div className="space-y-2">
              <Label htmlFor="preferredTime">Preferred Time Slots</Label>
              <Select value={formData.preferredTime} onValueChange={(value) => setFormData(prev => ({ ...prev, preferredTime: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="When works best for you?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="weekday-morning">Weekday Morning (9am-12pm)</SelectItem>
                  <SelectItem value="weekday-afternoon">Weekday Afternoon (1pm-4pm)</SelectItem>
                  <SelectItem value="weekday-evening">Weekday Evening (4pm-7pm)</SelectItem>
                  <SelectItem value="saturday-morning">Saturday Morning</SelectItem>
                  <SelectItem value="saturday-afternoon">Saturday Afternoon</SelectItem>
                  <SelectItem value="sunday">Sunday</SelectItem>
                  <SelectItem value="flexible">Flexible - discuss options</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Additional Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Additional Information</h3>
            <div className="space-y-2">
              <Label htmlFor="message">Tell us about your learning goals or any specific areas of focus</Label>
              <Textarea
                id="message"
                placeholder="e.g., preparing for NCEA exams, struggling with algebra, want to improve essay writing skills..."
                rows={4}
                value={formData.message}
                onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button 
              onClick={handleSubmit} 
              className="flex-1"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Submitting...' : 'Submit Enquiry'}
            </Button>
            <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
          </div>

          <div className="text-center text-xs text-muted-foreground">
            <p>* Required fields</p>
            <p>We'll respond within 24 hours. Free consultation included!</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}