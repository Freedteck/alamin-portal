import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent } from './ui/card';
import { GraduationCap, Users, Shield } from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (userType: 'student' | 'staff' | 'admin', credentials: { email: string; password: string }) => void;
}

export function LoginModal({ isOpen, onClose, onLogin }: LoginModalProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [activeTab, setActiveTab] = useState('student');

  const handleLogin = (userType: 'student' | 'staff' | 'admin') => {
    // Basic validation
    if (!email || !password) {
      alert('Please enter both email and password');
      return;
    }
    
    onLogin(userType, { email, password });
    setEmail('');
    setPassword('');
    onClose();
  };

  const demoCredentials = {
    student: { email: 'student@ilamtuition.co.nz', password: 'student123' },
    staff: { email: 'staff@ilamtuition.co.nz', password: 'staff123' },
    admin: { email: 'admin@ilamtuition.co.nz', password: 'admin123' }
  };

  const fillDemoCredentials = (userType: 'student' | 'staff' | 'admin') => {
    setEmail(demoCredentials[userType].email);
    setPassword(demoCredentials[userType].password);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <GraduationCap className="h-6 w-6 text-primary" />
              Login to Ilam Tuition Centre
            </div>
          </DialogTitle>
          <DialogDescription className="text-center">
            Choose your account type and enter your credentials to access the portal
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="student" className="text-xs">
              <Users className="h-4 w-4 mr-1" />
              Student
            </TabsTrigger>
            <TabsTrigger value="staff" className="text-xs">
              <GraduationCap className="h-4 w-4 mr-1" />
              Staff
            </TabsTrigger>
            <TabsTrigger value="admin" className="text-xs">
              <Shield className="h-4 w-4 mr-1" />
              Admin
            </TabsTrigger>
          </TabsList>

          <TabsContent value="student" className="space-y-4">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="text-center text-sm text-muted-foreground">
                    Student Portal Access
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="student-email">Email</Label>
                    <Input
                      id="student-email"
                      type="email"
                      placeholder="Enter your student email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="student-password">Password</Label>
                    <Input
                      id="student-password"
                      type="password"
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                  <Button 
                    onClick={() => handleLogin('student')} 
                    className="w-full"
                  >
                    Login as Student
                  </Button>
                  <Button 
                    onClick={() => fillDemoCredentials('student')}
                    variant="outline" 
                    className="w-full text-xs"
                  >
                    Use Demo Credentials
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="staff" className="space-y-4">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="text-center text-sm text-muted-foreground">
                    Staff Portal Access
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="staff-email">Email</Label>
                    <Input
                      id="staff-email"
                      type="email"
                      placeholder="Enter your staff email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="staff-password">Password</Label>
                    <Input
                      id="staff-password"
                      type="password"
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                  <Button 
                    onClick={() => handleLogin('staff')} 
                    className="w-full"
                  >
                    Login as Staff
                  </Button>
                  <Button 
                    onClick={() => fillDemoCredentials('staff')}
                    variant="outline" 
                    className="w-full text-xs"
                  >
                    Use Demo Credentials
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="admin" className="space-y-4">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="text-center text-sm text-muted-foreground">
                    Administrator Access
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admin-email">Email</Label>
                    <Input
                      id="admin-email"
                      type="email"
                      placeholder="Enter your admin email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admin-password">Password</Label>
                    <Input
                      id="admin-password"
                      type="password"
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                  <Button 
                    onClick={() => handleLogin('admin')} 
                    className="w-full"
                  >
                    Login as Admin
                  </Button>
                  <Button 
                    onClick={() => fillDemoCredentials('admin')}
                    variant="outline" 
                    className="w-full text-xs"
                  >
                    Use Demo Credentials
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="text-center text-xs text-muted-foreground">
          <p>Demo accounts are available for testing purposes.</p>
          <p>Contact admin for account registration.</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}