import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Badge } from './ui/badge';
import { Calendar, Clock, Plus, Edit, Trash2, Users, MapPin } from 'lucide-react';

interface ClassSchedule {
  id: string;
  subject: string;
  grade: string;
  teacher: string;
  room: string;
  dayOfWeek: string;
  startTime: string;
  endTime: string;
  duration: number;
  enrolledStudents: number;
  maxCapacity: number;
  status: 'scheduled' | 'ongoing' | 'completed' | 'cancelled';
}

export function ClassScheduling() {
  const [selectedWeek, setSelectedWeek] = useState('current');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedClass, setSelectedClass] = useState<ClassSchedule | null>(null);

  const [schedules] = useState<ClassSchedule[]>([
    {
      id: '1',
      subject: 'Mathematics',
      grade: 'Grade 10',
      teacher: 'Dr. Smith Johnson',
      room: 'Room A-101',
      dayOfWeek: 'Monday',
      startTime: '09:00',
      endTime: '10:30',
      duration: 90,
      enrolledStudents: 15,
      maxCapacity: 20,
      status: 'scheduled'
    },
    {
      id: '2',
      subject: 'Physics',
      grade: 'Grade 12',
      teacher: 'Prof. Sarah Wilson',
      room: 'Lab B-201',
      dayOfWeek: 'Monday',
      startTime: '11:00',
      endTime: '12:30',
      duration: 90,
      enrolledStudents: 12,
      maxCapacity: 15,
      status: 'ongoing'
    },
    {
      id: '3',
      subject: 'Chemistry',
      grade: 'Grade 11',
      teacher: 'Dr. Michael Brown',
      room: 'Lab B-202',
      dayOfWeek: 'Tuesday',
      startTime: '14:00',
      endTime: '15:30',
      duration: 90,
      enrolledStudents: 18,
      maxCapacity: 20,
      status: 'scheduled'
    },
    {
      id: '4',
      subject: 'Mathematics',
      grade: 'Grade 11',
      teacher: 'Dr. Smith Johnson',
      room: 'Room A-101',
      dayOfWeek: 'Wednesday',
      startTime: '10:00',
      endTime: '11:30',
      duration: 90,
      enrolledStudents: 16,
      maxCapacity: 20,
      status: 'scheduled'
    },
    {
      id: '5',
      subject: 'English',
      grade: 'Grade 10',
      teacher: 'Ms. Emily Davis',
      room: 'Room A-102',
      dayOfWeek: 'Thursday',
      startTime: '15:00',
      endTime: '16:30',
      duration: 90,
      enrolledStudents: 10,
      maxCapacity: 15,
      status: 'scheduled'
    }
  ]);

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const timeSlots = [
    '09:00', '10:30', '12:00', '13:30', '15:00', '16:30', '18:00'
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'ongoing': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-gray-100 text-gray-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getClassesForDayAndTime = (day: string, time: string) => {
    return schedules.filter(schedule => 
      schedule.dayOfWeek === day && schedule.startTime === time
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1>Class Scheduling</h1>
          <p className="text-muted-foreground">Manage class timetables and room assignments</p>
        </div>
        <div className="flex gap-2">
          <Select value={selectedWeek} onValueChange={setSelectedWeek}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select week" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current">Current Week</SelectItem>
              <SelectItem value="next">Next Week</SelectItem>
              <SelectItem value="previous">Previous Week</SelectItem>
            </SelectContent>
          </Select>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Add Class
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Schedule New Class</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="subject">Subject</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select subject" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mathematics">Mathematics</SelectItem>
                      <SelectItem value="physics">Physics</SelectItem>
                      <SelectItem value="chemistry">Chemistry</SelectItem>
                      <SelectItem value="biology">Biology</SelectItem>
                      <SelectItem value="english">English</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="grade">Grade</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select grade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="grade-8">Grade 8</SelectItem>
                      <SelectItem value="grade-9">Grade 9</SelectItem>
                      <SelectItem value="grade-10">Grade 10</SelectItem>
                      <SelectItem value="grade-11">Grade 11</SelectItem>
                      <SelectItem value="grade-12">Grade 12</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="teacher">Teacher</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select teacher" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dr-smith">Dr. Smith Johnson</SelectItem>
                      <SelectItem value="prof-sarah">Prof. Sarah Wilson</SelectItem>
                      <SelectItem value="dr-michael">Dr. Michael Brown</SelectItem>
                      <SelectItem value="ms-emily">Ms. Emily Davis</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="room">Room</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select room" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="a-101">Room A-101</SelectItem>
                      <SelectItem value="a-102">Room A-102</SelectItem>
                      <SelectItem value="b-201">Lab B-201</SelectItem>
                      <SelectItem value="b-202">Lab B-202</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="day">Day of Week</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select day" />
                    </SelectTrigger>
                    <SelectContent>
                      {daysOfWeek.map(day => (
                        <SelectItem key={day} value={day.toLowerCase()}>{day}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="startTime">Start Time</Label>
                  <Input id="startTime" type="time" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="endTime">End Time</Label>
                  <Input id="endTime" type="time" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="capacity">Max Capacity</Label>
                  <Input id="capacity" type="number" placeholder="Maximum students" />
                </div>
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setIsAddDialogOpen(false)}>
                  Schedule Class
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl">{schedules.length}</div>
            <p className="text-xs text-muted-foreground">Total Classes</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl">{schedules.filter(s => s.status === 'ongoing').length}</div>
            <p className="text-xs text-muted-foreground">Ongoing Classes</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl">{schedules.reduce((acc, s) => acc + s.enrolledStudents, 0)}</div>
            <p className="text-xs text-muted-foreground">Total Enrollments</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl">
              {Math.round((schedules.reduce((acc, s) => acc + s.enrolledStudents, 0) / 
               schedules.reduce((acc, s) => acc + s.maxCapacity, 0)) * 100)}%
            </div>
            <p className="text-xs text-muted-foreground">Capacity Utilization</p>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Timetable */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Weekly Timetable
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <div className="grid grid-cols-8 gap-2 min-w-[800px]">
              {/* Header */}
              <div className="p-2 border bg-muted">
                <div className="text-sm">Time</div>
              </div>
              {daysOfWeek.map(day => (
                <div key={day} className="p-2 border bg-muted">
                  <div className="text-sm text-center">{day}</div>
                </div>
              ))}

              {/* Time Slots */}
              {timeSlots.map(time => (
                <div key={time} className="contents">
                  <div className="p-2 border bg-muted text-sm">
                    {time}
                  </div>
                  {daysOfWeek.map(day => (
                    <div key={`${day}-${time}`} className="p-1 border min-h-[80px]">
                      {getClassesForDayAndTime(day, time).map(classItem => (
                        <div
                          key={classItem.id}
                          className="bg-blue-50 border border-blue-200 rounded p-2 mb-1 cursor-pointer hover:bg-blue-100"
                          onClick={() => setSelectedClass(classItem)}
                        >
                          <div className="text-xs">{classItem.subject}</div>
                          <div className="text-xs text-muted-foreground">{classItem.grade}</div>
                          <div className="text-xs text-muted-foreground">{classItem.room}</div>
                          <Badge className={`${getStatusColor(classItem.status)} text-xs`}>
                            {classItem.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Class List */}
      <Card>
        <CardHeader>
          <CardTitle>All Classes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {schedules.map((classItem) => (
              <div key={classItem.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="p-2 bg-blue-100 rounded">
                    <Calendar className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span>{classItem.subject} - {classItem.grade}</span>
                      <Badge className={getStatusColor(classItem.status)}>
                        {classItem.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center gap-4 mt-1">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {classItem.dayOfWeek}, {classItem.startTime} - {classItem.endTime}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {classItem.room}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="h-3 w-3" />
                        {classItem.enrolledStudents}/{classItem.maxCapacity} students
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" onClick={() => setSelectedClass(classItem)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Class Details Dialog */}
      <Dialog open={!!selectedClass} onOpenChange={() => setSelectedClass(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Class Details</DialogTitle>
          </DialogHeader>
          {selectedClass && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Subject</Label>
                  <p>{selectedClass.subject}</p>
                </div>
                <div>
                  <Label>Grade</Label>
                  <p>{selectedClass.grade}</p>
                </div>
                <div>
                  <Label>Teacher</Label>
                  <p>{selectedClass.teacher}</p>
                </div>
                <div>
                  <Label>Room</Label>
                  <p>{selectedClass.room}</p>
                </div>
                <div>
                  <Label>Schedule</Label>
                  <p>{selectedClass.dayOfWeek}, {selectedClass.startTime} - {selectedClass.endTime}</p>
                </div>
                <div>
                  <Label>Duration</Label>
                  <p>{selectedClass.duration} minutes</p>
                </div>
                <div>
                  <Label>Enrollment</Label>
                  <p>{selectedClass.enrolledStudents} / {selectedClass.maxCapacity} students</p>
                </div>
                <div>
                  <Label>Status</Label>
                  <Badge className={getStatusColor(selectedClass.status)}>
                    {selectedClass.status}
                  </Badge>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setSelectedClass(null)}>
                  Close
                </Button>
                <Button>Edit Class</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}